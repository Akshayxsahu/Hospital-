'use strict';
// Every screen talks to the app only through call(). Permission check happens here, once, for all methods.
const perm = require('./permissions');
const auth = require('./auth');
const patients = require('./patients');
const audit = require('./audit');
const billing = require('./billing');
const exp = require('./expenses');
const people = require('./people');
const reports = require('./reports');
const printing = require('./printing');
const backup = require('./backup');
const util = require('./util');

function makeApi(db, ctx = {}) {
  let session = null;                      // single desktop user at a time
  const S = () => session;
  const M = {
    // --- session
    'auth.login':          { open: true, fn: (u, p) => (session = auth.login(db, u, p)) },
    'auth.logout':         { open: true, fn: () => { if (session) audit.log(db, session.id, 'LOGOUT', 'users', session.id); session = null; return true; } },
    'auth.changePassword': { fn: (o, n) => { auth.changePassword(db, session, o, n); session.must_change_password = false; return true; } },
    // --- admin
    'user.create':   { perm: 'user.manage', fn: (u) => auth.createUser(db, S(), u) },
    'user.list':     { perm: 'user.manage', fn: () => db.all('SELECT id,username,full_name,role,is_active FROM users ORDER BY id') },
    'user.setActive':{ perm: 'user.manage', fn: (id, on) => { if (id === S().id) throw new Error('You cannot disable yourself'); db.run('UPDATE users SET is_active=? WHERE id=?', on ? 1 : 0, id); audit.log(db, S().id, 'UPDATE', 'users', id, null, { is_active: !!on }); return true; } },
    'user.resetPassword': { perm: 'user.manage', fn: (id, pw) => { if (!pw || pw.length < 6) throw new Error('Password must be at least 6 characters'); db.run('UPDATE users SET password_hash=?, must_change_password=1 WHERE id=?', auth.hash(pw), id); audit.log(db, S().id, 'UPDATE', 'users', id, null, { password: 'reset' }); return true; } },
    'audit.forRecord': { perm: 'audit.view', fn: (t, id) => audit.forRecord(db, t, id) },
    'audit.list':    { perm: 'audit.view', fn: (f = {}) => audit.list(db, f) },
    'settings.get':  { perm: 'patient.view', fn: () => Object.fromEntries(db.all('SELECT key,value FROM settings').map((r) => [r.key, r.value])) },
    'settings.set':  { perm: 'settings.edit', fn: (kv) => { db.tx(() => { for (const [k, v] of Object.entries(kv)) db.run('INSERT INTO settings(key,value) VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value', k, String(v ?? '')); audit.log(db, S().id, 'UPDATE', 'settings', null, null, kv); }); return true; } },
    'account.setOpening': { perm: 'settings.edit', fn: (id, amount) => { if (!Number.isInteger(amount)) throw new Error('Invalid amount'); const used = db.get('SELECT COUNT(*) n FROM v_cashbook WHERE account_id=?', id).n; if (used) throw new Error('Opening balance cannot change after entries exist'); db.run('UPDATE accounts SET opening_balance=? WHERE id=?', amount, id); audit.log(db, S().id, 'UPDATE', 'accounts', id, null, { opening_balance: amount }); return true; } },
    'backup.now':    { perm: 'backup.manage', fn: (dir, kind) => backup.backupNow(db, dir || ctx.backupDir, kind || 'MANUAL_USB', S().id) },
    'backup.list':   { perm: 'backup.manage', fn: () => db.all('SELECT * FROM backup_log ORDER BY id DESC LIMIT 50') },
    'backup.stageRestore': { perm: 'backup.manage', fn: (file) => { const r = backup.stageRestore(file, ctx.dataDir); audit.log(db, S().id, 'RESTORE', 'backup_log', null, null, { file }); return r; } },
    // --- masters
    'masters.list':  { perm: 'patient.view', fn: () => people.masters(db) },
    'doctor.save':   { perm: 'master.edit', fn: (d) => people.saveDoctor(db, S(), d) },
    'ward.save':     { perm: 'master.edit', fn: (w) => people.saveWard(db, S(), w) },
    'service.save':  { perm: 'master.edit', fn: (s) => people.saveService(db, S(), s) },
    'staff.save':    { perm: 'master.edit', fn: (s) => people.saveStaff(db, S(), s) },
    // --- patients
    'patient.create':  { perm: 'patient.create', fn: (p, o) => patients.create(db, S(), p, { allowDuplicate: !!o?.allowDuplicate }) },
    'patient.update':  { perm: 'patient.update', fn: (id, c) => patients.update(db, S(), id, c) },
    'patient.search':  { perm: 'patient.search', fn: (q) => patients.search(db, q) },
    'patient.profile': { perm: 'patient.view', fn: (id) => { const r = patients.profile(db, id, { withFinance: perm.can(S().role, 'finance.view') }); if (r.expenses) r.expenses.forEach((e) => { e.attachments = exp.attachments(db, e.id); }); return r; } },
    'patient.discharge': { perm: 'patient.update', fn: (id, date) => patients.discharge(db, S(), id, date) },
    'patient.close':   { perm: 'void.any', fn: (id, force) => patients.close(db, S(), id, { force }) },
    // --- money in
    'bill.create':     { perm: 'bill.create', fn: (b) => billing.createBill(db, S(), b) },
    'payment.create':  { perm: 'payment.create', fn: (p) => billing.receivePayment(db, S(), p) },
    'refund.create':   { perm: 'refund.create', fn: (r) => billing.refund(db, S(), r) },
    'creditnote.create': { perm: 'refund.create', fn: (c) => billing.creditNote(db, S(), c) },
    'void':            { perm: 'void.any', fn: (table, id, reason) => billing.voidRecord(db, S(), table, id, reason) },
    // --- money out
    'expensehead.create': { perm: 'expense.create', fn: (h) => exp.addHead(db, S(), h) },
    'expense.create':  { perm: 'expense.create', fn: (e) => exp.addPatientExpense(db, S(), e) },
    'expense.attach':  { perm: 'expense.create', fn: (id, file) => exp.attach(db, S(), id, file, ctx.attachDir) },
    'hospitalExpense.create': { perm: 'expense.create', fn: (e) => exp.addHospitalExpense(db, S(), e) },
    'allocation.preview': { perm: 'expense.create', fn: (a) => exp.allocationPreview(db, a) },
    'allocation.confirm': { perm: 'expense.create', fn: (a) => exp.allocationConfirm(db, S(), a) },
    'allocation.list': { perm: 'report.view', fn: () => db.all('SELECT a.*, h.name head FROM fixed_cost_allocations a JOIN expense_heads h ON h.id=a.head_id ORDER BY a.id DESC LIMIT 100') },
    'doctor.settle':   { perm: 'doctor.settle', fn: (s) => people.settleDoctor(db, S(), s) },
    'salary.pay':      { perm: 'staff.salary', fn: (s) => people.paySalary(db, S(), s) },
    // --- reports & printing
    'dashboard':       { perm: 'report.view', fn: (d) => reports.dashboard(db, d) },
    'report.run':      { perm: 'report.view', fn: (name, f) => reports.run(db, name, f) },
    'print.receipt':   { perm: 'finance.view', fn: (id, fmt) => printing.receiptHtml(db, id, fmt) },
    'print.bill':      { perm: 'finance.view', fn: (id, fmt) => printing.billHtml(db, id, fmt) },
    'print.report':    { perm: 'report.view', fn: (name, f) => printing.reportHtml(db, reports.run(db, name, f)) },
  };
  function call(name, ...args) {
    const m = M[name];
    if (!m) throw new Error('Unknown action ' + name);
    if (!m.open) {
      if (!session) { const e = new Error('Please login'); e.code = 'NOT_LOGGED_IN'; throw e; }
      if (session.must_change_password && name !== 'auth.changePassword') { const e = new Error('Change your password first'); e.code = 'MUST_CHANGE_PASSWORD'; throw e; }
    }
    if (m.perm) perm.require(session.role, m.perm);
    return m.fn(...args);
  }
  call.session = () => session;
  return call;
}
module.exports = { makeApi };

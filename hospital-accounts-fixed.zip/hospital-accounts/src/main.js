'use strict';
const { app, BrowserWindow, ipcMain, dialog } = require('electron');
const path = require('path');
const fs = require('fs');
const db = require('./db');
const auth = require('./auth');
const backup = require('./backup');
const reports = require('./reports');
const printing = require('./printing');
const { reportToXlsx } = require('./xlsx');
const { makeApi } = require('./api');

let call, win, conn;
const dataDir = () => path.join(app.getPath('userData'), 'data');

function printHtml(html, { pdfPath, silent = false, thermal = false } = {}) {
  return new Promise((resolve, reject) => {
    const w = new BrowserWindow({ show: false });
    w.loadURL('data:text/html;charset=utf-8,' + encodeURIComponent(html));
    w.webContents.on('did-finish-load', async () => {
      try {
        if (pdfPath) { fs.writeFileSync(pdfPath, await w.webContents.printToPDF({ pageSize: 'A4', landscape: /landscape/.test(html) })); resolve(pdfPath); }
        else w.webContents.print({ silent, printBackground: true, ...(thermal ? { pageSize: { width: 80000, height: 200000 } } : {}) }, (ok, why) => (ok ? resolve(true) : reject(new Error(why || 'Print cancelled'))));
      } catch (e) { reject(e); } finally { setTimeout(() => w.destroy(), 1500); }
    });
  });
}

app.whenReady().then(() => {
  const dir = dataDir();
  fs.mkdirSync(dir, { recursive: true });
  backup.applyPendingRestore(dir);                                      // finish a restore requested before restart
  conn = db.open(path.join(dir, 'hospital.db'));
  conn.exec('PRAGMA journal_mode=WAL;');
  auth.ensureAdmin(conn, 'yeeshubh', 'Shubh', 'Shubh');
  const ctx = { dataDir: dir, attachDir: path.join(dir, 'attachments'), backupDir: path.join(dir, 'backups') };
  call = makeApi(conn, ctx);

  // Daily automatic backup: on start, then check every hour (first check of each day makes the backup).
  const auto = () => { try { backup.autoBackupIfNeeded(conn, ctx.backupDir); } catch (e) { console.error('auto-backup failed', e); } };
  auto(); setInterval(auto, 60 * 60 * 1000);

  // Renderer gets ONE door into the app; errors come back as plain objects.
  ipcMain.handle('api', (_e, name, args) => {
    try { return { ok: true, data: call(name, ...(args || [])) }; }
    catch (err) { return { ok: false, error: err.message, code: err.code, matches: err.matches }; }
  });
  const guard = (fn) => async (_e, ...a) => { try { return { ok: true, data: await fn(...a) }; } catch (err) { return { ok: false, error: err.message }; } };
  const need = (action) => { require('./permissions').require(call.session()?.role, action); };

  ipcMain.handle('pickFile', guard(async () => (await dialog.showOpenDialog(win, { filters: [{ name: 'PDF / Image', extensions: ['pdf', 'png', 'jpg', 'jpeg'] }] })).filePaths[0] || null));
  ipcMain.handle('pickBackupFile', guard(async () => (await dialog.showOpenDialog(win, { filters: [{ name: 'Backup', extensions: ['db'] }] })).filePaths[0] || null));
  ipcMain.handle('pickFolder', guard(async () => (await dialog.showOpenDialog(win, { properties: ['openDirectory'] })).filePaths[0] || null));
  ipcMain.handle('attachFile', guard(async (expenseId) => {                 // dialog + attach in one step
    const f = (await dialog.showOpenDialog(win, { filters: [{ name: 'PDF / Image', extensions: ['pdf', 'png', 'jpg', 'jpeg'] }] })).filePaths[0];
    return f ? call('expense.attach', expenseId, f) : null;
  }));
  ipcMain.handle('openAttachment', guard(async (rel) => { need('finance.view'); const full = path.join(dir, 'attachments', rel); if (!full.startsWith(path.join(dir, 'attachments'))) throw new Error('Bad path'); return require('electron').shell.openPath(full); }));
  ipcMain.handle('exportXlsx', guard(async (name, filters) => {
    const rep = call('report.run', name, filters);
    const r = await dialog.showSaveDialog(win, { defaultPath: `${rep.title}.xlsx`, filters: [{ name: 'Excel', extensions: ['xlsx'] }] });
    if (r.canceled) return null; fs.writeFileSync(r.filePath, reportToXlsx(rep)); return r.filePath;
  }));
  ipcMain.handle('exportPdf', guard(async (name, filters) => {
    const html = call('print.report', name, filters);
    const r = await dialog.showSaveDialog(win, { defaultPath: `${call('report.run', name, filters).title}.pdf`, filters: [{ name: 'PDF', extensions: ['pdf'] }] });
    if (r.canceled) return null; return printHtml(html, { pdfPath: r.filePath });
  }));
  ipcMain.handle('printDoc', guard(async (kind, id, format) => {            // kind: receipt | bill
    const html = call(kind === 'bill' ? 'print.bill' : 'print.receipt', id, format);
    return printHtml(html, { thermal: format === 'THERMAL', silent: false });
  }));
  ipcMain.handle('backupToFolder', guard(async (kind) => {
    need('backup.manage');
    const f = (await dialog.showOpenDialog(win, { properties: ['openDirectory'], title: 'Choose pen drive or Google Drive folder' })).filePaths[0];
    return f ? call('backup.now', f, kind) : null;
  }));
  ipcMain.handle('restartApp', () => { app.relaunch(); app.exit(0); });

  win = new BrowserWindow({ width: 1280, height: 800, autoHideMenuBar: true,
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false } });
  win.loadFile(path.join(__dirname, '..', 'renderer', 'index.html'));
});
app.on('window-all-closed', () => app.quit());

'use strict';
// Every new patient must have an ID proof (Aadhar or Ayushman). Tests hand out unique ones so duplicate detection stays quiet.
let n = 100000000000;
const aadhar = () => String(++n);
const id = () => ({ id_type: 'AADHAR', aadhar: aadhar() });
module.exports = { aadhar, id };

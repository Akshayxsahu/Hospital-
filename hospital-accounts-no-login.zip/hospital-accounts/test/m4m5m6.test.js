'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs'); const os = require('os'); const path = require('path'); const { execFileSync } = require('child_process');
const ids = require('./_ids');
const dbm = require('../src/db');
const patients = require('../src/patients');
const billing = require('../src/billing');
const exp = require('../src/expenses');
const people = require('../src/people');
const reports = require('../src/reports');
const { reportToXlsx } = require('../src/xlsx');
const printing = require('../src/printing');
const backup = require('../src/backup');
const util = require('../src/util');

const admin = { id: 1, role: 'ADMIN' };
const head = (db, n) => db.get('SELECT id FROM expense_heads WHERE name=?', n).id;

// A small realistic month of data
function world() {
  const db = dbm.open(':memory:');
  db.run("INSERT INTO users(id,username,full_name,password_hash,role) VALUES (1,'admin','Admin','x','ADMIN')");
  db.run("UPDATE settings SET value='City Care Hospital' WHERE key='hospital_name'"); db.run("UPDATE settings SET value='Raipur, Chhattisgarh' WHERE key='address'");
  db.run("UPDATE accounts SET opening_balance=5000000 WHERE kind='CASH'"); db.run("UPDATE accounts SET opening_balance=10000000 WHERE kind='BANK'");
  const d1 = people.saveDoctor(db, admin, { name: 'Dr. Sharma', percent_bp: 2000 }).id;
  const d2 = people.saveDoctor(db, admin, { name: 'Dr. Verma', fixed_fee: 30000 }).id;
  const w = db.get("SELECT id FROM wards WHERE name='Private'").id;
  const mk = (name, doc, adm, extra = {}) => patients.create(db, admin, { name, patient_type: 'IPD', doctor_id: doc, ward_id: w, admission_date: adm, ...ids.id(), ...extra }).id;
  const a = mk('Patient A', d1, '2026-11-10', { discharge_date: '2026-11-14' });
  const b = mk('Patient B', d2, '2026-11-12');
  billing.receivePayment(db, admin, { patient_id: a, pay_type: 'ADVANCE', mode: 'CASH', amount: 500000, pay_date: '2026-11-10' });
  billing.createBill(db, admin, { patient_id: a, bill_date: '2026-11-14', items: [{ description: 'IPD package', rate: 1000000, doctor_id: d1 }] });
  billing.receivePayment(db, admin, { patient_id: a, pay_type: 'FULL', mode: 'UPI', amount: 500000, pay_date: '2026-11-14' });
  exp.addPatientExpense(db, admin, { patient_id: a, head_id: head(db, 'Medicine / Pharmacy'), amount: 150000, exp_date: '2026-11-13' });
  billing.createBill(db, admin, { patient_id: b, bill_date: '2026-11-15', items: [{ description: 'Surgery', rate: 2000000 }], discount: 100000, discount_reason: 'Senior citizen' });
  billing.receivePayment(db, admin, { patient_id: b, pay_type: 'ADVANCE', mode: 'CARD', amount: 800000, pay_date: '2026-11-15' });
  exp.addPatientExpense(db, admin, { patient_id: b, head_id: head(db, 'Doctor Fee'), doctor_id: d2, amount: 30000, exp_date: '2026-11-15' });
  exp.addHospitalExpense(db, admin, { head_id: head(db, 'Electricity'), amount: 600000, exp_date: '2026-11-20' });
  const st = people.saveStaff(db, admin, { name: 'Nurse Sita', monthly_salary: 1800000 }).id;
  people.paySalary(db, admin, { staff_id: st, salary_month: '2026-11', paid_date: '2026-11-30' });
  exp.allocationConfirm(db, admin, { head_id: head(db, 'Electricity'), period_from: '2026-11-01', period_to: '2026-11-30', total_amount: 600000 });
  people.settleDoctor(db, admin, { doctor_id: d1, amount: 100000, settle_date: '2026-11-16' });
  return { db, a, b, d1, d2 };
}

test('dashboard: billing, collection, expense (no double count of allocated overhead), ACCRUAL profit', () => {
  const { db } = world();
  const t = reports.dashboard(db, '2026-11-15');
  assert.equal(t.collection, 800000);       // cash received that day (information only)
  assert.equal(t.billed, 1900000);          // Patient B's bill, after the 1,000 discount - this is the day's INCOME
  assert.equal(t.expense, 30000);           // only Patient B's doctor fee that day
  assert.equal(t.profit, 1900000 - 30000);  // accrual: billed - cost, NOT cash received - cost
  assert.equal(t.patients_today, 0);
  const all = reports.dashboard(db, '2026-11-14');
  assert.equal(all.collection, 500000); assert.equal(all.billed, 1000000);
  assert.equal(all.pending_dues, db.get('SELECT SUM(due) v FROM v_patient_financials WHERE due>0').v);
});

test('patient P&L: rows, group by doctor / ward / date, filters, totals', () => {
  const { db, d1 } = world();
  const r = reports.patientPnl(db, {});
  assert.equal(r.rows.length, 2);
  const a = r.rows.find((x) => x.name === 'Patient A');
  assert.equal(a.profit, a.net_billed - a.total_cost);
  assert.equal(reports.patientPnl(db, { doctor_id: d1 }).rows.length, 1);
  assert.equal(reports.patientPnl(db, { group_by: 'ward' }).rows[0].patients, 2);
  assert.equal(reports.patientPnl(db, { group_by: 'doctor' }).rows.length, 2);
  assert.equal(reports.patientPnl(db, { group_by: 'date' }).rows.length, 2);
  assert.equal(reports.patientPnl(db, { from: '2026-11-11' }).rows.length, 1);
  assert.equal(r.totals.profit, r.rows.reduce((s, x) => s + x.profit, 0));
});

test('daily collection filters by mode/date; outstanding ageing', () => {
  const { db } = world();
  const c = reports.dailyCollection(db, { mode: 'UPI' });
  assert.deepEqual([c.rows.length, c.totals.net], [1, 500000]);
  assert.equal(reports.dailyCollection(db, { from: '2026-11-15', to: '2026-11-15' }).totals.received, 800000);
  const o = reports.outstanding(db, { as_of: '2026-12-20' });
  assert.equal(o.rows.length, 1);                                   // Patient A is fully paid
  const b = o.rows[0];
  assert.deepEqual([b.name, b.net_billed, b.net_received, b.due, b.age_days], ['Patient B', 1900000, 800000, 1100000, 35]);
  assert.equal(b.bucket, '31-60');
});

test('doctor report and settlement', () => {
  const { db, d1 } = world();
  const r = reports.doctorReport(db, {});
  const sharma = r.rows.find((x) => x.name === 'Dr. Sharma');
  assert.deepEqual([sharma.billed, sharma.earned, sharma.paid, sharma.payable], [1000000, 200000, 100000, 100000]);
});

test('overall P&L, cash book and bank book reconcile', () => {
  const { db } = world();
  const p = reports.overallPnl(db, {});
  const net = p.rows.find((r) => r.label === 'NET PROFIT / (LOSS)').amount;
  // ACCRUAL income = billed: 1,000,000 + (2,000,000 - 100,000 discount) = 2,900,000   (cash received is only a memo)
  // costs: pharmacy 150000 + doctor fees(200000+30000) + electricity 600000 + salary 1800000
  assert.equal(net, 2900000 - (150000 + 230000 + 600000 + 1800000));
  const cash = reports.cashBook(db, { kind: 'CASH' }), bank = reports.cashBook(db, { kind: 'BANK' });
  // cash: 5,000,000 open +500000 adv -150000 pharmacy -600000 electricity -1800000 salary -100000 settlement
  assert.equal(cash.totals.balance, 5000000 + 500000 - 150000 - 600000 - 1800000 - 100000);
  assert.equal(bank.totals.balance, 10000000 + 500000 + 800000);
  assert.equal(reports.cashBook(db, { kind: 'CASH', from: '2026-11-11' }).rows[0].balance, 5000000 + 500000);   // opening carried forward
});

test('BALANCE SHEET always balances (assets = liabilities + capital + retained), at any date', () => {
  const { db, a } = world();
  for (const d of ['2026-11-09', '2026-11-12', '2026-11-15', '2026-11-30', '2027-03-01']) assert.equal(reports.balanceSheet(db, { as_of: d }).balanced, true, d);
  billing.refund(db, admin, { patient_id: a, mode: 'CASH', amount: 10000, reason: 'x', refund_date: '2026-12-01' });
  billing.voidRecord(db, admin, 'payments', 1, 'wrong entry');
  assert.equal(reports.balanceSheet(db, {}).balanced, true);
});

test('xlsx export is a valid workbook (opens with a standard reader)', () => {
  const { db } = world();
  const rep = reports.patientPnl(db, {});
  const file = path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'x-')), 'r.xlsx');
  fs.writeFileSync(file, reportToXlsx(rep));
  const py = `import zipfile,sys,xml.dom.minidom as m
z=zipfile.ZipFile(sys.argv[1]); assert z.testzip() is None
for n in z.namelist(): m.parseString(z.read(n))
try:
  import openpyxl; ws=openpyxl.load_workbook(sys.argv[1]).active; print('OPENPYXL', ws.max_row, ws.cell(1,1).value, ws.cell(2,1).value)
except ImportError: print('ZIPXML-OK')`;
  const out = execFileSync('python3', ['-I', '-c', py, file]).toString();
  console.log('  ' + out.trim());
  assert.match(out, /OPENPYXL 4 Patient ID PAT-|ZIPXML-OK/);
});

test('receipt / bill / report print templates', () => {
  const { db } = world();
  const r = printing.receiptHtml(db, 1, 'A4'), t = printing.receiptHtml(db, 1, 'THERMAL');
  assert.match(r, /City Care Hospital/); assert.match(r, /Rupees Five Thousand Only/); assert.match(t, /width:72mm/);
  assert.match(printing.billHtml(db, 2, 'A4'), /Senior citizen/);
  assert.match(printing.reportHtml(db, reports.patientPnl(db, {})), /Patient-wise Profit/);
  assert.equal(printing.amountInWords(12345678), 'Rupees One Lakh Twenty Three Thousand Four Hundred Fifty Six and Seventy Eight Paise Only');
  assert.equal(printing.amountInWords(10000000), 'Rupees One Lakh Only');
  assert.equal(printing.amountInWords(250000000), 'Rupees Twenty Five Lakh Only');
  assert.equal(printing.receiptHtml(db, 1).includes('<script'), false);
});

test('html is escaped (patient name cannot inject script)', () => {
  const { db } = world();
  db.run("UPDATE patients SET name='<script>alert(1)</script>' WHERE id=1");
  assert.equal(printing.receiptHtml(db, 1).includes('<script>alert'), false);
});

test('backup: snapshot is a valid database, daily auto backup runs once, restore swaps file', () => {
  const { db } = world();
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'bk-'));
  const first = backup.autoBackupIfNeeded(db, path.join(dir, 'b'));
  assert.ok(first && fs.existsSync(first.file));
  assert.equal(backup.autoBackupIfNeeded(db, path.join(dir, 'b')), null);          // already done today
  assert.equal(backup.verify(first.file).patients, 2);
  const m = backup.backupNow(db, path.join(dir, 'usb'), 'MANUAL_USB', 1);
  assert.equal(db.get("SELECT COUNT(*) n FROM backup_log").n, 2);
  fs.writeFileSync(path.join(dir, 'junk.db'), 'not a database');
  assert.throws(() => backup.verify(path.join(dir, 'junk.db')));
  // restore flow
  fs.copyFileSync(m.file, path.join(dir, 'hospital.db'));
  const data = path.join(dir, 'data'); fs.mkdirSync(data); fs.writeFileSync(path.join(data, 'hospital.db'), 'OLD');
  backup.stageRestore(m.file, data);
  assert.equal(backup.applyPendingRestore(data), true);
  assert.equal(backup.verify(path.join(data, 'hospital.db')).patients, 2);
  assert.ok(fs.readdirSync(data).some((f) => f.startsWith('before-restore-')));      // old file kept, never destroyed
  assert.equal(backup.applyPendingRestore(data), false);
});

test('local date is used (not UTC) so midnight entries land on the right day', () => {
  util.setNow(new Date(2026, 10, 18, 0, 30));          // 18-Nov 00:30 local
  assert.equal(util.ymd(), '2026-11-18'); util.setNow(null);
});

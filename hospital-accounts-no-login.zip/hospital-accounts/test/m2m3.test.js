'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs'); const os = require('os'); const path = require('path');
const ids = require('./_ids');
const dbm = require('../src/db');
const patients = require('../src/patients');
const billing = require('../src/billing');
const exp = require('../src/expenses');
const people = require('../src/people');

const admin = { id: 1, role: 'ADMIN' };
function setup() {
  const db = dbm.open(':memory:');
  db.run("INSERT INTO users(id,username,full_name,password_hash,role) VALUES (1,'admin','Admin','x','ADMIN')");
  const doc = people.saveDoctor(db, admin, { name: 'Dr. Sharma', percent_bp: 2000, fixed_fee: 50000 }).id;
  const mk = (name, extra = {}) => patients.create(db, admin, { name, patient_type: 'IPD', admission_date: '2026-11-10', ...ids.id(), ...extra }).id;
  return { db, doc, mk };
}
const head = (db, name) => db.get('SELECT id FROM expense_heads WHERE name=?', name).id;
const F = (db, id) => db.get('SELECT * FROM v_patient_financials WHERE patient_id=?', id);

test('Patient A end to end: advance, part, full, expenses, allocation -> profit 1,800', () => {
  const { db, doc, mk } = setup();
  const a = mk('Patient A');
  billing.receivePayment(db, admin, { patient_id: a, pay_type: 'ADVANCE', mode: 'CASH', amount: 500000, pay_date: '2026-11-10' });
  billing.receivePayment(db, admin, { patient_id: a, pay_type: 'ADVANCE', mode: 'UPI', amount: 300000, pay_date: '2026-11-12' });
  const b = billing.createBill(db, admin, { patient_id: a, bill_date: '2026-11-14', items: [{ description: 'IPD package', qty: 1, rate: 1000000, doctor_id: doc, doctor_percent_bp: 2000 }] });
  assert.equal(b.bill_no.slice(0, 5), 'BILL-');
  assert.equal(F(db, a).due, 200000);
  const r = billing.receivePayment(db, admin, { patient_id: a, pay_type: 'FULL', mode: 'CASH', amount: 200000, pay_date: '2026-11-14' });
  assert.equal(r.due_after, 0);
  exp.addPatientExpense(db, admin, { patient_id: a, head_id: head(db, 'Food'), amount: 20000 });
  exp.addPatientExpense(db, admin, { patient_id: a, head_id: head(db, 'Medicine / Pharmacy'), amount: 150000 });
  exp.addPatientExpense(db, admin, { patient_id: a, head_id: head(db, 'Pathology / Lab'), amount: 150000 });
  // doctor share = 20% of 10,000 = 2,000 auto-booked from the bill line
  const al = exp.allocationConfirm(db, admin, { head_id: head(db, 'Electricity'), period_from: '2026-11-01', period_to: '2026-11-30', total_amount: 300000 });
  assert.equal(al.patients, 1);
  const f = F(db, a);
  assert.deepEqual([f.net_received, f.direct_cost, f.overhead_cost, f.total_cost, f.profit, f.due], [1000000, 520000, 300000, 820000, 180000, 0]);
  assert.equal(db.get('SELECT payable FROM v_doctor_payable WHERE doctor_id=?', doc).payable, 200000);
});

test('payment rules: part < due, full == due, nothing due -> advance, TPA name, no overpay', () => {
  const { db, mk } = setup(); const a = mk('A');
  const pay = (o) => billing.receivePayment(db, admin, { patient_id: a, mode: 'CASH', ...o });
  assert.throws(() => pay({ pay_type: 'PART', amount: 100 }), /Nothing is due/);
  billing.createBill(db, admin, { patient_id: a, items: [{ description: 'X', rate: 100000 }] });
  assert.throws(() => pay({ pay_type: 'PART', amount: 100000 }), /less than the due/);
  assert.throws(() => pay({ pay_type: 'FULL', amount: 50000 }), /must equal the due/);
  assert.throws(() => pay({ pay_type: 'PART', amount: 1.5 }), /positive amount/);
  assert.throws(() => pay({ pay_type: 'PART', amount: 1000, mode: 'INSURANCE_TPA' }), /TPA/);
  pay({ pay_type: 'PART', amount: 40000, mode: 'INSURANCE_TPA', tpa_name: 'Star Health', reference_no: 'CLM1' });
  assert.equal(F(db, a).due, 60000);
});

test('discount needs reason; refund limited to received; credit note limited to bill', () => {
  const { db, mk } = setup(); const a = mk('A');
  assert.throws(() => billing.createBill(db, admin, { patient_id: a, items: [{ description: 'X', rate: 100000 }], discount: 5000 }), /reason/);
  assert.throws(() => billing.createBill(db, admin, { patient_id: a, items: [{ description: 'X', rate: 100000 }], discount: 200000, discount_reason: 'x' }), /more than the bill/);
  const b = billing.createBill(db, admin, { patient_id: a, items: [{ description: 'X', rate: 100000 }], discount: 10000, discount_reason: 'Staff' });
  assert.equal(b.total, 90000);
  billing.receivePayment(db, admin, { patient_id: a, pay_type: 'FULL', mode: 'UPI', amount: 90000 });
  assert.throws(() => billing.refund(db, admin, { patient_id: a, mode: 'UPI', amount: 100000, reason: 'x' }), /more than the money received/);
  billing.refund(db, admin, { patient_id: a, mode: 'UPI', amount: 20000, reason: 'Unused medicine' });
  assert.equal(F(db, a).net_received, 70000);
  assert.throws(() => billing.creditNote(db, admin, { patient_id: a, bill_id: b.id, amount: 95000, reason: 'x' }), /more than the bill/);
  billing.creditNote(db, admin, { patient_id: a, bill_id: b.id, amount: 20000, reason: 'Service not given' });
  assert.equal(F(db, a).net_billed, 70000);
});

test('doctor share: percent override, fixed-fee expense, void bill removes auto share', () => {
  const { db, doc, mk } = setup(); const a = mk('A');
  const b = billing.createBill(db, admin, { patient_id: a, items: [{ description: 'Surgery', rate: 1000000, doctor_id: doc }, { description: 'Visit', rate: 100000, doctor_id: doc, doctor_percent_bp: 5000 }] });
  assert.equal(db.get('SELECT payable FROM v_doctor_payable').payable, 200000 + 50000);
  assert.throws(() => exp.addPatientExpense(db, admin, { patient_id: a, head_id: head(db, 'Doctor Fee'), amount: 50000 }), /Choose the doctor/);
  exp.addPatientExpense(db, admin, { patient_id: a, head_id: head(db, 'Doctor Fee'), amount: 50000, doctor_id: doc });
  assert.equal(db.get('SELECT payable FROM v_doctor_payable').payable, 300000);
  billing.voidRecord(db, admin, 'bills', b.id, 'Entered wrongly');
  assert.equal(db.get('SELECT payable FROM v_doctor_payable').payable, 50000);
  assert.equal(F(db, a).net_billed, 0);
  assert.throws(() => billing.voidRecord(db, admin, 'bills', b.id, 'again'), /Already/);
  assert.throws(() => billing.voidRecord(db, admin, 'bills', 99, ''), /reason/);
  assert.equal(db.get("SELECT COUNT(*) n FROM audit_log WHERE action='VOID'").n, 1);
});

test('expense heads: custom head, scope rules', () => {
  const { db, mk } = setup(); const a = mk('A');
  const { id } = exp.addHead(db, admin, { name: 'Ambulance' });
  exp.addPatientExpense(db, admin, { patient_id: a, head_id: id, amount: 80000 });
  assert.throws(() => exp.addHead(db, admin, { name: 'ambulance' }), /already exists/);
  assert.throws(() => exp.addPatientExpense(db, admin, { patient_id: a, head_id: head(db, 'Electricity'), amount: 1 }), /overhead/);
  assert.throws(() => exp.addHospitalExpense(db, admin, { head_id: head(db, 'Food'), amount: 1 }), /patient expense/);
});

test('allocation: exact paise split, per-day weighting, double allocation blocked, void redo', () => {
  const { db, mk } = setup();
  const p1 = mk('P1', { admission_date: '2026-11-01', discharge_date: '2026-11-10' });   // 10 days
  const p2 = mk('P2', { admission_date: '2026-11-21' });                                  // 10 days (21..30)
  const p3 = mk('P3', { admission_date: '2026-11-30' });                                  // 1 day
  const h = head(db, 'Electricity');
  const base = { head_id: h, period_from: '2026-11-01', period_to: '2026-11-30', total_amount: 1000003 };
  const pv = exp.allocationPreview(db, base);
  assert.equal(pv.rows.reduce((s, r) => s + r.amount, 0), 1000003);                       // no paise lost
  assert.deepEqual(pv.rows.map((r) => r.days), [10, 10, 1]);
  const eq = exp.allocationPreview(db, { ...base, method: 'EQUAL', total_amount: 100 });
  assert.deepEqual(eq.rows.map((r) => r.amount).sort(), [33, 33, 34]);
  assert.throws(() => exp.allocationPreview(db, { ...base, method: 'MANUAL', manual: { [p1]: 5 } }), /add up/);
  const done = exp.allocationConfirm(db, admin, base);
  assert.throws(() => exp.allocationConfirm(db, admin, base), /already allocated/);
  billing.voidRecord(db, admin, 'fixed_cost_allocations', done.id, 'Wrong total');
  assert.equal(db.get('SELECT COALESCE(SUM(overhead_cost),0) s FROM v_patient_financials').s, 0);
  exp.allocationConfirm(db, admin, { ...base, method: 'MANUAL', manual: { [p1]: 1, [p2]: 2, [p3]: 1000000 } });
  assert.equal(F(db, p3).overhead_cost, 1000000);
});

test('attachments: copies file, only pdf/image, hash stored', () => {
  const { db, mk } = setup(); const a = mk('A');
  const e = exp.addPatientExpense(db, admin, { patient_id: a, head_id: head(db, 'Medicine / Pharmacy'), amount: 1000 }).id;
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'att-'));
  fs.writeFileSync(path.join(tmp, 'rx.pdf'), '%PDF-1.4 test'); fs.writeFileSync(path.join(tmp, 'evil.exe'), 'x');
  const r = exp.attach(db, admin, e, path.join(tmp, 'rx.pdf'), path.join(tmp, 'store'));
  assert.ok(fs.existsSync(path.join(tmp, 'store', r.path)));
  assert.equal(exp.attachments(db, e)[0].sha256.length, 64);
  assert.throws(() => exp.attach(db, admin, e, path.join(tmp, 'evil.exe'), tmp), /Only PDF/);
});

test('closed patient rejects entries; discharge rules', () => {
  const { db, mk } = setup(); const a = mk('A');
  assert.throws(() => patients.discharge(db, admin, a, '2026-11-01'), /before admission/);
  patients.discharge(db, admin, a, '2026-11-12');
  assert.equal(patients.profile(db, a, { withFinance: false }).patient.status, 'DISCHARGED');
  billing.createBill(db, admin, { patient_id: a, items: [{ description: 'X', rate: 1000 }] });
  assert.throws(() => patients.close(db, admin, a), /not zero/);
  patients.close(db, admin, a, { force: true });
  assert.throws(() => billing.createBill(db, admin, { patient_id: a, items: [{ description: 'X', rate: 1 }] }), /closed/);
});

test('doctor settlement cannot exceed payable; salary once per month', () => {
  const { db, doc, mk } = setup(); const a = mk('A');
  billing.createBill(db, admin, { patient_id: a, items: [{ description: 'X', rate: 1000000, doctor_id: doc }] });
  assert.throws(() => people.settleDoctor(db, admin, { doctor_id: doc, amount: 300000 }), /Only .* is payable/);
  const s = people.settleDoctor(db, admin, { doctor_id: doc, amount: 150000 });
  assert.equal(s.payable_after, 50000);
  const st = people.saveStaff(db, admin, { name: 'Nurse', monthly_salary: 1500000 }).id;
  people.paySalary(db, admin, { staff_id: st, salary_month: '2026-11' });
  assert.throws(() => people.paySalary(db, admin, { staff_id: st, salary_month: '2026-11' }), /already entered/);
});

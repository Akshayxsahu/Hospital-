'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs'); const os = require('os'); const path = require('path');
const ids = require('./_ids');
const dbm = require('../src/db'); const patients = require('../src/patients'); const billing = require('../src/billing');
const exp = require('../src/expenses'); const people = require('../src/people'); const reports = require('../src/reports'); const printing = require('../src/printing');
const admin = { id: 1, role: 'ADMIN' };

function world() {
  const db = dbm.open(':memory:');
  db.run("INSERT INTO users(id,username,full_name,password_hash,role) VALUES (1,'admin','Admin','x','ADMIN')");
  return db;
}
const head = (db, n) => db.get('SELECT id FROM expense_heads WHERE name=?', n).id;
const mk = (db, extra = {}) => patients.create(db, admin, { name: 'P', patient_type: 'IPD', admission_date: '2026-11-10', ...ids.id(), ...extra }).id;

test('ID proof is mandatory: Aadhar (12 digits) or Ayushman card; duplicates found on either; search finds both', () => {
  const db = world();
  const base = { name: 'X', patient_type: 'OPD' };
  assert.throws(() => patients.create(db, admin, base), /Choose the ID proof/);
  assert.throws(() => patients.create(db, admin, { ...base, id_type: 'AADHAR' }), /Aadhar number is mandatory/);
  assert.throws(() => patients.create(db, admin, { ...base, id_type: 'AYUSHMAN' }), /Ayushman card ID is mandatory/);
  assert.throws(() => patients.create(db, admin, { ...base, id_type: 'AADHAR', aadhar: '1234' }), /12 digits/);
  assert.throws(() => patients.create(db, admin, { ...base, id_type: 'PAN', aadhar: '123456789012' }), /Aadhar or Ayushman/);
  assert.throws(() => patients.create(db, admin, { ...base, id_type: 'AYUSHMAN', ayushman_id: 'a b!' }), /6-30 letters/);
  const a = patients.create(db, admin, { ...base, id_type: 'AYUSHMAN', ayushman_id: 'ab-1234 5678' });     // spaces dropped, upper-cased
  assert.equal(db.get('SELECT ayushman_id v FROM patients WHERE id=?', a.id).v, 'AB-12345678');
  assert.throws(() => patients.create(db, admin, { ...base, name: 'Twin', id_type: 'AYUSHMAN', ayushman_id: 'AB-12345678' }), (e) => e.code === 'DUPLICATE');
  patients.create(db, admin, { ...base, name: 'Aadhar Man', id_type: 'AADHAR', aadhar: '999988887777' });
  assert.equal(patients.search(db, 'AB-12').length, 0);                       // letters-only prefix is a name search, not an ID search
  assert.equal(patients.search(db, '9999').length, 1);                        // Aadhar prefix
  assert.equal(patients.search(db, 'Aadhar Man')[0].name, 'Aadhar Man');
});

test('an old record without an ID proof must get one when it is next edited', () => {
  const db = world();
  db.run("INSERT INTO patients(uhid,name,patient_type,admission_date) VALUES ('PAT-2026-0099','Old Patient','OPD','2026-01-01')");
  const id = db.get("SELECT id FROM patients WHERE uhid='PAT-2026-0099'").id;
  assert.throws(() => patients.update(db, admin, id, { bed_no: 'B-1' }), /Choose the ID proof/);
  assert.equal(patients.update(db, admin, id, { bed_no: 'B-1', id_type: 'AADHAR', aadhar: '555566667777' }).changed, 3);
});

test('upgrade: an existing database (room_no, no ID columns) is migrated in place without losing data', () => {
  const file = path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'mig-')), 'old.db');
  const d = dbm.open(file);
  d.run("INSERT INTO users(id,username,full_name,password_hash,role) VALUES (1,'admin','Admin','x','ADMIN')");
  d.run("INSERT INTO patients(uhid,name,aadhar,bed_no,patient_type,admission_date) VALUES ('PAT-2026-0001','Old Ram','123456789012','S-12','IPD','2026-11-10')");
  // turn it back into the OLD layout: room_no column, no id_type / ayushman_id, schema version 0
  d.exec('DROP INDEX ix_pat_ayushman; ALTER TABLE patients DROP COLUMN id_type; ALTER TABLE patients DROP COLUMN ayushman_id; ALTER TABLE patients RENAME COLUMN bed_no TO room_no; PRAGMA user_version = 0;');
  d.close();
  const m = dbm.open(file);                                                     // the app starts -> upgrade runs
  const p = m.get("SELECT * FROM patients WHERE uhid='PAT-2026-0001'");
  assert.equal(p.bed_no, 'S-12'); assert.equal(p.name, 'Old Ram'); assert.equal(p.id_type, 'AADHAR'); assert.equal(p.aadhar, '123456789012');
  assert.equal('room_no' in p, false);
  assert.equal(m.get('PRAGMA user_version').user_version, dbm.MIGRATIONS.length);
  assert.ok(m.get('SELECT * FROM v_patient_financials LIMIT 1') !== undefined);   // views rebuilt
  m.close(); dbm.open(file).close();                                              // a second start changes nothing and does not fail
});

test('ACCRUAL: income counts when billed, not when paid; later payment does not change profit', () => {
  const db = world(); const a = mk(db);
  billing.createBill(db, admin, { patient_id: a, bill_date: '2026-11-10', items: [{ description: 'Package', rate: 1000000 }] });
  exp.addPatientExpense(db, admin, { patient_id: a, head_id: head(db, 'Food'), amount: 300000, exp_date: '2026-11-10' });
  let f = db.get('SELECT * FROM v_patient_financials WHERE patient_id=?', a);
  assert.deepEqual([f.net_received, f.profit, f.cash_profit, f.due], [0, 700000, -300000, 1000000]);   // nothing paid yet, still a 7,000 profit
  const day = reports.dashboard(db, '2026-11-10');
  assert.deepEqual([day.billed, day.collection, day.expense, day.profit], [1000000, 0, 300000, 700000]);
  billing.receivePayment(db, admin, { patient_id: a, pay_type: 'FULL', mode: 'CASH', amount: 1000000, pay_date: '2026-11-25' });
  f = db.get('SELECT * FROM v_patient_financials WHERE patient_id=?', a);
  assert.equal(f.profit, 700000);                                                  // unchanged by the payment
  assert.equal(reports.dashboard(db, '2026-11-25').profit, 0);                     // payment day: cash came in, no new income
  assert.equal(reports.dashboard(db, '2026-11-25').collection, 1000000);
  const pnl = reports.overallPnl(db, { from: '2026-11-01', to: '2026-11-30' });
  assert.equal(pnl.rows.find((r) => r.label === 'NET PROFIT / (LOSS)').amount, 700000);
  assert.equal(pnl.rows.find((r) => r.label === 'Cash received from patients').amount, 1000000);   // memo only
  const cn = billing.creditNote(db, admin, { patient_id: a, bill_id: 1, amount: 100000, reason: 'Wrong item', cn_date: '2026-11-26' });
  assert.ok(cn.cn_no);
  assert.equal(db.get('SELECT profit FROM v_patient_financials WHERE patient_id=?', a).profit, 600000);   // credit note reduces income
});

test('ACCRUAL: salary belongs to its month; balance sheet stays balanced with unpaid and advance salary', () => {
  const db = world();
  db.run("UPDATE accounts SET opening_balance=5000000 WHERE kind='CASH'");
  const st = people.saveStaff(db, admin, { name: 'Nurse', monthly_salary: 1000000 }).id;
  people.paySalary(db, admin, { staff_id: st, salary_month: '2026-11', paid_date: '2026-12-05' });   // Nov salary paid in December
  people.paySalary(db, admin, { staff_id: st, salary_month: '2027-01', paid_date: '2026-12-20' });   // January salary paid early
  const net = (f) => reports.overallPnl(db, f).rows.find((r) => r.label === 'NET PROFIT / (LOSS)').amount;
  assert.equal(net({ from: '2026-11-01', to: '2026-11-30' }), -1000000);          // November cost even though paid in December
  assert.equal(net({ from: '2026-12-01', to: '2026-12-31' }), 0);                 // December has no salary cost
  assert.equal(net({ from: '2027-01-01', to: '2027-01-31' }), -1000000);
  const at = (d) => reports.balanceSheet(db, { as_of: d });
  assert.equal(at('2026-11-30').rows.find((r) => /Salaries payable/.test(r.label)).amount, 1000000);   // accrued, unpaid
  assert.ok(at('2026-12-20').rows.find((r) => /paid in advance/.test(r.label)));                         // Jan paid early
  for (const d of ['2026-11-15', '2026-11-30', '2026-12-05', '2026-12-20', '2027-01-31', '2027-06-01']) assert.equal(at(d).balanced, true, d);
});

test('multi-line expenses are saved together or not at all; vendor is no longer needed', () => {
  const db = world(); const doc = people.saveDoctor(db, admin, { name: 'Dr. S' }).id; const a = mk(db, { doctor_id: doc });
  const r = exp.addPatientExpenses(db, admin, { patient_id: a, exp_date: '2026-11-12', mode: 'CASH', lines: [
    { head_id: head(db, 'Doctor Fee'), doctor_id: doc, amount: 50000, description: 'Visit' }, { head_id: head(db, 'Food'), amount: 20000 }, { head_id: head(db, 'Consumables'), amount: 5000, description: 'Gloves' }] });
  assert.equal(r.ids.length, 3); assert.equal(r.total, 75000);
  const rows = db.all('SELECT * FROM patient_expenses WHERE patient_id=? ORDER BY id', a);
  assert.deepEqual(rows.map((x) => [x.amount, x.vendor, x.account_id === null]), [[50000, null, true], [20000, null, false], [5000, null, false]]);   // doctor fee is payable (no cash yet)
  assert.throws(() => exp.addPatientExpenses(db, admin, { patient_id: a, lines: [{ head_id: head(db, 'Food'), amount: 100 }, { head_id: head(db, 'Doctor Fee'), amount: 100 }] }), /Line 2: Choose the doctor/);
  assert.throws(() => exp.addPatientExpenses(db, admin, { patient_id: a, lines: [{ head_id: head(db, 'Food'), amount: 100 }, { head_id: head(db, 'Electricity'), amount: 100 }] }), /Line 2/);
  assert.equal(db.get('SELECT COUNT(*) n FROM patient_expenses WHERE patient_id=?', a).n, 3);   // the good first line was NOT saved
  assert.throws(() => exp.addPatientExpenses(db, admin, { patient_id: a, lines: [] }), /at least one/);
});

test('calendar month data; discharge slip', () => {
  const db = world(); const a = mk(db, { bed_no: 'W-9', guardian_name: 'Mohan' });
  billing.createBill(db, admin, { patient_id: a, bill_date: '2026-11-12', items: [{ description: 'Bed', rate: 400000 }] });
  billing.receivePayment(db, admin, { patient_id: a, pay_type: 'ADVANCE', mode: 'UPI', amount: 100000, pay_date: '2026-11-12' });
  exp.addPatientExpense(db, admin, { patient_id: a, head_id: head(db, 'Food'), amount: 30000, exp_date: '2026-11-13' });
  const c = reports.calendarMonth(db, '2026-11');
  assert.deepEqual(c.days['2026-11-12'], { billed: 400000, collected: 100000, expense: 0, patients: 0 });
  assert.equal(c.days['2026-11-13'].expense, 30000); assert.equal(c.days['2026-11-10'].patients, 1);
  assert.throws(() => reports.calendarMonth(db, '2026-13'), /Month must look like/);
  assert.throws(() => printing.dischargeHtml(db, a), /not discharged/);
  patients.discharge(db, admin, a, '2026-11-14');
  const html = printing.dischargeHtml(db, a, 'A4');
  assert.match(html, /DISCHARGE SLIP/); assert.match(html, /W-9/); assert.match(html, /2026-11-14/); assert.match(html, /Days stayed<\/td><td>5/);
  assert.match(html, /Balance due/); assert.match(html, /3,000\.00/);                         // 4,000 billed - 1,000 received
  assert.doesNotMatch(printing.dischargeHtml(db, a, 'A4', { withFinance: false }), /Account summary/);   // receptionist: no money
  assert.match(printing.dischargeHtml(db, a, 'THERMAL'), /DISCHARGE SLIP/);
});

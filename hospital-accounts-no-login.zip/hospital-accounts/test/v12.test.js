'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const ids = require('./_ids');
const dbm = require('../src/db'); const patients = require('../src/patients'); const billing = require('../src/billing');
const people = require('../src/people'); const reports = require('../src/reports'); const printing = require('../src/printing');
const admin = { id: 1, role: 'ADMIN' };
const world = () => { const db = dbm.open(':memory:'); db.run("INSERT INTO users(id,username,full_name,password_hash,role) VALUES (1,'admin','Admin','x','ADMIN')"); return db; };

test('doctor and staff are recorded separately for each patient, with their own details', () => {
  const db = world();
  const doc = people.saveDoctor(db, admin, { name: 'Dr. Mehta', speciality: 'Surgeon', mobile: '9811111111' }).id;
  const st = people.saveStaff(db, admin, { name: 'Sister Anita', designation: 'Staff Nurse', mobile: '9822222222', monthly_salary: 1500000 }).id;
  const pid = patients.create(db, admin, { name: 'P', patient_type: 'IPD', doctor_id: doc, staff_id: st, ...ids.id() }).id;
  const p = patients.profile(db, pid, { withFinance: false }).patient;
  assert.deepEqual([p.doctor_name, p.doctor_speciality, p.doctor_mobile], ['Dr. Mehta', 'Surgeon', '9811111111']);
  assert.deepEqual([p.staff_name, p.staff_designation, p.staff_mobile], ['Sister Anita', 'Staff Nurse', '9822222222']);
  const row = patients.search(db, 'P')[0]; assert.deepEqual([row.doctor_name, row.staff_name], ['Dr. Mehta', 'Sister Anita']);   // both visible in the list
  assert.throws(() => patients.create(db, admin, { name: 'Q', patient_type: 'OPD', staff_id: 999, ...ids.id() }), /staff member not found/);
  assert.throws(() => patients.create(db, admin, { name: 'Q', patient_type: 'OPD', doctor_id: 999, ...ids.id() }), /doctor not found/);
  const st2 = people.saveStaff(db, admin, { name: 'Ramu', designation: 'Ward boy' }).id;
  assert.equal(patients.update(db, admin, pid, { staff_id: st2 }).changed, 1);                       // reassign staff; doctor untouched
  const p2 = patients.profile(db, pid, { withFinance: false }).patient; assert.deepEqual([p2.staff_name, p2.doctor_name], ['Ramu', 'Dr. Mehta']);
  people.saveStaff(db, admin, { id: st, name: 'Sister Anita', mobile: '9833333333', monthly_salary: 1500000 });
  assert.equal(db.get('SELECT mobile FROM staff WHERE id=?', st).mobile, '9833333333');
  const mk = (name) => patients.create(db, admin, { name, patient_type: 'OPD', ...ids.id() }).id;   // a patient with nobody assigned is fine
  assert.equal(patients.profile(db, mk('Nobody'), { withFinance: false }).patient.staff_name, null);
});

test('bill: no quantity column, patient address printed; old bills with qty still read correctly', () => {
  const db = world(); const pid = patients.create(db, admin, { name: 'Sunita', patient_type: 'OPD', address: 'Ward 5, Ambikapur', mobile: '9000000000', guardian_name: 'Mohan', ...ids.id() }).id;
  const b = billing.createBill(db, admin, { patient_id: pid, bill_date: '2026-11-20', items: [{ description: 'Consultation', rate: 30000 }, { description: 'Dressing', rate: 20000 }] });
  const html = printing.billHtml(db, b.id, 'A4');
  assert.match(html, /Address: Ward 5, Ambikapur/); assert.match(html, /Guardian: Mohan/);
  assert.doesNotMatch(html, />Qty</); assert.doesNotMatch(html, />Rate</); assert.match(html, />Amount</);
  assert.equal(db.all('SELECT qty,amount FROM bill_items WHERE bill_id=?', b.id).every((i) => i.qty === 1), true);
  assert.equal(db.get('SELECT total FROM bills WHERE id=?', b.id).total, 50000);
  const old = billing.createBill(db, admin, { patient_id: pid, items: [{ description: 'Injection', qty: 3, rate: 1000 }] });   // an old-style line
  assert.match(printing.billHtml(db, old.id, 'A4'), /Injection <small>\(3 x 10\.00\)<\/small>/);
  const noAddr = patients.create(db, admin, { name: 'NoAddr', patient_type: 'OPD', ...ids.id() }).id;
  assert.match(printing.billHtml(db, billing.createBill(db, admin, { patient_id: noAddr, items: [{ description: 'X', rate: 100 }] }).id), /Address: -/);
});

test('every report and the dashboard run on the strict driver (regression: "Too many parameter values were provided")', () => {
  const db = world();
  const doc = people.saveDoctor(db, admin, { name: 'D', percent_bp: 1000 }).id;
  const pid = patients.create(db, admin, { name: 'P', patient_type: 'IPD', doctor_id: doc, ...ids.id() }).id;
  billing.createBill(db, admin, { patient_id: pid, bill_date: '2026-11-10', items: [{ description: 'IPD', rate: 100000, doctor_id: doc }] });
  assert.ok(reports.dashboard(db, '2026-11-10')); assert.ok(reports.calendarMonth(db, '2026-11'));
  for (const r of ['patientPnl', 'dailyCollection', 'outstanding', 'doctorReport', 'overallPnl', 'cashBook', 'balanceSheet']) {
    for (const f of [{}, { from: '2026-11-01', to: '2026-11-30', as_of: '2026-11-30', date: '2026-11-10' }, { doctor_id: doc }]) assert.ok(reports.run(db, r, f).rows, `${r} ${JSON.stringify(f)}`);
  }
  assert.equal(reports.run(db, 'doctorReport', {}).rows.length, 1);
  assert.throws(() => dbm.positional('SELECT ?', []), /expects 1 value/);                    // a wrong number of values fails loudly
  assert.deepEqual(dbm.positional('SELECT ?1, ?2, ?1', ['a', 'b']), { sql: 'SELECT ?, ?, ?', values: ['a', 'b', 'a'] });
});

'use strict';
// Runs renderer/app.js against the REAL backend with a tiny fake DOM. Catches typos, bad variables and render errors.
const test = require('node:test');
const assert = require('node:assert/strict');
const dbm = require('../src/db'); const auth = require('../src/auth'); const { makeApi } = require('../src/api');

const hidden = new Set(['chg', 'app', 'modalbg', 'toast']); const els = {};
const el = (id) => (els[id] ||= { id, value: '', innerHTML: '', textContent: '', dataset: {}, style: {}, onclick: null, oninput: null, onchange: null, onkeydown: null,
  classList: { add: (c) => c === 'hide' && hidden.add(id), remove: (c) => c === 'hide' && hidden.delete(id), toggle: (c, f) => { if (c === 'hide') (f ? hidden.add(id) : hidden.delete(id)); }, contains: (c) => c === 'hide' && hidden.has(id) },
  querySelector: () => ({ prepend() {} }), focus() {}, closest: () => null });
let ready;
function boot() {
  const db = dbm.open(':memory:'); auth.ensureAdmin(db, 'admin123');
  const call = makeApi(db, { dataDir: '.', attachDir: '.', backupDir: '.' });
  call('auth.login', 'admin', 'admin123'); call('auth.changePassword', 'admin123', 'Secret@1');
  const sent = [];
  global.window = { api: async (n, ...a) => { try { return { ok: true, data: call(n, ...a) }; } catch (e) { return { ok: false, error: e.message, code: e.code, matches: e.matches }; } },
    native: new Proxy({}, { get: (_, k) => async (...a) => { sent.push([k, ...a]); return { ok: true, data: null }; } }) };
  global.document = { getElementById: el, querySelectorAll: () => [], addEventListener() {}, createElement: () => ({}), activeElement: { tagName: 'BODY' } };
  global.location = { reload() {} }; global.confirm = () => false; global.prompt = () => null; global.setTimeout = (f) => 0; global.clearTimeout = () => {};
  delete require.cache[require.resolve('../renderer/app.js')];
  const app = require('../renderer/app.js');
  return { db, call, app, sent };
}
const flush = () => new Promise((r) => setImmediate(r));

test('UI renders every screen without errors and a bill + payment can be saved through the forms', async () => {
  const { db, call, app } = boot();
  const me = call.session(); app.setMe(me);
  await app.enter();
  assert.match(els.view.innerHTML, /Today's Collection/);
  assert.match(els.nav.innerHTML, /Reports/);
  const doc = call('doctor.save', { name: 'Dr. Sharma', percent_bp: 2000 }).id;
  await app.SCREENS.doctors(); assert.match(els.view.innerHTML, /Dr\. Sharma/);
  const pid = call('patient.create', { name: 'Patient A', patient_type: 'IPD', doctor_id: doc }).id;
  await app.SCREENS.patients(); assert.match(els.view.innerHTML, /Patient A/);
  await app.openProfile(pid); assert.match(els.view.innerHTML, /Cost sheet/); assert.match(els.view.innerHTML, /Receive Payment/);

  app.ACT.bill(); assert.match(els.modal.innerHTML, /New Bill/);
  await els.msave.onclick(); assert.match(els.merr.textContent, /at least one item/);       // empty bill is rejected nicely
  call('bill.create', { patient_id: pid, items: [{ description: 'IPD', rate: 1000000, doctor_id: doc }] });
  await app.openProfile(pid);
  app.ACT.receive(); assert.match(els.modal.innerHTML, /Receive Payment/);
  el('f_pay_type').value = 'FULL'; el('f_mode').value = 'CASH'; el('f_amount').value = '10000'; el('f_pay_date').value = '2026-11-18';
  await els.msave.onclick(); await flush();
  assert.equal(call('patient.profile', pid).finance.due, 0);

  app.ACT.expense(); assert.match(els.modal.innerHTML, /Add Expense/);
  el('f_head_id').value = String(db.get("SELECT id FROM expense_heads WHERE name='Food'").id); el('f_amount').value = '200'; el('f_exp_date').value = '2026-11-18'; el('f_mode').value = 'CASH';
  await els.msave.onclick(); await flush();
  assert.equal(call('patient.profile', pid).finance.direct_cost, 20000 + 200000);               // food + auto doctor share

  app.ACT.refund(); assert.match(els.modal.innerHTML, /Credit Note/);
  app.ACT.alloc(); assert.match(els.modal.innerHTML, /Allocate Fixed Cost/);
  app.ACT.docSave({}); assert.match(els.modal.innerHTML, /Fixed fee/);
  app.ACT.settle({ id: String(doc) }); assert.match(els.modal.innerHTML, /Settle/);
  app.ACT.newPatient(); assert.match(els.modal.innerHTML, /New Patient/);

  await app.SCREENS.accounts(); assert.match(els.view.innerHTML, /Fixed-cost allocations/);
  await app.SCREENS.admin(); assert.match(els.view.innerHTML, /Audit trail/);
  await app.SCREENS.reports();
  for (const r of ['patientPnl', 'dailyCollection', 'outstanding', 'doctorReport', 'overallPnl', 'cashBook', 'balanceSheet']) {
    els.rsel.value = r; await app.ACT.runReport(); assert.match(els.rout.innerHTML, /<table>/, r);
  }
  await app.ACT.xlsx(); await app.ACT.pdf();
});

test('receptionist screen: only Patients menu, no money anywhere', async () => {
  const { call, app } = boot();
  call('user.create', { username: 'rec', full_name: 'Ravi', password: 'rec12345', role: 'RECEPTIONIST' });
  call('auth.logout'); const me = call('auth.login', 'rec', 'rec12345'); call('auth.changePassword', 'rec12345', 'rec12345!'); me.must_change_password = false;
  app.setMe(me); await app.enter();
  assert.doesNotMatch(els.nav.innerHTML, /Reports|Dashboard|Admin|Expenses/);
  const pid = call('patient.create', { name: 'P', patient_type: 'OPD' }).id;
  await app.openProfile(pid);
  assert.doesNotMatch(els.view.innerHTML, /Receive Payment|Cost sheet|Profit/);
  assert.match(els.view.innerHTML, /Accountant \/ Admin only/);
});

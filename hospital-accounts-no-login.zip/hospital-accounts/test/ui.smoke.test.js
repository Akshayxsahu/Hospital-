'use strict';
// Runs renderer/app.js against the REAL backend with a small fake page. The fake page is STRICT: it only knows elements that exist in
// index.html or that the app really rendered, so a reference to a missing element (like the old $('lb') login button) fails here.
// Any use of the browser's confirm()/prompt()/alert() also fails the test (Electron does not support them).
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs'); const path = require('path');
const ids = require('./_ids');
const dbm = require('../src/db'); const auth = require('../src/auth'); const { makeApi } = require('../src/api');

const HTML = fs.readFileSync(path.join(__dirname, '..', 'renderer', 'index.html'), 'utf8');
const APP = fs.readFileSync(path.join(__dirname, '..', 'renderer', 'app.js'), 'utf8');
const flush = () => new Promise((r) => setImmediate(r));

let known, hidden, els0, inputs;
function el(id) {
  if (!els0[id]) {
    let html = '';
    els0[id] = { id, value: '', textContent: '', dataset: {}, style: {}, onclick: null, oninput: null, onchange: null, onkeydown: null,
      get innerHTML() { return html; }, set innerHTML(v) { html = String(v); for (const m of html.matchAll(/\sid="([^"]+)"/g)) known.add(m[1]); },
      classList: { add: (c) => c === 'hide' && hidden.add(id), remove: (c) => c === 'hide' && hidden.delete(id), toggle: (c, f) => { if (c === 'hide') (f ? hidden.add(id) : hidden.delete(id)); }, contains: (c) => c === 'hide' && hidden.has(id) },
      querySelector: () => ({ prepend() {}, focus() {} }), focus() {}, click() { return this.onclick && this.onclick(); }, closest: () => null };
  }
  return els0[id];
}
const getEl = (id) => (known.has(id) ? el(id) : null);
// `els.something` throws if that element was never on the page - a loud failure instead of a silent undefined.
const els = new Proxy({}, { get: (_, id) => { const e = getEl(id); if (!e) throw new Error(`The page has no element #${id}`); return e; } });
// Drive the "lines" tables (bill / expense): the fake finds the inputs inside the box's current HTML.
function lineInputs(box) {
  const out = [...els[box].innerHTML.matchAll(/<(?:input|select)[^>]*data-i="(\d+)"[^>]*data-k="(\w+)"/g)].map((m) => ({ dataset: { i: m[1], k: m[2] }, value: '', oninput: null, onchange: null }));
  inputs[box] = out; return out;
}
const typeIn = (box, i, k, value) => { const e = inputs[box].find((x) => x.dataset.i === String(i) && x.dataset.k === k); assert.ok(e, `no ${k} input on line ${i}`); e.value = String(value); (e.oninput || e.onchange)(); };

function boot() {
  known = new Set([...HTML.matchAll(/\sid="([^"]+)"/g)].map((m) => m[1])); hidden = new Set(['app', 'modalbg', 'dlgbg', 'toast']); els0 = {}; inputs = {};
  const db = dbm.open(':memory:'); auth.ensureAdmin(db, 'admin123');
  const call = makeApi(db, { dataDir: '.', attachDir: '.', backupDir: '.' });
  const sent = [];
  const PRINTERS = [{ name: 'HP LaserJet', isDefault: true }, { name: 'EPSON TM-T82', isDefault: false }];
  global.window = { api: async (n, ...a) => { try { return { ok: true, data: call(n, ...a) }; } catch (e) { return { ok: false, error: e.message, code: e.code, matches: e.matches }; } },
    native: new Proxy({}, { get: (_, k) => async (...a) => { sent.push([k, ...a]); return { ok: true, data: k === 'listPrinters' ? PRINTERS : null }; } }) };
  global.document = { getElementById: getEl, querySelectorAll: (sel) => { const m = /^#(\w+) \[data-k\]$/.exec(sel); return m ? lineInputs(m[1]) : []; }, addEventListener() {}, createElement: () => ({}), activeElement: { tagName: 'BODY' } };
  global.location = { reload() {} };
  global.confirm = () => { throw new Error('native confirm() used'); }; global.prompt = () => { throw new Error('native prompt() used'); }; global.alert = () => { throw new Error('native alert() used'); };
  global.setTimeout = () => 0; global.clearTimeout = () => {};
  delete require.cache[require.resolve('../renderer/app.js')];
  const app = require('../renderer/app.js');
  return { db, call, app, sent };
}
const head = (db, name) => db.get('SELECT id FROM expense_heads WHERE name=?', name).id;

test('source guard: no native confirm/prompt/alert, no leftover login elements, every $("id") exists', () => {
  assert.doesNotMatch(APP.replace(/\/\/.*$/gm, ''), /(?<![\w.])(confirm|prompt|alert)\(/, 'native browser dialogs are not supported in Electron');
  for (const m of APP.matchAll(/\$\('([\w-]+)'\)/g)) {
    const id = m[1];
    if (/^(f_|d_)/.test(id)) continue;                              // form fields are generated from field lists (f_<key>)
    assert.ok(HTML.includes(`id="${id}"`) || APP.includes(`id="${id}"`) || APP.includes(`id=\\"${id}\\"`), `$('${id}') refers to an element that is never created`);
  }
  assert.doesNotMatch(APP, /\$\('(lb|lp|lu|cb|out|cp|np)'\)/);
});

test('UI renders every screen and a bill + payment can be saved through the forms (no login)', async () => {
  const { db, call, app, sent } = boot();
  await app.enter();
  assert.match(els.view.innerHTML, /Billing/); assert.match(els.nav.innerHTML, /Reports/);
  const doc = call('doctor.save', { name: 'Dr. Sharma', percent_bp: 2000 }).id;
  await app.SCREENS.doctors(); assert.match(els.view.innerHTML, /Dr\. Sharma/); assert.match(els.view.innerHTML, /To add a doctor: click/);
  const pid = call('patient.create', { name: 'Patient A', patient_type: 'IPD', doctor_id: doc, bed_no: 'B-7', ...ids.id() }).id;
  await app.SCREENS.patients(); assert.match(els.view.innerHTML, /Patient A/);
  await app.openProfile(pid);
  assert.match(els.view.innerHTML, /Cost sheet/); assert.match(els.view.innerHTML, /Receive Payment/);
  assert.match(els.view.innerHTML, /Bed No\.: [^<]*B-7/); assert.doesNotMatch(els.view.innerHTML, /Room/);

  app.ACT.bill(); assert.match(els.modal.innerHTML, /New Bill/);
  await els.msave.onclick(); assert.match(els.merr.textContent, /at least one item/);
  call('bill.create', { patient_id: pid, items: [{ description: 'IPD', rate: 1000000, doctor_id: doc }] });
  await app.openProfile(pid);
  app.ACT.receive(); assert.match(els.modal.innerHTML, /Receive Payment/);
  els.f_pay_type.value = 'FULL'; els.f_mode.value = 'CASH'; els.f_amount.value = '10000'; els.f_pay_date.value = '2026-11-18';
  const saving = els.msave.onclick(); await flush();                 // after saving, the Print / Save-as-PDF chooser opens
  assert.match(els.dlg.innerHTML, /Save as PDF/);
  await els.dlg_pdf.onclick(); await flush();
  assert.deepEqual(sent.find((x) => x[0] === 'printDoc').slice(1, 3).concat(sent.find((x) => x[0] === 'printDoc')[4]), ['receipt', 1, 'PDF']);
  await saving;
  assert.equal(call('patient.profile', pid).finance.due, 0);

  app.ACT.refund(); assert.match(els.modal.innerHTML, /Credit Note/);
  app.ACT.alloc(); assert.match(els.modal.innerHTML, /Allocate Fixed Cost/); assert.match(els.modal.innerHTML, /id="f_head_id"/);
  app.ACT.docSave({}); assert.match(els.modal.innerHTML, /Fixed fee/);
  app.ACT.settle({ id: String(doc) }); assert.match(els.modal.innerHTML, /Settle/);

  await app.SCREENS.accounts(); assert.match(els.view.innerHTML, /Fixed-cost allocations/);
  await app.SCREENS.admin(); assert.match(els.view.innerHTML, /Audit trail/); assert.match(els.view.innerHTML, /Printers/);
  await app.SCREENS.reports();
  for (const r of ['patientPnl', 'dailyCollection', 'outstanding', 'doctorReport', 'overallPnl', 'cashBook', 'balanceSheet']) {
    els.rsel.value = r; els.rsel.onchange(); await app.ACT.runReport(); assert.match(els.rout.innerHTML, /<table>/, r);
  }
  await app.ACT.xlsx(); await app.ACT.pdf(); await app.ACT.printRep();
  assert.ok(sent.some((x) => x[0] === 'printDoc' && x[1] === 'report' && x[4] === 'PRINT'), JSON.stringify(sent.map((x) => x.slice(0, 5))));
});

test('new patient: Bed No., mandatory Aadhar / Ayushman ID, quick "+ Add new doctor"', async () => {
  const { call, app } = boot();
  await app.enter();
  app.ACT.newPatient();
  const m = els.modal.innerHTML;
  assert.match(m, /Bed No\./); assert.doesNotMatch(m, /Room No/); assert.match(m, /ID proof \*/); assert.match(m, /ID number[^<]*\*/); assert.match(m, /Ayushman card/);
  els.f_name.value = 'Ramu'; els.f_patient_type.value = 'OPD';
  await els.msave.onclick(); assert.match(els.merr.textContent, /Choose the ID proof/);                 // ID proof is mandatory
  els.f_id_type.value = 'AADHAR'; els.f_id_number.value = '12345';
  await els.msave.onclick(); assert.match(els.merr.textContent, /12 digits/);
  els.f_id_number.value = '123456789012'; els.f_bed_no.value = 'A-3';
  await els.msave.onclick(); await flush();
  const p1 = call('patient.search', 'Ramu')[0]; assert.ok(p1);
  const full = call('patient.profile', p1.id).patient;
  assert.deepEqual([full.id_type, full.aadhar, full.bed_no], ['AADHAR', '123456789012', 'A-3']);
  assert.match(els.view.innerHTML, /Aadhar 123456789012/);

  app.ACT.newPatient();                                                                       // Ayushman path + quick add doctor
  els.f_name.value = 'Sita'; els.f_patient_type.value = 'IPD'; els.f_id_type.value = 'AYUSHMAN'; els.f_id_number.value = 'ab-1234 5678';
  const adding = els.adddoc.onclick(); await flush();
  assert.match(els.dlg.innerHTML, /Add doctor/);
  await els.dlg_ok.onclick(); assert.match(els.derr.textContent, /Doctor name is required/);     // dialog keeps required fields
  els.d_name.value = 'Dr. Quick'; els.d_percent.value = '10';
  await els.dlg_ok.onclick(); await adding; await flush();
  assert.match(els.f_doctor_id.innerHTML, /Dr\. Quick/); assert.equal(call('masters.list').doctors.some((d) => d.name === 'Dr. Quick' && d.percent_bp === 1000), true);
  els.f_doctor_id.value = String(call('masters.list').doctors.find((d) => d.name === 'Dr. Quick').id);
  await els.msave.onclick(); await flush();
  const p2 = call('patient.profile', call('patient.search', 'Sita')[0].id).patient;
  assert.deepEqual([p2.id_type, p2.ayushman_id, p2.doctor_name], ['AYUSHMAN', 'AB-12345678', 'Dr. Quick']);
});

test('discharge works without prompt(): date dialog, then discharge slip print / PDF', async () => {
  const { call, app, sent } = boot();
  await app.enter();
  const pid = call('patient.create', { name: 'Gopal', patient_type: 'IPD', admission_date: '2026-11-10', bed_no: 'W-2', ...ids.id() }).id;
  await app.openProfile(pid);
  assert.match(els.view.innerHTML, /data-act="discharge"/);
  const run = app.ACT.discharge(); await flush();
  assert.match(els.dlg.innerHTML, /Discharge date/);
  els.d_date.value = '2026-11-14'; await els.dlg_ok.onclick(); await flush();
  assert.equal(call('patient.profile', pid).patient.status, 'DISCHARGED');
  assert.match(els.dlg.innerHTML, /discharge slip/i);                                         // asks to print the slip
  await els.dlg_yes.onclick(); await flush();
  assert.match(els.dlg.innerHTML, /Save as PDF/);
  await els.dlg_pdf.onclick(); await flush(); await run;
  assert.deepEqual(sent.filter((x) => x[0] === 'printDoc')[0].slice(1, 5), ['discharge', pid, 'A4', 'PDF']);
  assert.match(els.view.innerHTML, /Discharge slip/);                                          // button remains for re-printing
  const slip = call('print.discharge', pid, 'A4');
  assert.match(slip, /DISCHARGE SLIP/); assert.match(slip, /Gopal/); assert.match(slip, /W-2/); assert.match(slip, /2026-11-14/);
});

test('expense lines: several lines in one entry, no vendor field, doctor only for Doctor Fee', async () => {
  const { db, call, app } = boot();
  await app.enter();
  const doc = call('doctor.save', { name: 'Dr. S', percent_bp: 0 }).id;
  const pid = call('patient.create', { name: 'P', patient_type: 'IPD', doctor_id: doc, ...ids.id() }).id;
  await app.openProfile(pid);
  app.ACT.expense();
  assert.match(els.modal.innerHTML, /Add Expense/); assert.match(els.modal.innerHTML, /Add line/); assert.doesNotMatch(els.modal.innerHTML + els.xlines.innerHTML, /Vendor|Shop/);
  assert.match(els.xlines.innerHTML, /data-k="doctor_id" disabled/);                           // no doctor until Doctor Fee is chosen
  await els.msave.onclick(); assert.match(els.merr.textContent, /at least one expense line/);   // blank row ignored
  typeIn('xlines', 0, 'head_id', head(db, 'Doctor Fee'));
  assert.doesNotMatch(els.xlines.innerHTML, /data-k="doctor_id" disabled/);
  typeIn('xlines', 0, 'amount', '500'); typeIn('xlines', 0, 'description', 'Round visit');
  await els.addxline.onclick();
  typeIn('xlines', 1, 'head_id', head(db, 'Food')); typeIn('xlines', 1, 'amount', '200');
  assert.match(els.x_total.textContent, /700\.00/);
  const saving = els.msave.onclick(); await flush();
  assert.match(els.dlg.innerHTML, /first line/);                                               // attach question mentions the first line
  await els.dlg_no.onclick(); await saving;
  const rows = call('patient.profile', pid).expenses;
  assert.equal(rows.length, 2);
  assert.deepEqual(rows.map((r) => [r.head, r.amount, r.doctor_id]), [['Doctor Fee', 50000, doc], ['Food', 20000, null]]);
});

test('void asks the reason in the app dialog; Printers screen lists installed printers and saves the choice', async () => {
  const { call, app, sent } = boot();
  await app.enter();
  const pid = call('patient.create', { name: 'P', patient_type: 'OPD', ...ids.id() }).id;
  call('payment.create', { patient_id: pid, pay_type: 'ADVANCE', mode: 'UPI', amount: 5000 });
  await app.openProfile(pid);
  const v = app.ACT.void({ t: 'payments', id: '1' }); await flush();
  assert.match(els.dlg.innerHTML, /Reason for voiding/);
  await els.dlg_ok.onclick(); assert.match(els.derr.textContent, /required/);
  els.d_text.value = 'Entered twice'; await els.dlg_ok.onclick(); await v;
  assert.equal(call('patient.profile', pid).finance.net_received, 0);

  await app.SCREENS.admin();
  const pr = app.ACT.printers(); await pr;
  assert.match(els.modal.innerHTML, /HP LaserJet/); assert.match(els.modal.innerHTML, /EPSON TM-T82/); assert.match(els.modal.innerHTML, /Add device/);
  els.f_printer_a4.value = 'HP LaserJet'; els.f_printer_thermal.value = 'EPSON TM-T82';
  await els.msave.onclick(); await flush();
  const st = call('settings.get'); assert.deepEqual([st.printer_a4, st.printer_thermal], ['HP LaserJet', 'EPSON TM-T82']);
  await app.ACT.printers(); await els.prnwin.onclick(); assert.ok(sent.some((x) => x[0] === 'openPrinterSettings'));
});

test('dashboard calendar: month grid with daily figures; clicking a day shows that day', async () => {
  const { call, app } = boot();
  await app.enter();
  const pid = call('patient.create', { name: 'P', patient_type: 'IPD', admission_date: '2026-11-18', ...ids.id() }).id;
  call('bill.create', { patient_id: pid, bill_date: '2026-11-18', items: [{ description: 'Room', rate: 1000000 }] });
  call('expense.create', { patient_id: pid, head_id: 3, exp_date: '2026-11-18', amount: 250000 });
  await app.ACT.calPick({ d: '2026-11-18' });
  const h = els.view.innerHTML;
  assert.match(h, /<table class="cal">/); assert.match(h, /November 2026/); assert.match(h, /data-act="calPick" data-d="2026-11-18"/);
  assert.match(h, /\+10k/); assert.match(h, /-2\.5k/);                                          // billed +10k, expense -2.5k on the 18th
  assert.match(h, /18 November 2026/); assert.match(h, /₹10,000\.00/);                          // the day's billing tile
  await app.ACT.calNext(); assert.match(els.view.innerHTML, /December 2026/);
  await app.ACT.calPrev(); await app.ACT.calPrev(); assert.match(els.view.innerHTML, /October 2026/);
});

test('receptionist screen: only Patients menu, no money anywhere', async () => {
  const { call, app } = boot();
  call('user.create', { username: 'rec', full_name: 'Ravi', password: 'rec12345', role: 'RECEPTIONIST' });
  const me = call('auth.login', 'rec', 'rec12345'); me.must_change_password = false;
  app.setMe(me); await app.enter();
  assert.doesNotMatch(els.nav.innerHTML, /Reports|Dashboard|Admin|Expenses/);
  const pid = call('patient.create', { name: 'P', patient_type: 'OPD', ...ids.id() }).id;
  await app.openProfile(pid);
  assert.doesNotMatch(els.view.innerHTML, /Receive Payment|Cost sheet|Profit/);
  assert.match(els.view.innerHTML, /Accountant \/ Admin only/);
});

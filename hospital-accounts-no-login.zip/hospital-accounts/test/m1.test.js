'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const ids = require('./_ids');
const dbm = require('../src/db');
const auth = require('../src/auth');
const { makeApi } = require('../src/api');
const patients = require('../src/patients');

function setup() {
  const db = dbm.open(':memory:');
  auth.ensureAdmin(db, 'admin123');
  const call = makeApi(db);
  call('auth.login', 'admin', 'admin123');
  call('auth.changePassword', 'admin123', 'Secret@1');
  call('user.create', { username: 'reception', full_name: 'Ravi', password: 'recep123', role: 'RECEPTIONIST' });
  call('user.create', { username: 'acct', full_name: 'Anita', password: 'acct1234', role: 'ACCOUNTANT' });
  call('auth.logout');
  return { db, call };
}
const loginAs = (call, u, p) => { call('auth.login', u, p); call('auth.changePassword', p, p + 'x'); };
const patientA = { name: 'Patient A', age: 45, gender: 'M', mobile: '9876543210', patient_type: 'IPD', admission_date: '2026-11-10', id_type: 'AADHAR', aadhar: '111111111111' };

test('single-user mode: no login needed - the app works at once as the local admin', () => {
  const db = dbm.open(':memory:'); auth.ensureAdmin(db, 'admin123');
  const call = makeApi(db);                                          // nobody logs in
  assert.equal(call.session().role, 'ADMIN');
  assert.deepEqual(call('patient.search', 'x'), []);
  assert.ok(call('patient.create', { name: 'No login needed', patient_type: 'OPD', ...ids.id() }).uhid);
  assert.throws(() => call('auth.login', 'admin', 'wrong'), /Wrong username/);   // the login API still refuses a wrong password
});

test('patient IDs are sequential PAT-YYYY-NNNN and restart each year', () => {
  const { db, call } = setup();
  loginAs(call, 'reception', 'recep123');
  const a = patients.create(db, { id: 1, role: 'ADMIN' }, { ...patientA, mobile: '9000000001', aadhar: ids.aadhar() }, { now: new Date('2026-03-01') });
  const b = patients.create(db, { id: 1, role: 'ADMIN' }, { ...patientA, name: 'B', mobile: '9000000002', aadhar: ids.aadhar() }, { now: new Date('2026-12-31') });
  const c = patients.create(db, { id: 1, role: 'ADMIN' }, { ...patientA, name: 'C', mobile: '9000000003', aadhar: ids.aadhar() }, { now: new Date('2027-01-01') });
  assert.deepEqual([a.uhid, b.uhid, c.uhid], ['PAT-2026-0001', 'PAT-2026-0002', 'PAT-2027-0001']);
});

test('validation + duplicate mobile warning (can be overridden)', () => {
  const { call } = setup();
  loginAs(call, 'reception', 'recep123');
  assert.throws(() => call('patient.create', { name: '', patient_type: 'OPD' }), /name is required/);
  assert.throws(() => call('patient.create', { name: 'X', patient_type: 'OPD', mobile: '123' }), /10 digits/);
  assert.throws(() => call('patient.create', { name: 'X', patient_type: 'OPD', aadhar: '12' }), /12 digits/);
  call('patient.create', patientA);
  assert.throws(() => call('patient.create', { ...patientA, name: 'Twin' }), (e) => e.code === 'DUPLICATE');
  assert.ok(call('patient.create', { ...patientA, name: 'Twin' }, { allowDuplicate: true }).uhid);
});

test('search by UHID, name, mobile, aadhar', () => {
  const { call } = setup();
  loginAs(call, 'reception', 'recep123');
  call('patient.create', { ...patientA, name: 'Ramesh Kumar', aadhar: '123456789012' });
  call('patient.create', { ...patientA, name: 'Sita Devi', mobile: '9111111111', aadhar: ids.aadhar() });
  const year = new Date().getFullYear();
  assert.equal(call('patient.search', `PAT-${year}-0001`)[0].name, 'Ramesh Kumar');
  assert.equal(call('patient.search', '0002')[0].name, 'Sita Devi');
  assert.equal(call('patient.search', 'ramesh')[0].uhid, `PAT-${year}-0001`);
  assert.equal(call('patient.search', '98765')[0].name, 'Ramesh Kumar');
  assert.equal(call('patient.search', '1234567890')[0].name, 'Ramesh Kumar');
  assert.equal(call('patient.search', '100%').length, 0);          // wildcard characters are not special
});

test('roles: receptionist adds patients but sees NO money; accountant sees finance', () => {
  const { db, call } = setup();
  loginAs(call, 'reception', 'recep123');
  const { id } = call('patient.create', patientA);
  const r = call('patient.profile', id);
  assert.equal(r.finance, undefined);
  assert.throws(() => call('user.create', {}), /Not allowed/);
  assert.throws(() => call('audit.forRecord', 'patients', id), /Not allowed/);
  call('auth.logout');
  loginAs(call, 'acct', 'acct1234');
  const f = call('patient.profile', id).finance;
  assert.equal(f.profit, 0); assert.equal(f.due, 0);
  assert.throws(() => call('user.list'), /Not allowed/);
});

test('Patient A profile shows billed/received/cost/profit from the views', () => {
  const { db, call } = setup();
  loginAs(call, 'acct', 'acct1234');
  const { id } = call('patient.create', patientA);
  db.exec(`INSERT INTO bills(bill_no,patient_id,bill_date,subtotal,total) VALUES ('B1',${id},'2026-11-14',1000000,1000000);
           INSERT INTO payments(receipt_no,patient_id,pay_date,pay_type,mode,amount) VALUES ('R1',${id},'2026-11-14','FULL','CASH',1000000);
           INSERT INTO patient_expenses(patient_id,head_id,exp_date,amount) VALUES (${id},1,'2026-11-14',200000),(${id},3,'2026-11-14',20000),(${id},4,'2026-11-14',150000),(${id},5,'2026-11-14',150000);
           INSERT INTO patient_expenses(patient_id,head_id,exp_date,amount,source) VALUES (${id},10,'2026-11-14',300000,'ALLOCATED');`);
  const f = call('patient.profile', id).finance;
  assert.deepEqual([f.net_received, f.total_cost, f.profit, f.due], [1000000, 820000, 180000, 0]);
});

test('audit trail records who created / edited; unchanged edits are not logged', () => {
  const { call } = setup();
  loginAs(call, 'reception', 'recep123');
  const { id } = call('patient.create', patientA);
  assert.equal(call('patient.update', id, { bed_no: 'S-12' }).changed, 1);
  assert.equal(call('patient.update', id, { bed_no: 'S-12' }).changed, 0);
  call('auth.logout');
  call('auth.login', 'admin', 'Secret@1');
  const log = call('audit.forRecord', 'patients', id);
  assert.deepEqual(log.map(l => [l.username, l.action]), [['reception', 'CREATE'], ['reception', 'UPDATE']]);
  assert.equal(JSON.parse(log[1].new_json).bed_no, 'S-12');
});

test('failed save rolls back completely (no half-written patient, no skipped number)', () => {
  const { db } = setup();
  const admin = { id: 1, role: 'ADMIN' };
  assert.throws(() => patients.create(db, { id: 999, role: 'ADMIN' }, patientA));   // bad user id -> FK error
  assert.equal(db.get('SELECT COUNT(*) n FROM patients').n, 0);
  assert.equal(patients.create(db, admin, patientA).uhid.endsWith('0001'), true);
});

test('search is fast with 20,000 patients (< 100 ms; target is 1 s)', () => {
  const { db } = setup();
  db.tx(() => {
    const ins = db.raw.prepare("INSERT INTO patients(uhid,name,mobile,aadhar,patient_type,admission_date) VALUES (?,?,?,?,'OPD','2026-01-01')");
    for (let i = 1; i <= 20000; i++) ins.run(`PAT-2026-${String(i).padStart(5, '0')}`, `Patient Name ${i}`, String(9000000000 + i), String(100000000000 + i));
  });
  for (const q of ['Name 19999', '9000015000', '10000000500', 'PAT-2026-12345']) {
    const t = performance.now(); const r = patients.search(db, q); const ms = performance.now() - t;
    console.log(`  search "${q}" -> ${r.length} rows in ${ms.toFixed(1)} ms`);
    assert.ok(r.length > 0 && ms < 100, `${q} took ${ms}`);
  }
});

'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs'); const os = require('os'); const path = require('path');
const dbm = require('../src/db'); const auth = require('../src/auth'); const { makeApi } = require('../src/api');

function boot() {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'api-'));
  const db = dbm.open(':memory:'); auth.ensureAdmin(db, 'admin123');
  const call = makeApi(db, { dataDir: dir, attachDir: path.join(dir, 'att'), backupDir: path.join(dir, 'bk') });
  call('auth.login', 'admin', 'admin123'); call('auth.changePassword', 'admin123', 'Secret@1');
  call('user.create', { username: 'rec', full_name: 'R', password: 'rec12345', role: 'RECEPTIONIST' });
  call('user.create', { username: 'acc', full_name: 'A', password: 'acc12345', role: 'ACCOUNTANT' });
  call('auth.logout');
  return { db, call };
}
const as = (call, u, p) => { call('auth.login', u, p); call('auth.changePassword', p, p + '!'); };

test('full flow through the API as Accountant; receptionist and accountant limits enforced', () => {
  const { call } = boot();
  as(call, 'rec', 'rec12345');
  const pid = call('patient.create', { name: 'Patient A', patient_type: 'IPD' }).id;
  for (const [m, args] of [['bill.create', [{}]], ['payment.create', [{}]], ['expense.create', [{}]], ['dashboard', []], ['report.run', ['patientPnl']], ['backup.now', []], ['void', ['bills', 1, 'x']], ['print.receipt', [1]], ['doctor.save', [{ name: 'x' }]]])
    assert.throws(() => call(m, ...args), /Not allowed/, m);
  assert.ok(call('masters.list').wards.length >= 4);                  // receptionist can pick doctor/ward
  call('auth.logout'); as(call, 'acc', 'acc12345');
  const doc = call('doctor.save', { name: 'Dr. S', percent_bp: 2000 }).id;
  call('bill.create', { patient_id: pid, items: [{ description: 'IPD', rate: 1000000, doctor_id: doc }] });
  call('payment.create', { patient_id: pid, pay_type: 'FULL', mode: 'CASH', amount: 1000000 });
  const prof = call('patient.profile', pid);
  assert.equal(prof.finance.due, 0); assert.equal(prof.payments.length, 1);
  assert.match(call('print.receipt', 1, 'THERMAL'), /RECEIPT/);
  assert.throws(() => call('void', 'payments', 1, 'oops'), /Not allowed/);        // only admin can void
  assert.throws(() => call('user.list'), /Not allowed/);
  assert.equal(call('dashboard').collection, 1000000);
  assert.equal(call('report.run', 'balanceSheet').balanced, true);
});

test('admin: void, audit viewer, settings, backup, disable user', () => {
  const { call } = boot();
  as(call, 'acc', 'acc12345');
  const pid = call('patient.create', { name: 'P', patient_type: 'OPD' }).id;
  call('payment.create', { patient_id: pid, pay_type: 'ADVANCE', mode: 'UPI', amount: 5000 });
  call('auth.logout'); call('auth.login', 'admin', 'Secret@1');
  call('void', 'payments', 1, 'Entered twice');
  const log = call('audit.list', { action: 'VOID' });
  assert.equal(log.length, 1); assert.equal(log[0].username, 'admin');
  assert.equal(call('patient.profile', pid).finance.net_received, 0);
  call('settings.set', { hospital_name: 'City Care' });
  assert.equal(call('settings.get').hospital_name, 'City Care');
  assert.ok(fs.existsSync(call('backup.now').file));
  assert.equal(call('backup.list').length, 1);
  const uid = call('user.list').find((u) => u.username === 'acc').id;
  call('user.setActive', uid, false);
  call('auth.logout');
  assert.throws(() => call('auth.login', 'acc', 'acc12345!'), /Wrong username/);
  call('auth.login', 'admin', 'Secret@1');
  assert.throws(() => call('user.setActive', 1, false), /yourself/);
  call('account.setOpening', 1, 5000000);
});

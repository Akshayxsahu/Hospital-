// Loaded by every test (through _ids.js). The installed app uses better-sqlite3, which is stricter than node:sqlite about query values;
// this makes the test database behave the same way so such bugs fail here and not on the hospital PC.
// Emulates better-sqlite3 at the DRIVER boundary: numbered ?N are "named" (positional values rejected); bare ? count must match exactly.
const { DatabaseSync } = require('node:sqlite');
const prep = DatabaseSync.prototype.prepare;
DatabaseSync.prototype.prepare = function (sql) {
  const st = prep.call(this, sql);
  const s = sql.replace(/'(?:[^']|'')*'/g, "''");
  const bare = (s.replace(/\?\d+/g, '').match(/\?/g) || []).length, numbered = /\?\d/.test(s);
  for (const k of ['run', 'get', 'all']) {
    const f = st[k].bind(st);
    st[k] = (...a) => { if (numbered && a.length) throw new Error('Too many parameter values were provided (numbered ?N): ' + sql.replace(/\s+/g, ' ').slice(0, 90)); if (!numbered && a.length !== bare) throw new Error(`Too many/few parameter values: ${a.length} vs ${bare}: ` + sql.replace(/\s+/g, ' ').slice(0, 90)); return f(...a); };
  }
  return st;
};

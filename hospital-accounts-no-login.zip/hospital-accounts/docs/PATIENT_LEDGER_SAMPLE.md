# Sample Patient Ledger — Patient A

Generated from `demo_patient_a.sql` (numbers verified against `v_patient_financials`).

```
┌─ PATIENT PROFILE ───────────────────────────────────────────────────────────────┐
│ ID: PAT-2026-0001      Name: Patient A         Age/Sex: 45 / M                  │
│ Mobile: 98765 43210    Doctor: Dr. Sharma      Type: IPD                        │
│ Ward / Bed No.: Semi-Private / S-12                 Status: DISCHARGED               │
│ Admitted: 10-Nov-2026                          Discharged: 14-Nov-2026          │
├─────────────────────────────────────────────────────────────────────────────────┤
│  BILLED          RECEIVED         DUE            TOTAL COST       PROFIT        │
│  ₹10,000         ₹10,000          ₹0             ₹8,200           ₹1,800 ▲      │
└─────────────────────────────────────────────────────────────────────────────────┘
[Ledger]  [Expenses / Cost Sheet]  [Documents]  [Audit]        [F4 Bill][F5 Receive][F6 Expense]
```

## Tab 1 — Ledger (money in)

| Date | Ref | Particulars | Mode | Billed (Dr) | Received (Cr) | Balance Due |
|---|---|---|---|---:|---:|---:|
| 10-Nov | RCP-2026-0001 | Advance | Cash | | 5,000 | −5,000 *(advance held)* |
| 12-Nov | RCP-2026-0002 | Part payment | UPI | | 3,000 | −8,000 |
| 14-Nov | BILL-2026-0001 | IPD package (4 days) | — | 10,000 | | 2,000 |
| 14-Nov | RCP-2026-0003 | Final payment | Cash | | 2,000 | **0** |
| | | **Total** | | **10,000** | **10,000** | **0 ✔ Fully paid** |

## Tab 2 — Expenses / Cost Sheet (money out)

| Date | Head | Description | Source | Amount | 📎 |
|---|---|---|---|---:|:-:|
| 14-Nov | Doctor Fee | Dr. Sharma | Auto (from doctor fee) | 2,000 | |
| 14-Nov | Food | 4 days | Manual | 200 | |
| 13-Nov | Medicine / Pharmacy | Pharmacy bill | Manual | 1,500 | 📎 |
| 11-Nov | Pathology / Lab | Lab tests | Manual | 1,500 | 📎 |
| 14-Nov | Other Fixed Cost | Monthly overhead share | Allocated | 3,000 | |
| | | **Total Cost** | | **8,200** | |
| | | *(Direct 5,200 + Overhead 3,000)* | | | |

## Profit summary box (bottom of the profile)

```
   Total Received (net of refunds)      ₹ 10,000
 − Total Cost                           ₹  8,200
 ─────────────────────────────────────────────
   PROFIT                               ₹  1,800   (18.0% margin)
```

If a refund of ₹500 were entered later, Received becomes ₹9,500 and Profit drops to ₹1,300 automatically. If another ₹500 expense were added, Total Cost and Profit update the same way — nothing is typed manually.

## Side effect: Doctor payable (Doctors screen)

| Doctor | Earned | Paid | Payable |
|---|---:|---:|---:|
| Dr. Sharma | 2,000 | 0 | **2,000** → [Settle] |

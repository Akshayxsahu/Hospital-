# Step-by-step: from this ZIP to a working Windows app using GitHub

You do **not** need to know programming. Two parts: **(A) put the files on GitHub**, **(B) let GitHub build the installer for you** (you just download an `.exe`).

## Part A — Put the project on GitHub (browser only, easiest)

1. **Create a GitHub account** (skip if you have one): open https://github.com → *Sign up*.
2. **Unzip** `hospital-accounts-final.zip` on your computer (right-click → *Extract All*). You will get a folder `hospital-accounts` containing `src`, `renderer`, `db`, `test`, `docs`, `.github`, `package.json`, `README.md` …
3. On GitHub click the **＋** (top-right) → **New repository**.
4. Repository name: `hospital-accounts`. Select **Private** (strongly recommended — it is your business software). Tick nothing else. Click **Create repository**.
5. On the new empty repository page click the link **“uploading an existing file”**.
6. Open the extracted `hospital-accounts` folder, **select everything inside it** (Ctrl+A) and **drag it into the GitHub page**. Folders upload together with their files. Wait until the progress bars finish.
   - Make sure the `.github` folder is included (it holds the automatic build instructions). If you cannot see it in Windows Explorer, it is simply listed first/last — it is not hidden.
   - GitHub allows 100 files per drag. This project has about 40 files, so one upload is enough.
7. Scroll down, in *Commit changes* leave **“Commit directly to the main branch”** → click **Commit changes**.

✅ Your code is now safely stored on GitHub, with history.

## Part B — Get the Windows installer (GitHub builds it for you)

1. In your repository click the **Actions** tab. If GitHub asks, click **“I understand my workflows, enable them”**.
2. You will see a run named **“Test and build Windows installer”** starting automatically (yellow dot = running, green tick = done, red cross = failed). It takes about 5–10 minutes.
   - If it did not start: click that workflow name on the left → **Run workflow** → **Run workflow**.
3. When it shows a **green tick**, click the run → scroll to **Artifacts** → click **Hospital-Accounts-Setup** → a ZIP downloads. Unzip it: inside is **`Hospital Accounts Setup 1.0.0.exe`**.
4. Copy that `.exe` to the hospital computer (laptop or desktop) and double-click to install. Windows may show *“Windows protected your PC”* because the app is not commercially signed → click **More info → Run anyway**.
5. Open **Hospital Accounts** from the desktop shortcut.
   **First login:** username `admin`, password `admin123` → the app forces you to set a new password immediately.

> The 34 automated tests run before every build. If a test fails, the installer is **not** built — so you never get a broken version.

### First-time setup inside the app (5 minutes)
1. **Admin → Hospital settings → Edit**: hospital name, address, phone (and optional logo path) — printed on every receipt.
2. **Admin → Opening cash / bank balance**: enter today's cash in hand and bank balance (only possible before the first entry).
3. **Doctors & Staff**: add doctors (fixed fee and/or % share) and staff salaries.
4. **Admin → Add user**: create a Receptionist and an Accountant login.
5. Press **F2** and register the first patient.

## Part C — Giving it a version number (optional, for releases)
When you want a clean download link: GitHub → **Releases → Create a new release** → type a tag such as `v1.0.0` → **Publish**. The build runs again and attaches the installer to that release page.

## Part D — Updating the software later
1. Get the new files (from me / your developer).
2. In your repository click **Add file → Upload files**, drag the changed files (same folder names), **Commit changes**.
3. Wait for the green tick in **Actions**, download the new installer, and install it **over** the old one. Your data is stored separately (in `C:\Users\<you>\AppData\Roaming\hospital-accounts\data`) and is **not** touched by updates.

## Part E — Alternative: run directly on a computer without GitHub Actions
1. Install **Node.js 22 LTS** from https://nodejs.org.
2. Open the unzipped folder, click the address bar, type `cmd`, press Enter.
3. Type `npm install` (wait), then `npm test` (should say pass 34), then `npm start`.

## Part F — Using GitHub Desktop instead of the browser (if you prefer an app)
1. Install **GitHub Desktop** (https://desktop.github.com) and sign in.
2. *File → Add local repository* → choose the unzipped folder → click **create a repository** if asked.
3. Type a summary like “First version” → **Commit to main** → **Publish repository** (tick *Keep this code private*).
4. Later changes: edit/replace files → Commit → **Push origin**.

## Where is my data? (important)
- Database: `C:\Users\<you>\AppData\Roaming\hospital-accounts\data\hospital.db`
- Automatic daily backups: same place, folder `backups` (last 30 kept).
- Attachments (bills/prescriptions): folder `attachments`.
- **Never** upload `hospital.db` to GitHub (it contains patient data). The project's `.gitignore` already blocks it when you use Git/GitHub Desktop.

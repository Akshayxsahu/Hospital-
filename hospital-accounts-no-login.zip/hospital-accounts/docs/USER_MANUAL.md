# Staff quick guide (10 minutes)

| Who | Can do |
|---|---|
| **Receptionist** | Register / edit / search patients. Cannot see any money. |
| **Accountant** | Everything about money: bills, receipts, expenses, refunds, doctor settlement, salary, reports. Cannot void or manage users. |
| **Admin** | Everything, plus void (with reason), users, settings, backup / restore, audit trail. |

## Daily routine
1. **F2** – New patient → fill name, type, doctor, ward → **Save**. The Patient ID (PAT-2026-0001) is created automatically. If the mobile/Aadhar already exists the software warns you.
2. Search any time in the top box (ID / name / mobile / Aadhar). Press **/** to jump to the box.
3. Open the patient. Keys: **F4 Bill · F5 Receive payment · F6 Expense · F7 Refund / Credit note**.
4. **Advance** when money is taken before the bill. **Part** = less than due. **Full** = exactly the due.
5. After saving a receipt choose **A4** (letterhead) or **Thermal** (80 mm roll).
6. Look at the five boxes on the patient screen: **Billed · Received · Due · Total Cost · Profit/Loss** — nothing is typed manually.
7. At discharge press **Discharge**. When the balance is zero the Admin can **Close file** (no more entries).

## Expenses
- **Per patient (F6):** Doctor Fee, Nursing, Food, Medicine, Pathology, Radiology, OT, Room Rent, Consumables, Other. Add your own head with **+ New expense head**. Use **+ Attach** to store a bill/prescription (PDF or photo).
- **Doctor Fee** is not cash out today — it becomes *payable* to the doctor; pay it from **Doctors & Staff → Settle**.
- **Hospital expenses** (electricity, rent, repairs): *Expenses → + Hospital expense*.
- **Fixed-cost allocation (month end):** *Expenses → Allocate fixed cost to patients* → choose head, total, period, method → **Preview** → **Confirm**. Each patient's cost sheet then shows its overhead share. The same period cannot be allocated twice.

## Mistakes
Nothing is ever deleted. Ask the Admin to press **Void** next to the entry and give a reason; it stays visible in the **Audit trail** (who, when, old value).

## Reports (Reports menu)
Patient-wise P&L (group by date / doctor / ward) · Daily collection · Outstanding dues (ageing) · Doctor-wise · Overall P&L · Cash book / Bank book · Balance sheet. Each has filters and **Export Excel** / **Export PDF**.

## Backup
Automatic every day. Extra copy: **Admin → Backup to Pen Drive** (choose the pen-drive folder). For Google Drive, install *Google Drive for desktop*, then choose a folder inside it. Restore: **Admin → Restore from backup** (old data is kept as a “before-restore” file).

'use strict';
/* Hospital Accounts - screens. Plain JS, no build step. All data comes through call(); money is paise internally, rupees on screen. */
const $ = (id) => document.getElementById(id);
const esc = (s) => String(s ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const rs = (p) => '₹' + ((Number(p) || 0) / 100).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const today = () => { const d = new Date(), p = (n) => String(n).padStart(2, '0'); return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`; };
const cls = (v) => (v < 0 ? 'neg' : v > 0 ? 'pos' : '');
let me = null, M = { doctors: [], wards: [], heads: [], accounts: [], services: [], staff: [] }, cur = { patient: null, screen: 'patients' }, ACT = {};

async function call(name, ...args) {
  const r = await window.api(name, ...args);
  if (!r.ok) { const e = new Error(r.error); e.code = r.code; e.matches = r.matches; throw e; }
  return r.data;
}
async function nat(name, ...args) { const r = await window.native[name](...args); if (!r.ok) throw new Error(r.error); return r.data; }
function toast(msg) { const t = $('toast'); t.textContent = msg; t.classList.remove('hide'); setTimeout(() => t.classList.add('hide'), 3500); }
const guard = (fn) => async (...a) => { try { return await fn(...a); } catch (e) { toast('⚠ ' + e.message); } };
const canFin = () => me && ['ADMIN', 'ACCOUNTANT'].includes(me.role);
const isAdmin = () => me && me.role === 'ADMIN';
const toP = (v) => { if (v === '' || v == null) return undefined; const n = Number(v); if (!isFinite(n) || n < 0) throw new Error('Enter a valid amount'); return Math.round(n * 100); };

// ---------- in-app dialogs ----------
// The browser's confirm()/prompt() are NOT supported in Electron ("prompt() is not supported"), and native pop-ups can leave
// the window with a dead keyboard on Windows. So every question is asked in the app's own dialog layer (#dlgbg) instead.
let dlgDone = null, dlgDefault = null;
function closeDialog(v) { $('dlgbg').classList.add('hide'); const f = dlgDone; dlgDone = null; dlgDefault = null; if (f) f(v); }
const dialogOpen = () => !$('dlgbg').classList.contains('hide');
// buttons: [{ id, label, cls, value | run }]  - `value` closes the dialog with that value, `run` does its own thing.
function dialog(title, bodyHtml, buttons, { def, onOpen } = {}) {
  if (dlgDone) closeDialog(null);                                   // never leave an earlier question hanging
  return new Promise((resolve) => {
    dlgDone = resolve; dlgDefault = def ? 'dlg_' + def : null;
    $('dlg').innerHTML = `<h3>${esc(title)}</h3>${bodyHtml}<p class="err" id="derr"></p><div class="bar">${buttons.map((b) => `<button class="${b.cls || 'sec'}" id="dlg_${b.id}">${esc(b.label)}</button>`).join('')}</div>`;
    $('dlgbg').classList.remove('hide');
    buttons.forEach((b) => { $('dlg_' + b.id).onclick = () => (b.run ? b.run() : closeDialog(b.value)); });
    if (onOpen) onOpen();
    setTimeout(() => { const f = $('dlg').querySelector && $('dlg').querySelector('input,select,textarea'); const t = f || $('dlg_' + buttons[0].id); if (t && t.focus) t.focus(); }, 0);
  });
}
const askConfirm = (msg, { yes = 'Yes', no = 'No', title = 'Please confirm' } = {}) =>
  dialog(title, `<p style="white-space:pre-line">${esc(msg)}</p>`, [{ id: 'yes', label: yes, cls: 'pri', value: true }, { id: 'no', label: no, cls: 'sec', value: false }], { def: 'yes' });
// Resolves with the values, or null if cancelled. Required (req) fields are checked here; errors stay in the dialog.
function askForm(title, specs, okLabel = 'OK', intro = '') {
  return dialog(title, `${intro}<div class="grid g2">${specs.map((f) => fieldHtml(f, 'd_')).join('')}</div>`, [
    { id: 'ok', label: okLabel, cls: 'pri', run: () => {
      try { const v = readFields(specs, 'd_'); const miss = specs.find((x) => x.req && v[x.k] === undefined); if (miss) throw new Error(`${miss.l} is required`); closeDialog(v); }
      catch (e) { $('derr').textContent = e.message; } } },
    { id: 'cancel', label: 'Cancel', cls: 'sec', value: null }], { def: 'ok' });
}
async function askText(title, label, value = '') { const v = await askForm(title, [{ k: 'text', l: label, req: 1, v: value, w: 'full' }]); return v ? v.text : null; }

// Print / Save-as-PDF chooser for a receipt, bill or discharge slip.
function printDialog(kind, id, defFmt = 'A4') {
  const what = { receipt: 'receipt', bill: 'bill', discharge: 'discharge slip' }[kind] || 'document';
  const go = async (dest) => {
    try {
      const r = await nat('printDoc', kind, id, $('pd_fmt').value, dest);
      closeDialog(true);
      if (typeof r === 'string') toast('Saved PDF: ' + r); else if (r === true) toast('Sent to the printer');
    } catch (e) { $('derr').textContent = e.message; }
  };
  return dialog('Print ' + what, `<label>Paper</label><select id="pd_fmt"><option value="A4">A4 (letterhead)</option><option value="THERMAL">Thermal 80 mm roll</option></select>
    <p class="muted">Print sends it to your printer (choose the printer in Admin → Printers). Save as PDF keeps a file you can e-mail or print later.</p>`, [
    { id: 'print', label: '🖨 Print', cls: 'pri', run: () => go('PRINT') },
    { id: 'pdf', label: '💾 Save as PDF', cls: 'pri', run: () => go('PDF') },
    { id: 'close', label: 'Close', cls: 'sec', value: null }], { def: 'print', onOpen: () => { $('pd_fmt').value = defFmt; } });
}

// ---------- generic form + modal helpers ----------
const opts = (list, sel, blank = '-') => `<option value="">${blank}</option>` + list.map(([v, l]) => `<option value="${esc(v)}"${String(v) === String(sel ?? '') ? ' selected' : ''}>${esc(l)}</option>`).join('');
function fieldHtml(f, pre = 'f_') {
  const id = pre + f.k, v = f.v ?? '';
  let inp;
  if (f.t === 'select') inp = `<select id="${id}">${opts(f.o, v, f.blank ?? '-')}</select>`;
  else if (f.t === 'textarea') inp = `<textarea id="${id}" rows="2">${esc(v)}</textarea>`;
  else inp = `<input id="${id}" type="${f.t === 'money' ? 'number' : f.t || 'text'}" ${f.t === 'money' ? 'step="0.01" min="0"' : ''} value="${esc(v)}">`;
  return `<div class="${f.w === 'full' ? 'full' : ''}"><label>${esc(f.l)}${f.req ? ' *' : ''}</label>${inp}</div>`;
}
function readFields(specs, pre = 'f_') {
  const out = {};
  for (const f of specs) {
    let v = $(pre + f.k).value;
    if (f.t === 'money') v = toP(v);
    else if (f.t === 'number' || f.k.endsWith('_id') || f.k === 'qty') v = v === '' ? undefined : Number(v);
    else if (v === '') v = undefined;
    out[f.k] = v;
  }
  return out;
}
function openModal(title, body, onSave, saveLabel = 'Save') {
  $('modal').innerHTML = `<h3>${esc(title)}</h3>${body}<p class="err" id="merr"></p><div class="bar"><button class="pri" id="msave">${esc(saveLabel)}</button><button class="sec" id="mcancel">Cancel</button></div>`;
  $('modalbg').classList.remove('hide');
  $('mcancel').onclick = closeModal;
  $('msave').onclick = async () => { try { await onSave(); } catch (e) { $('merr').textContent = e.message; } };
}
const closeModal = () => $('modalbg').classList.add('hide');
function formModal(title, specs, onSave, label) {
  openModal(title, `<div class="grid g2">${specs.map((f) => fieldHtml(f)).join('')}</div>`, async () => { await onSave(readFields(specs)); closeModal(); }, label);
}

// ---------- generic report/table renderer ----------
function table(columns, rows, totals) {
  const c = (t) => (t === 'money' || t === 'int' ? ' class="r"' : '');
  const f = (v, t) => (t === 'money' ? rs(v) : esc(v ?? ''));
  return `<table><tr>${columns.map((x) => `<th${c(x.type)}>${esc(x.label)}</th>`).join('')}</tr>` +
    rows.map((r) => `<tr>${columns.map((x) => `<td${c(x.type)}>${f(r[x.key], x.type)}</td>`).join('')}</tr>`).join('') +
    (totals ? `<tr class="tot"><td>TOTAL</td>${columns.slice(1).map((x) => `<td${c(x.type)}>${totals[x.key] !== undefined ? f(totals[x.key], x.type) : ''}</td>`).join('')}</tr>` : '') + '</table>' +
    (rows.length ? '' : '<p class="muted">Nothing to show.</p>');
}

// ---------- app shell (direct launch; no login screen) ----------
const show = (id) => ['app'].forEach((x) => $(x).classList.toggle('hide', x !== id));
async function enter() {
  show('app');
  await reloadMasters();
  const s = await call('settings.get'); $('hname').textContent = s.hospital_name || 'Hospital Accounts';
  const items = [['patients', 'Patients']];
  if (canFin()) items.unshift(['dashboard', 'Dashboard']), items.push(['doctors', 'Doctors & Staff'], ['accounts', 'Expenses'], ['reports', 'Reports']);
  if (isAdmin()) items.push(['admin', 'Admin']);
  $('nav').innerHTML = items.map(([k, l]) => `<button data-act="go" data-k="${k}" id="nav_${k}">${l}</button>`).join('');
  await go(canFin() ? 'dashboard' : 'patients');
}
const reloadMasters = async () => { M = await call('masters.list'); };
const SCREENS = {};
async function go(k) {
  cur.screen = k; cur.patient = null;
  if (k === 'dashboard') cal = { ym: null, date: null };
  document.querySelectorAll('#nav button').forEach((b) => b.classList.toggle('on', b.dataset.k === k));
  await SCREENS[k]();
}

// ---------- Dashboard (accrual basis) + calendar ----------
const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
let cal = { ym: null, date: null };
const fmtDay = (d) => { const [y, m, dd] = d.split('-').map(Number); return `${dd} ${MONTHS[m - 1]} ${y}`; };
const short = (p) => { const r = Math.abs(p) / 100, f = (x) => x.toFixed(1).replace(/\.0$/, ''); return (p < 0 ? '-' : '') + (r >= 100000 ? f(r / 100000) + 'L' : r >= 1000 ? f(r / 1000) + 'k' : String(Math.round(r))); };
function calendarHtml(c) {
  const [y, m] = c.ym.split('-').map(Number), first = new Date(y, m - 1, 1).getDay(), n = new Date(y, m, 0).getDate(), t = today();
  const cells = [];
  for (let i = 0; i < first; i++) cells.push('<td class="out"></td>');
  for (let d = 1; d <= n; d++) {
    const key = `${c.ym}-${String(d).padStart(2, '0')}`, x = c.days[key] || {};
    cells.push(`<td class="${key === cal.date ? 'sel' : ''} ${key === t ? 'tod' : ''}" data-act="calPick" data-d="${key}"><span class="dn">${d}</span>${x.billed ? `<span class="b">+${short(x.billed)}</span>` : ''}${x.expense ? `<br><span class="x">-${short(x.expense)}</span>` : ''}</td>`);
  }
  while (cells.length % 7) cells.push('<td class="out"></td>');
  const rows = []; for (let i = 0; i < cells.length; i += 7) rows.push(`<tr>${cells.slice(i, i + 7).join('')}</tr>`);
  return `<div class="month"><button class="sec sm" data-act="calPrev">◀</button><b>${MONTHS[m - 1]} ${y}</b><span><button class="sec sm" data-act="calToday">Today</button> <button class="sec sm" data-act="calNext">▶</button></span></div>
    <table class="cal"><tr>${['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((w) => `<th>${w}</th>`).join('')}</tr>${rows.join('')}</table>
    <p class="muted" style="margin:6px 0 0"><span class="b">+green</span> = billed that day, <span class="x">-red</span> = expenses. Click a day to see its figures.</p>`;
}
SCREENS.dashboard = async () => {
  cal.date = cal.date || today(); cal.ym = cal.ym || cal.date.slice(0, 7);
  const [d, c] = await Promise.all([call('dashboard', cal.date), call('calendar.month', cal.ym)]);
  const isToday = d.date === today(), lbl = isToday ? 'Today' : fmtDay(d.date);
  $('view').innerHTML = `<h3 style="margin-top:0">${isToday ? 'Today — ' : ''}${fmtDay(d.date)}</h3><div class="tiles">
    <div class="tile">${lbl}'s Billing<b>${rs(d.billed)}</b></div><div class="tile">${lbl}'s Collection<b>${rs(d.collection)}</b></div><div class="tile">${lbl}'s Expense<b>${rs(d.expense)}</b></div>
    <div class="tile">${lbl}'s Profit<b class="${cls(d.profit)}">${rs(d.profit)}</b></div><div class="tile">Pending Dues<b class="neg">${rs(d.pending_dues)}</b></div>
    <div class="tile">Patients ${isToday ? 'Today' : 'that day'}<b>${d.patients_today}</b></div></div>
    <div class="tiles"><div class="tile">${MONTHS[Number(d.month.slice(5)) - 1]}: Income<b>${rs(d.month_income)}</b></div><div class="tile">${MONTHS[Number(d.month.slice(5)) - 1]}: Expenses<b>${rs(d.month_expense)}</b></div>
    <div class="tile">${MONTHS[Number(d.month.slice(5)) - 1]}: Profit<b class="${cls(d.month_profit)}">${rs(d.month_profit)}</b></div></div>
    <div class="grid g2"><div class="card" id="calbox">${calendarHtml(c)}</div>
    <div><div class="card"><h4>Latest receipts</h4>${table([{ key: 'receipt_no', label: 'Receipt' }, { key: 'name', label: 'Patient' }, { key: 'mode', label: 'Mode' }, { key: 'amount', label: 'Amount', type: 'money' }], d.recent_receipts)}</div>
    <div class="card"><h4>Highest dues</h4>${table([{ key: 'uhid', label: 'Patient ID' }, { key: 'name', label: 'Name' }, { key: 'due', label: 'Due', type: 'money' }], d.top_dues)}</div></div></div>
    <p class="muted"><b>Accrual basis:</b> income is counted when a bill is made and a cost when it is incurred — not when money moves. “Collection” is cash received (advances and dues are not income until billed). Monthly salaries are counted on the last day of their month. Allocated overhead is not counted twice.</p>`;
};
const calShift = (k) => { const [y, m] = cal.ym.split('-').map(Number), dt = new Date(y, m - 1 + k, 1); cal.ym = `${dt.getFullYear()}-${String(dt.getMonth() + 1).padStart(2, '0')}`; cal.date = cal.ym === today().slice(0, 7) ? today() : cal.ym + '-01'; return SCREENS.dashboard(); };
ACT.calPrev = () => calShift(-1);
ACT.calNext = () => calShift(1);
ACT.calToday = () => { cal = { ym: null, date: null }; return SCREENS.dashboard(); };
ACT.calPick = (d) => { cal.date = d.d; cal.ym = d.d.slice(0, 7); return SCREENS.dashboard(); };

// ---------- Patients: search, form, profile ----------
SCREENS.patients = async () => { $('q').value = ''; await search(''); };
async function search(q) {
  const rows = await call('patient.search', q);
  $('view').innerHTML = `<div class="bar"><button class="pri" data-act="newPatient">+ New Patient (F2)</button></div><div class="card">
    <table><tr><th>Patient ID</th><th>Name</th><th>Age/Sex</th><th>Mobile</th><th>Type</th><th>Admitted</th><th>Status</th></tr>` +
    rows.map((r) => `<tr class="row" data-act="open" data-id="${r.id}"><td>${esc(r.uhid)}</td><td>${esc(r.name)}</td><td>${esc(r.age ?? '')}/${esc(r.gender ?? '')}</td><td>${esc(r.mobile ?? '')}</td><td>${esc(r.patient_type)}</td><td>${esc(r.admission_date)}</td><td><span class="tag">${esc(r.status)}</span></td></tr>`).join('') +
    `</table>${rows.length ? '' : '<p class="muted">No patient found.</p>'}</div>`;
}
const idOf = (p) => (p.id_type === 'AYUSHMAN' ? p.ayushman_id : p.aadhar);
const patientSpecs = (p = {}) => { const t = p.id_type || (p.aadhar ? 'AADHAR' : ''); return [
  { k: 'name', l: 'Patient Name', req: 1, v: p.name }, { k: 'age', l: 'Age', t: 'number', v: p.age },
  { k: 'gender', l: 'Gender', t: 'select', o: [['M', 'Male'], ['F', 'Female'], ['O', 'Other']], v: p.gender },
  { k: 'mobile', l: 'Mobile (10 digits)', v: p.mobile },
  { k: 'id_type', l: 'ID proof', req: 1, t: 'select', o: [['AADHAR', 'Aadhar card'], ['AYUSHMAN', 'Ayushman card']], v: t, blank: '- choose -' },
  { k: 'id_number', l: 'ID number (Aadhar: 12 digits)', req: 1, v: idOf({ ...p, id_type: t }) },
  { k: 'guardian_name', l: 'Guardian Name', v: p.guardian_name },
  { k: 'doctor_id', l: 'Doctor Assigned', t: 'select', o: M.doctors.map((d) => [d.id, d.name]), v: p.doctor_id },
  { k: 'ward_id', l: 'Ward', t: 'select', o: M.wards.map((w) => [w.id, w.name]), v: p.ward_id }, { k: 'bed_no', l: 'Bed No.', v: p.bed_no },
  { k: 'patient_type', l: 'Patient Type', req: 1, t: 'select', o: [['OPD', 'OPD'], ['IPD', 'IPD'], ['EMERGENCY', 'Emergency'], ['DAYCARE', 'Day Care']], v: p.patient_type || 'OPD', blank: '-' },
  { k: 'admission_date', l: 'Admission Date', t: 'date', v: p.admission_date || today() }, { k: 'address', l: 'Address', w: 'full', v: p.address },
]; };
// The screen has ONE "ID number" box; it goes to the Aadhar or the Ayushman column depending on the chosen proof.
function readPatient(specs) {
  const v = readFields(specs), n = v.id_number; delete v.id_number;
  if (v.id_type === 'AADHAR') v.aadhar = n; else if (v.id_type === 'AYUSHMAN') v.ayushman_id = n;
  return v;
}
// "+ Add new doctor" right inside the patient form - no need to leave the form and lose what was typed.
const doctorSpecs = (o = {}) => [{ k: 'name', l: 'Doctor name', req: 1, v: o.name }, { k: 'speciality', l: 'Speciality', v: o.speciality }, { k: 'mobile', l: 'Mobile', v: o.mobile },
  { k: 'fixed_fee', l: 'Fixed fee per visit/day ₹', t: 'money', v: o.fixed_fee ? o.fixed_fee / 100 : '' }, { k: 'percent', l: 'Share of billed items %', t: 'number', v: o.percent_bp ? o.percent_bp / 100 : '' }];
const doctorPayload = (v, id) => ({ id, name: v.name, speciality: v.speciality, mobile: v.mobile, fixed_fee: v.fixed_fee || 0, percent_bp: Math.round((v.percent || 0) * 100) });
const addDoctorBar = '<div class="bar"><button class="sec sm" id="adddoc">+ Add new doctor</button><span class="muted">Not in the list? Add the doctor here.</span></div>';
function wireAddDoctor() {
  $('adddoc').onclick = guard(async () => {
    const v = await askForm('Add doctor', doctorSpecs(), 'Save doctor', '<p class="muted">You can set both. Fixed fee is added as a Doctor Fee expense; the % is booked automatically from bill lines.</p>');
    if (!v) return;
    const r = await call('doctor.save', doctorPayload(v)); await reloadMasters();
    $('f_doctor_id').innerHTML = opts(M.doctors.map((d) => [d.id, d.name]), r.id); toast('Doctor added and selected');
  });
}
ACT.newPatient = () => {
  const specs = patientSpecs();
  const save = async (allow) => {
    try { const r = await call('patient.create', readPatient(specs), { allowDuplicate: allow }); closeModal(); toast('Saved ' + r.uhid); await openProfile(r.id); }
    catch (e) { if (e.code === 'DUPLICATE') { const m = e.matches.map((x) => `${x.uhid} ${x.name}`).join(', '); if (await askConfirm(`Already registered: ${m}\n\nSave as a NEW patient anyway?`, { yes: 'Save as new', no: 'Cancel' })) return save(true); } else throw e; }
  };
  openModal('New Patient', `<div class="grid">${specs.map((f) => fieldHtml(f)).join('')}</div>${addDoctorBar}`, () => save(false), 'Save (Ctrl+S)');
  wireAddDoctor();
};
ACT.editPatient = () => {
  const p = cur.patient, specs = patientSpecs(p);
  openModal('Edit Patient ' + p.uhid, `<div class="grid">${specs.map((f) => fieldHtml(f)).join('')}</div>${addDoctorBar}`,
    async () => { await call('patient.update', p.id, readPatient(specs)); closeModal(); toast('Updated'); await openProfile(p.id); });
  wireAddDoctor();
};
ACT.open = (d) => openProfile(Number(d.id));
async function openProfile(id) {
  cur.screen = 'profile';
  const r = await call('patient.profile', id); const p = r.patient; cur.patient = p; cur.profile = r;
  const f = r.finance, pay = r.payments || [], bills = r.bills || [], ex = r.expenses || [];
  const closed = p.status === 'CLOSED';
  const voidBtn = (t, i) => (isAdmin() ? `<button class="dng sm" data-act="void" data-t="${t}" data-id="${i}">Void</button>` : '');
  const money = f ? `<div class="tiles">
      <div class="tile">Billed<b>${rs(f.net_billed)}</b></div><div class="tile">Received<b>${rs(f.net_received)}</b></div>
      <div class="tile">Due<b class="${f.due > 0 ? 'neg' : ''}">${rs(f.due)}</b></div><div class="tile">Total Cost<b>${rs(f.total_cost)}</b><small class="muted">direct ${rs(f.direct_cost)} + overhead ${rs(f.overhead_cost)}</small></div>
      <div class="tile">Profit / Loss<b class="${cls(f.profit)}">${rs(f.profit)}</b><small class="muted">billed − cost (accrual)</small></div></div>
    ${closed ? '' : `<div class="bar"><button class="pri" data-act="bill">Bill (F4)</button><button class="pri" data-act="receive">Receive Payment (F5)</button><button class="sec" data-act="expense">Add Expense (F6)</button><button class="sec" data-act="refund">Refund / Credit Note (F7)</button></div>`}
    <div class="card"><h4>Bills & receipts (ledger)</h4><table><tr><th>Date</th><th>Ref</th><th>Particulars</th><th class="r">Billed</th><th class="r">Received</th><th></th></tr>
      ${[...bills.map((b) => ({ d: b.bill_date, k: 'b' + b.id, ref: b.bill_no, txt: 'Bill' + (b.discount ? ` (discount ${rs(b.discount)}: ${esc(b.discount_reason)})` : ''), bill: b.total, id: b.id, t: 'bill', kind: 'bills' })),
        ...pay.map((y) => ({ d: y.pay_date, ref: y.receipt_no, txt: `${y.pay_type} - ${y.mode}${y.reference_no ? ' / ' + esc(y.reference_no) : ''}`, rec: y.amount, id: y.id, t: 'receipt', kind: 'payments' }))]
        .sort((a, b) => a.d.localeCompare(b.d)).map((x) => `<tr><td>${x.d}</td><td>${esc(x.ref)}</td><td>${x.txt}</td><td class="r">${x.bill ? rs(x.bill) : ''}</td><td class="r">${x.rec ? rs(x.rec) : ''}</td>
        <td><button class="sec sm" data-act="print" data-t="${x.t}" data-id="${x.id}">🖨 Print / PDF</button> ${voidBtn(x.kind, x.id)}</td></tr>`).join('')}
      <tr class="tot"><td colspan="3">Total</td><td class="r">${rs(f.billed)}</td><td class="r">${rs(f.received)}</td><td></td></tr></table></div>
    <div class="card"><h4>Cost sheet (expenses)</h4><table><tr><th>Date</th><th>Head</th><th>Details</th><th class="r">Amount</th><th>Documents</th><th></th></tr>
      ${ex.map((e) => `<tr><td>${e.exp_date}</td><td>${esc(e.head)}</td><td>${esc(e.description ?? '')} ${e.source === 'ALLOCATED' ? '<span class="tag">overhead</span>' : e.source === 'AUTO_DOCTOR' ? '<span class="tag">auto</span>' : ''}</td><td class="r">${rs(e.amount)}</td>
        <td>${(e.attachments || []).map((a) => `<a href="#" data-act="openAtt" data-p="${esc(a.file_path)}">📎 ${esc(a.file_name)}</a>`).join('<br>')} ${e.source === 'MANUAL' && !closed ? `<button class="sec sm" data-act="attach" data-id="${e.id}">+ Attach</button>` : ''}</td>
        <td>${voidBtn('patient_expenses', e.id)}</td></tr>`).join('') || '<tr><td colspan="6" class="muted">No expenses yet.</td></tr>'}
      <tr class="tot"><td colspan="3">Total cost</td><td class="r">${rs(f.total_cost)}</td><td colspan="2"></td></tr></table></div>`
    : '<p class="muted"><i>Financial details are visible to Accountant / Admin only.</i></p>';
  $('view').innerHTML = `<div class="card"><div class="bar"><button class="sec" data-act="back">← Back</button><button class="sec" data-act="editPatient">Edit</button>
    ${p.status === 'ACTIVE' ? '<button class="sec" data-act="discharge">Discharge</button>' : '<button class="sec" data-act="slip">Discharge slip</button>'}${isAdmin() && !closed ? '<button class="dng" data-act="closeFile">Close file</button>' : ''}</div>
    <h3>${esc(p.uhid)} — ${esc(p.name)} <span class="tag">${esc(p.status)}</span></h3>
    <div class="grid g4"><div>Age/Sex: ${esc(p.age ?? '')} / ${esc(p.gender ?? '')}</div><div>Mobile: ${esc(p.mobile ?? '')}</div><div>Type: ${esc(p.patient_type)}</div><div>Doctor: ${esc(p.doctor_name ?? '')}</div>
    <div>Ward / Bed No.: ${esc(p.ward_name ?? '')} ${esc(p.bed_no ?? '')}</div><div>Admitted: ${esc(p.admission_date)}</div><div>Discharged: ${esc(p.discharge_date ?? '—')}</div><div>Guardian: ${esc(p.guardian_name ?? '')}</div><div>ID: ${p.id_type === 'AYUSHMAN' ? 'Ayushman ' + esc(p.ayushman_id ?? '') : p.aadhar ? 'Aadhar ' + esc(p.aadhar) : '<i class="neg">not recorded - edit to add</i>'}</div></div></div>${money}`;
}
ACT.back = () => go('patients');
ACT.discharge = guard(async () => {
  const p = cur.patient;
  const v = await askForm('Discharge — ' + p.name, [{ k: 'date', l: 'Discharge date', t: 'date', req: 1, v: today() }], 'Discharge');
  if (!v) return;
  await call('patient.discharge', p.id, v.date); await openProfile(p.id); toast('Patient discharged');
  if (await askConfirm('Print the discharge slip now?', { yes: 'Print / Save PDF', no: 'Not now' })) await printDialog('discharge', p.id);
});
ACT.slip = guard(() => printDialog('discharge', cur.patient.id));
ACT.closeFile = guard(async () => {
  if (!(await askConfirm('Close this patient file? No more entries will be possible.', { yes: 'Close file', no: 'Cancel' }))) return;
  try { await call('patient.close', cur.patient.id, false); }
  catch (e) { if (/not zero/.test(e.message) && (await askConfirm(e.message + '\n\nClose anyway?', { yes: 'Close anyway', no: 'Cancel' }))) await call('patient.close', cur.patient.id, true); else throw e; }
  await openProfile(cur.patient.id);
});
ACT.openAtt = guard((d) => nat('openAttachment', d.p));
ACT.attach = guard(async (d) => { const r = await nat('attachFile', Number(d.id)); if (r) { toast('Attached'); await openProfile(cur.patient.id); } });
ACT.print = guard((d) => printDialog(d.t, Number(d.id)));
ACT.void = guard(async (d) => {
  const reason = await askText('Void this record', 'Reason for voiding (required)'); if (!reason) return;
  await call('void', d.t, Number(d.id), reason); toast('Voided - recorded in audit trail'); await openProfile(cur.patient.id);
});

// ---------- Billing ----------
ACT.bill = () => {
  const p = cur.patient; let lines = [{ description: '', qty: 1, rate: '', doctor_id: p.doctor_id || '' }];
  const draw = () => {
    $('lines').innerHTML = `<table><tr><th>Description</th><th style="width:60px">Qty</th><th style="width:110px">Rate ₹</th><th style="width:170px">Doctor</th><th></th></tr>` +
      lines.map((l, i) => `<tr><td><input list="svc" data-i="${i}" data-k="description" value="${esc(l.description)}"></td><td><input type="number" min="1" data-i="${i}" data-k="qty" value="${l.qty}"></td>
      <td><input type="number" step="0.01" min="0" data-i="${i}" data-k="rate" value="${esc(l.rate)}"></td><td><select data-i="${i}" data-k="doctor_id">${opts(M.doctors.map((d) => [d.id, d.name]), l.doctor_id)}</select></td>
      <td><button class="dng sm" data-act="rmLine" data-i="${i}">✕</button></td></tr>`).join('') + '</table>';
    document.querySelectorAll('#lines [data-k]').forEach((el) => { el.oninput = el.onchange = () => { lines[+el.dataset.i][el.dataset.k] = el.value; total(); if (el.dataset.k === 'description') autofill(+el.dataset.i, el.value); }; });
    total();
  };
  const autofill = (i, name) => { const s = M.services.find((x) => x.name === name); if (s && !lines[i].rate) { lines[i].rate = s.default_rate / 100; draw(); } };
  const total = () => { const sub = lines.reduce((s, l) => s + (Number(l.qty) || 0) * (Number(l.rate) || 0), 0); const disc = Number($('b_disc').value) || 0; $('b_total').textContent = '₹' + (sub - disc).toLocaleString('en-IN', { minimumFractionDigits: 2 }); };
  ACT.rmLine = (d) => { lines.splice(+d.i, 1); if (!lines.length) lines.push({ description: '', qty: 1, rate: '' }); draw(); };
  openModal('New Bill — ' + p.name,
    `<datalist id="svc">${M.services.map((s) => `<option value="${esc(s.name)}">`).join('')}</datalist><div id="lines"></div><div class="bar"><button class="sec" id="addline">+ Add line</button></div>
    <div class="grid"><div><label>Bill date</label><input id="b_date" type="date" value="${today()}"></div><div><label>Discount ₹</label><input id="b_disc" type="number" step="0.01" min="0" value=""></div><div><label>Discount reason</label><input id="b_reason"></div></div>
    <h3 style="text-align:right">Total: <span id="b_total">₹0.00</span></h3><p class="muted">No GST is charged. Doctor's % share is booked automatically for lines with a doctor.</p>`,
    async () => {
      const r = await call('bill.create', { patient_id: p.id, bill_date: $('b_date').value, discount: toP($('b_disc').value) || 0, discount_reason: $('b_reason').value || undefined,
        items: lines.filter((l) => l.description).map((l) => ({ description: l.description, qty: Number(l.qty) || 1, rate: toP(l.rate) ?? 0, doctor_id: l.doctor_id ? Number(l.doctor_id) : undefined, service_id: M.services.find((s) => s.name === l.description)?.id })) });
      closeModal(); toast('Bill ' + r.bill_no + ' saved'); await openProfile(p.id);
      if (await askConfirm('Receive payment now?')) ACT.receive();
    }, 'Save Bill');
  $('addline').onclick = () => { lines.push({ description: '', qty: 1, rate: '', doctor_id: p.doctor_id || '' }); draw(); };
  $('b_disc').oninput = total; draw();
};
ACT.receive = () => {
  const p = cur.patient, due = cur.profile?.finance?.due ?? 0;
  const specs = [
    { k: 'pay_type', l: 'Payment type', t: 'select', o: [['ADVANCE', 'Advance'], ['PART', 'Part payment'], ['FULL', 'Full payment']], v: due > 0 ? 'FULL' : 'ADVANCE', blank: '-' },
    { k: 'mode', l: 'Mode', t: 'select', o: [['CASH', 'Cash'], ['UPI', 'UPI'], ['CARD', 'Card'], ['BANK_TRANSFER', 'Bank Transfer'], ['INSURANCE_TPA', 'Insurance / TPA']], v: 'CASH', blank: '-' },
    { k: 'amount', l: 'Amount ₹', t: 'money', v: due > 0 ? due / 100 : '' }, { k: 'pay_date', l: 'Date', t: 'date', v: today() },
    { k: 'reference_no', l: 'UPI / Cheque / Claim no.' }, { k: 'tpa_name', l: 'TPA / Insurance company' },
  ];
  openModal(`Receive Payment — ${p.name} (due ${rs(due)})`, `<div class="grid g2">${specs.map((f) => fieldHtml(f)).join('')}</div>`, async () => {
    const r = await call('payment.create', { patient_id: p.id, ...readFields(specs) }); closeModal(); toast(`Receipt ${r.receipt_no} saved`);
    await openProfile(p.id); await printDialog('receipt', r.id);
  }, 'Save & Print');
  $('f_pay_type').onchange = () => { if ($('f_pay_type').value === 'FULL' && due > 0) $('f_amount').value = due / 100; };
};
ACT.expense = () => {
  const p = cur.patient;
  const heads = () => M.heads.filter((h) => h.scope === 'PATIENT');
  const feeId = () => String(M.heads.find((h) => h.name === 'Doctor Fee')?.id);
  let lines = [{ head_id: '', doctor_id: p.doctor_id || '', description: '', amount: '' }];
  const top = [{ k: 'exp_date', l: 'Date', t: 'date', v: today() }, { k: 'mode', l: 'Paid from', t: 'select', o: [['CASH', 'Cash'], ['UPI', 'Bank / UPI']], v: 'CASH', blank: '-' }];
  const total = () => { $('x_total').textContent = rs(Math.round(lines.reduce((t, l) => t + (Number(l.amount) || 0), 0) * 100)); };
  const draw = () => {
    $('xlines').innerHTML = `<table><tr><th style="width:190px">Expense head</th><th style="width:170px">Doctor (for Doctor Fee)</th><th>Details</th><th style="width:115px">Amount ₹</th><th></th></tr>` +
      lines.map((l, i) => `<tr><td><select data-i="${i}" data-k="head_id">${opts(heads().map((h) => [h.id, h.name]), l.head_id, '- choose -')}</select></td>
      <td><select data-i="${i}" data-k="doctor_id" ${String(l.head_id) === feeId() ? '' : 'disabled'}>${opts(M.doctors.map((d) => [d.id, d.name]), l.doctor_id)}</select></td>
      <td><input data-i="${i}" data-k="description" value="${esc(l.description)}"></td><td><input type="number" step="0.01" min="0" data-i="${i}" data-k="amount" value="${esc(l.amount)}"></td>
      <td><button class="dng sm" data-act="rmXLine" data-i="${i}">✕</button></td></tr>`).join('') + '</table>';
    document.querySelectorAll('#xlines [data-k]').forEach((el) => { el.oninput = el.onchange = () => { lines[+el.dataset.i][el.dataset.k] = el.value; if (el.dataset.k === 'head_id') draw(); else total(); }; });
    total();
  };
  ACT.rmXLine = (d) => { lines.splice(+d.i, 1); if (!lines.length) lines.push({ head_id: '', doctor_id: p.doctor_id || '', description: '', amount: '' }); draw(); };
  openModal('Add Expense — ' + p.name, `<div class="grid g2">${top.map((f) => fieldHtml(f)).join('')}</div><div id="xlines"></div>
    <div class="bar"><button class="sec" id="addxline">+ Add line</button><button class="sec sm" id="newhead">+ New expense head</button><span class="muted">Doctor Fee goes to the doctor's payable; other heads are paid now.</span></div>
    <h3 style="text-align:right">Total: <span id="x_total">₹0.00</span></h3>`, async () => {
    const used = lines.filter((l) => l.head_id || l.amount || l.description);          // a completely empty row is ignored
    const v = readFields(top);
    const r = await call('expense.createMany', { patient_id: p.id, exp_date: v.exp_date, mode: v.mode,
      lines: used.map((l) => ({ head_id: l.head_id ? Number(l.head_id) : undefined, amount: toP(l.amount), doctor_id: String(l.head_id) === feeId() && l.doctor_id ? Number(l.doctor_id) : undefined, description: l.description || undefined })) });
    closeModal(); toast(r.ids.length > 1 ? `${r.ids.length} expense lines saved (${rs(r.total)})` : 'Expense saved'); await openProfile(p.id);
    if (await askConfirm('Attach the bill / prescription (PDF or photo) now?' + (r.ids.length > 1 ? '\nIt will be attached to the first line.' : ''), { yes: 'Attach', no: 'Skip' })) { await nat('attachFile', r.id); await openProfile(p.id); }
  }, 'Save Expense');
  $('addxline').onclick = () => { lines.push({ head_id: '', doctor_id: p.doctor_id || '', description: '', amount: '' }); draw(); };
  $('newhead').onclick = guard(async () => { const n = await askText('New expense head', 'Head name'); if (!n) return; await call('expensehead.create', { name: n, scope: 'PATIENT' }); await reloadMasters(); draw(); toast('Head added'); });
  draw();
};
ACT.refund = () => {
  const p = cur.patient;
  const specs = [
    { k: 'kind', l: 'Type', t: 'select', o: [['refund', 'Refund (money returned)'], ['cn', 'Credit note (reduce a bill)']], v: 'refund', blank: '-' },
    { k: 'amount', l: 'Amount ₹', t: 'money', req: 1 }, { k: 'mode', l: 'Refund mode', t: 'select', o: [['CASH', 'Cash'], ['UPI', 'UPI'], ['CARD', 'Card'], ['BANK_TRANSFER', 'Bank Transfer']], v: 'CASH', blank: '-' },
    { k: 'bill_id', l: 'Against bill (credit note)', t: 'select', o: (cur.profile.bills || []).map((b) => [b.id, `${b.bill_no} (${rs(b.total)})`]) }, { k: 'reason', l: 'Reason', req: 1, w: 'full' },
  ];
  formModal('Refund / Credit Note — ' + p.name, specs, async (v) => {
    if (v.kind === 'cn') await call('creditnote.create', { patient_id: p.id, bill_id: v.bill_id, amount: v.amount, reason: v.reason });
    else await call('refund.create', { patient_id: p.id, mode: v.mode, amount: v.amount, reason: v.reason });
    toast('Saved'); await openProfile(p.id);
  });
};

// ---------- Doctors & Staff ----------
SCREENS.doctors = async () => {
  await reloadMasters();
  const rep = await call('report.run', 'doctorReport', {});
  const staff = M.staff;
  $('view').innerHTML = `<div class="card"><div class="bar"><h4 style="margin:0">Doctors</h4><button class="pri sm" data-act="docSave">+ Add doctor</button><span class="muted">To add a doctor: click “+ Add doctor”, type the name (fee / share % are optional) and Save.</span></div>
    <table><tr><th>Doctor</th><th class="r">Fixed fee</th><th class="r">Share %</th><th class="r">Earned</th><th class="r">Paid</th><th class="r">Payable</th><th></th></tr>
    ${M.doctors.map((d) => { const r = rep.rows.find((x) => x.id === d.id) || {}; return `<tr><td>${esc(d.name)}<br><small class="muted">${esc(d.speciality ?? '')}</small></td><td class="r">${rs(d.fixed_fee)}</td><td class="r">${(d.percent_bp / 100).toFixed(2)}%</td>
      <td class="r">${rs(r.earned)}</td><td class="r">${rs(r.paid)}</td><td class="r"><b>${rs(r.payable)}</b></td>
      <td><button class="sec sm" data-act="docSave" data-id="${d.id}">Edit</button> <button class="pri sm" data-act="settle" data-id="${d.id}">Settle</button></td></tr>`; }).join('')}</table></div>
    <div class="card"><div class="bar"><h4 style="margin:0">Staff salary</h4><button class="pri sm" data-act="staffSave">+ Add staff</button></div>
    <table><tr><th>Name</th><th>Designation</th><th class="r">Monthly salary</th><th></th></tr>${staff.map((s) => `<tr><td>${esc(s.name)}</td><td>${esc(s.designation ?? '')}</td><td class="r">${rs(s.monthly_salary)}</td>
      <td><button class="sec sm" data-act="staffSave" data-id="${s.id}">Edit</button> <button class="pri sm" data-act="paySalary" data-id="${s.id}">Enter salary</button></td></tr>`).join('')}</table></div>
    <p class="muted">Doctor "Earned" = fixed visit fees + percentage share booked from bills. "Settle" records the actual payment to the doctor.</p>`;
};
ACT.docSave = (d) => {
  const o = M.doctors.find((x) => x.id === Number(d.id)) || {};
  const specs = doctorSpecs(o);
  openModal(o.id ? 'Edit Doctor' : 'Add Doctor', `<div class="grid g2">${specs.map((f) => fieldHtml(f)).join('')}</div><p class="muted">You can set both. Fixed fee is added as a Doctor Fee expense; the % is booked automatically from bill lines.</p>`, async () => {
    await call('doctor.save', doctorPayload(readFields(specs), o.id)); closeModal(); await go('doctors');
  });
};
ACT.settle = (d) => {
  const doc = M.doctors.find((x) => x.id === Number(d.id));
  formModal('Settle — ' + doc.name, [{ k: 'amount', l: 'Amount ₹', t: 'money', req: 1 }, { k: 'mode', l: 'Mode', t: 'select', o: [['CASH', 'Cash'], ['UPI', 'UPI'], ['BANK_TRANSFER', 'Bank Transfer']], v: 'CASH', blank: '-' }, { k: 'settle_date', l: 'Date', t: 'date', v: today() }, { k: 'note', l: 'Note' }],
    async (v) => { const r = await call('doctor.settle', { doctor_id: doc.id, ...v }); toast(`Settled ${r.settle_no}. Still payable: ${rs(r.payable_after)}`); await go('doctors'); });
};
ACT.staffSave = (d) => {
  const o = M.staff.find((x) => x.id === Number(d.id)) || {};
  formModal(o.id ? 'Edit Staff' : 'Add Staff', [{ k: 'name', l: 'Name', req: 1, v: o.name }, { k: 'designation', l: 'Designation', v: o.designation }, { k: 'monthly_salary', l: 'Monthly salary ₹', t: 'money', v: o.monthly_salary ? o.monthly_salary / 100 : '' }],
    async (v) => { await call('staff.save', { id: o.id, ...v, monthly_salary: v.monthly_salary || 0 }); await go('doctors'); });
};
ACT.paySalary = (d) => {
  const s = M.staff.find((x) => x.id === Number(d.id));
  formModal('Salary — ' + s.name, [{ k: 'salary_month', l: 'Month (YYYY-MM)', v: today().slice(0, 7), req: 1 }, { k: 'amount', l: 'Amount ₹', t: 'money', v: s.monthly_salary / 100 }, { k: 'paid_date', l: 'Paid on', t: 'date', v: today() }, { k: 'mode', l: 'Mode', t: 'select', o: [['CASH', 'Cash'], ['BANK_TRANSFER', 'Bank']], v: 'CASH', blank: '-' }],
    async (v) => { await call('salary.pay', { staff_id: s.id, ...v }); toast('Salary entered'); });
};

// ---------- Expenses (hospital-level + fixed cost allocation) ----------
SCREENS.accounts = async () => {
  const al = await call('allocation.list');
  $('view').innerHTML = `<div class="bar"><button class="pri" data-act="hospExp">+ Hospital expense</button><button class="pri" data-act="alloc">Allocate fixed cost to patients</button></div>
   <div class="card"><h4>Fixed-cost allocations done</h4>${table([{ key: 'id', label: '#', type: 'int' }, { key: 'head', label: 'Head' }, { key: 'period_from', label: 'From' }, { key: 'period_to', label: 'To' }, { key: 'method', label: 'Method' }, { key: 'total_amount', label: 'Total', type: 'money' }, { key: 'state', label: '' }],
     al.map((a) => ({ ...a, state: a.is_void ? 'VOID' : '' })))}
     ${isAdmin() ? '<p class="muted">To redo an allocation, Admin voids it from the Admin → Void screen using its # (table: fixed_cost_allocations).</p>' : ''}</div>
   <p class="muted">Hospital expense = electricity bill, rent, repairs etc. paid by the hospital. Allocation spreads it over patients so each patient's cost sheet shows an overhead share. Overall P&L counts the real expense once — never twice.</p>`;
};
ACT.hospExp = () => formModal('Hospital Expense', [{ k: 'head_id', l: 'Head', req: 1, t: 'select', o: M.heads.filter((h) => h.scope !== 'PATIENT').map((h) => [h.id, h.name]) }, { k: 'amount', l: 'Amount ₹', t: 'money', req: 1 }, { k: 'exp_date', l: 'Date', t: 'date', v: today() }, { k: 'mode', l: 'Paid from', t: 'select', o: [['CASH', 'Cash'], ['UPI', 'Bank / UPI']], v: 'CASH', blank: '-' }, { k: 'description', l: 'Details', w: 'full' }],
  async (v) => { await call('hospitalExpense.create', v); toast('Saved'); });
ACT.alloc = () => {
  const specs = [{ k: 'head_id', l: 'Fixed cost head', req: 1, t: 'select', o: M.heads.filter((h) => h.scope === 'FIXED').map((h) => [h.id, h.name]) }, { k: 'total_amount', l: 'Total amount ₹', t: 'money', req: 1 },
    { k: 'period_from', l: 'From', t: 'date', v: today().slice(0, 8) + '01' }, { k: 'period_to', l: 'To', t: 'date', v: today() },
    { k: 'method', l: 'Method', t: 'select', o: [['PER_PATIENT_DAY', 'Per patient-day (fairest)'], ['EQUAL', 'Equal per patient']], v: 'PER_PATIENT_DAY', blank: '-' }];
  openModal('Allocate Fixed Cost', `<div class="grid g2">${specs.map((f) => fieldHtml(f)).join('')}</div><div id="pv"></div>`, async () => {
    const v = readFields(specs);
    if (!$('pv').dataset.ok) { const pv = await call('allocation.preview', v); $('pv').dataset.ok = '1'; $('msave').textContent = 'Confirm & Save'; $('pv').innerHTML = `<h4>Preview — ${pv.rows.length} patients</h4>` + table([{ key: 'uhid', label: 'Patient' }, { key: 'name', label: 'Name' }, { key: 'days', label: 'Days', type: 'int' }, { key: 'amount', label: 'Share', type: 'money' }], pv.rows); return; }
    const r = await call('allocation.confirm', v); closeModal(); toast(`Allocated to ${r.patients} patients`); await go('accounts');
  }, 'Preview');
};

// ---------- Reports ----------
const D = () => M.doctors.map((d) => [d.id, d.name]);
const RPT = {
  patientPnl: { l: 'Patient-wise Profit & Loss', f: [['from', 'From (admitted)', 'date'], ['to', 'To', 'date'], ['doctor_id', 'Doctor', 'select', D], ['ward_id', 'Ward', 'select', () => M.wards.map((w) => [w.id, w.name])], ['uhid', 'Patient ID'], ['group_by', 'Group by', 'select', () => [['date', 'Date'], ['doctor', 'Doctor'], ['ward', 'Ward']]]] },
  dailyCollection: { l: 'Daily Collection', f: [['from', 'From', 'date'], ['to', 'To', 'date'], ['mode', 'Payment mode', 'select', () => [['CASH', 'Cash'], ['UPI', 'UPI'], ['CARD', 'Card'], ['BANK_TRANSFER', 'Bank Transfer'], ['INSURANCE_TPA', 'Insurance / TPA']]], ['doctor_id', 'Doctor', 'select', D], ['uhid', 'Patient ID']] },
  outstanding: { l: 'Outstanding / Dues', f: [['doctor_id', 'Doctor', 'select', D], ['as_of', 'As on', 'date']] },
  doctorReport: { l: 'Doctor-wise Collection & Payable', f: [['from', 'From', 'date'], ['to', 'To', 'date'], ['doctor_id', 'Doctor', 'select', D]] },
  overallPnl: { l: 'Overall Hospital P&L', f: [['from', 'From', 'date'], ['to', 'To', 'date']] },
  cashBook: { l: 'Cash Book / Bank Book', f: [['kind', 'Book', 'select', () => [['CASH', 'Cash Book'], ['BANK', 'Bank Book']]], ['from', 'From', 'date'], ['to', 'To', 'date']] },
  balanceSheet: { l: 'Balance Sheet', f: [['as_of', 'As on', 'date']] },
};
SCREENS.reports = async () => {
  $('view').innerHTML = `<div class="card"><div class="bar"><label style="margin:0">Report</label><select id="rsel" style="width:300px">${Object.entries(RPT).map(([k, r]) => `<option value="${k}">${r.l}</option>`).join('')}</select></div>
    <div id="rfilters" class="grid g4"></div><div class="bar" style="margin-top:10px"><button class="pri" data-act="runReport">Show</button><button class="sec" data-act="xlsx">Export Excel</button><button class="sec" data-act="pdf">Save as PDF</button><button class="sec" data-act="printRep">🖨 Print</button></div></div><div id="rout"></div>`;
  const draw = () => { const r = RPT[$('rsel').value] || RPT.patientPnl; $('rfilters').innerHTML = r.f.map(([k, l, t, o]) => fieldHtml({ k, l, t: t || 'text', o: o ? o() : undefined, blank: 'All' })).join(''); };
  $('rsel').onchange = draw; draw();
};
const rFilters = () => { const o = {}; (RPT[$('rsel').value] || RPT.patientPnl).f.forEach(([k, , t]) => { const v = $('f_' + k).value; if (v !== '') o[k] = t === 'select' && /_id$/.test(k) ? Number(v) : v; }); return o; };
ACT.runReport = guard(async () => {
  const rep = await call('report.run', $('rsel').value, rFilters());
  $('rout').innerHTML = `<div class="card"><h3>${esc(rep.title)}</h3>${rep.balanced === false ? '<p class="neg">⚠ Balance sheet does not balance - contact support.</p>' : ''}${table(rep.columns, rep.rows, rep.totals)}</div>`;
});
ACT.xlsx = guard(async () => { const f = await nat('exportXlsx', $('rsel').value, rFilters()); if (f) toast('Saved: ' + f); });
ACT.printRep = guard(async () => { const r = await nat('printDoc', 'report', $('rsel').value, 'A4', 'PRINT', rFilters()); if (r === true) toast('Sent to the printer'); });
ACT.pdf = guard(async () => { const f = await nat('exportPdf', $('rsel').value, rFilters()); if (f) toast('Saved: ' + f); });

// ---------- Admin ----------
SCREENS.admin = async () => {
  const [users, st, bk, au] = await Promise.all([call('user.list'), call('settings.get'), call('backup.list'), call('audit.list', { limit: 100 })]);
  $('view').innerHTML = `<div class="card"><div class="bar"><h4 style="margin:0">Users</h4><button class="pri sm" data-act="userNew">+ Add user</button></div>
    <table><tr><th>Username</th><th>Name</th><th>Role</th><th>Active</th><th></th></tr>${users.map((u) => `<tr><td>${esc(u.username)}</td><td>${esc(u.full_name)}</td><td>${u.role}</td><td>${u.is_active ? 'Yes' : 'No'}</td>
    <td><button class="sec sm" data-act="userToggle" data-id="${u.id}" data-on="${u.is_active ? 0 : 1}">${u.is_active ? 'Disable' : 'Enable'}</button> <button class="sec sm" data-act="userReset" data-id="${u.id}">Reset password</button></td></tr>`).join('')}</table></div>
   <div class="card"><div class="bar"><h4 style="margin:0">Hospital settings (printed on receipts)</h4><button class="pri sm" data-act="settings">Edit</button><button class="sec sm" data-act="opening">Opening cash / bank balance</button></div>
    <p>${esc(st.hospital_name)} — ${esc(st.address)} ${esc(st.phone)}</p></div>
   <div class="card"><div class="bar"><h4 style="margin:0">Printers</h4><button class="pri sm" data-act="printers">Choose printers</button></div>
    <p>A4 printer: <b>${esc(st.printer_a4 || 'ask every time')}</b> &nbsp; Thermal (80 mm) printer: <b>${esc(st.printer_thermal || 'ask every time')}</b></p>
    <p class="muted">No printer? Every Print window also has <b>Save as PDF</b>.</p></div>
   <div class="card"><div class="bar"><h4 style="margin:0">Backup & Restore</h4><button class="pri sm" data-act="bkUsb">Backup to Pen Drive</button><button class="pri sm" data-act="bkGdrive">Backup to Google Drive folder</button><button class="dng sm" data-act="restore">Restore from backup…</button></div>
    <p class="muted">A backup is made automatically every day. Google Drive: install "Google Drive for desktop" and choose a folder inside it - it uploads the file for you.</p>
    ${table([{ key: 'at', label: 'When' }, { key: 'kind', label: 'Type' }, { key: 'file_path', label: 'File' }, { key: 'size_bytes', label: 'Bytes', type: 'int' }], bk.slice(0, 8))}</div>
   <div class="card"><h4>Void a record (Admin)</h4><p class="muted">Normally use the Void button on the patient screen. For an allocation: type table <b>fixed_cost_allocations</b> and its # from the Expenses screen.</p><div class="bar"><input id="vt" placeholder="table e.g. fixed_cost_allocations" style="width:260px"><input id="vi" placeholder="id" style="width:80px"><input id="vr" placeholder="reason" style="width:260px"><button class="dng sm" data-act="voidAny">Void</button></div></div>
   <div class="card"><h4>Audit trail (latest 100)</h4>${table([{ key: 'at', label: 'When' }, { key: 'username', label: 'User' }, { key: 'action', label: 'Action' }, { key: 'table_name', label: 'Table' }, { key: 'record_id', label: 'ID', type: 'int' }, { key: 'new_json', label: 'Details' }], au.map((a) => ({ ...a, new_json: (a.new_json || '').slice(0, 90) })))}</div>`;
};
ACT.userNew = () => formModal('Add user', [{ k: 'username', l: 'Username', req: 1 }, { k: 'full_name', l: 'Full name', req: 1 }, { k: 'password', l: 'Temporary password', req: 1 }, { k: 'role', l: 'Role', t: 'select', o: [['RECEPTIONIST', 'Receptionist'], ['ACCOUNTANT', 'Accountant'], ['ADMIN', 'Admin']], v: 'RECEPTIONIST', blank: '-' }], async (v) => { await call('user.create', v); await go('admin'); });
ACT.userToggle = guard(async (d) => { await call('user.setActive', Number(d.id), d.on === '1'); await go('admin'); });
ACT.userReset = guard(async (d) => { const p = await askText('Reset password', 'New temporary password (min 6)'); if (p) { await call('user.resetPassword', Number(d.id), p); toast('Done - user must change it at next login'); } });
ACT.printers = guard(async () => {
  const [list, st] = await Promise.all([nat('listPrinters'), call('settings.get')]);
  const o = list.map((p) => [p.name, p.name + (p.isDefault ? '  (Windows default)' : '')]);
  const specs = [{ k: 'printer_a4', l: 'A4 printer (bills, slips, reports)', t: 'select', o, v: st.printer_a4, blank: 'Ask every time (Windows print window)', w: 'full' },
    { k: 'printer_thermal', l: 'Thermal receipt printer (80 mm)', t: 'select', o, v: st.printer_thermal, blank: 'Ask every time (Windows print window)', w: 'full' }];
  openModal('Printers', `<ol class="muted" style="margin:0 0 10px 18px;padding:0"><li>Switch the printer on, connect it (USB / Wi-Fi) and add it in Windows: <b>Settings → Bluetooth &amp; devices → Printers &amp; scanners → Add device</b>.</li>
    <li>Click <b>Refresh list</b> below — the printer appears in the lists.</li><li>Choose it for A4 and/or thermal and Save. Printing then goes straight to it.</li>
    <li>If you leave it on “Ask every time”, Windows' print window opens, where <b>Microsoft Print to PDF</b> also works.</li></ol>
    ${list.length ? '' : '<p class="neg">No printer is installed in Windows yet.</p>'}<div class="grid g2">${specs.map((f) => fieldHtml(f)).join('')}</div>
    <div class="bar"><button class="sec sm" id="prnwin">Open Windows printer settings</button><button class="sec sm" id="prnref">↻ Refresh list</button></div>`, async () => {
    const v = readFields(specs); await call('settings.set', { printer_a4: v.printer_a4 ?? '', printer_thermal: v.printer_thermal ?? '' }); closeModal(); toast('Printers saved'); await go('admin');
  });
  $('prnwin').onclick = guard(() => nat('openPrinterSettings'));
  $('prnref').onclick = () => { closeModal(); ACT.printers(); };
});
ACT.settings = async () => { const s = await call('settings.get'); formModal('Hospital settings', [{ k: 'hospital_name', l: 'Hospital name', v: s.hospital_name }, { k: 'address', l: 'Address', v: s.address }, { k: 'phone', l: 'Phone', v: s.phone }, { k: 'letterhead_path', l: 'Logo image path (optional, PNG/JPG)', v: s.letterhead_path, w: 'full' }], async (v) => { await call('settings.set', v); $('hname').textContent = v.hospital_name || 'Hospital Accounts'; await go('admin'); }); };
ACT.opening = () => formModal('Opening balances (only before the first entry)', [{ k: 'cash', l: 'Cash in hand ₹', t: 'money', v: (M.accounts.find((a) => a.kind === 'CASH')?.opening_balance || 0) / 100 }, { k: 'bank', l: 'Bank balance ₹', t: 'money', v: (M.accounts.find((a) => a.kind === 'BANK')?.opening_balance || 0) / 100 }],
  async (v) => { await call('account.setOpening', M.accounts.find((a) => a.kind === 'CASH').id, v.cash || 0); await call('account.setOpening', M.accounts.find((a) => a.kind === 'BANK').id, v.bank || 0); await reloadMasters(); toast('Saved'); });
ACT.bkUsb = guard(async () => { const r = await nat('backupToFolder', 'MANUAL_USB'); if (r) { toast('Backup saved: ' + r.file); await go('admin'); } });
ACT.bkGdrive = guard(async () => { const r = await nat('backupToFolder', 'GDRIVE'); if (r) { toast('Backup saved: ' + r.file); await go('admin'); } });
ACT.restore = guard(async () => {
  const f = await nat('pickBackupFile'); if (!f) return;
  if (!(await askConfirm('Restore this backup? Current data is kept as a "before-restore" copy, and the app will restart.', { yes: 'Restore', no: 'Cancel' }))) return;
  const info = await call('backup.stageRestore', f); toast(`Backup OK (${info.patients} patients). Restarting…`); setTimeout(() => nat('restartApp'), 1200);
});
ACT.voidAny = guard(async () => { await call('void', $('vt').value.trim(), Number($('vi').value), $('vr').value); toast('Voided'); });

// ---------- wiring ----------
ACT.go = (d) => go(d.k);
document.addEventListener('click', (e) => { const el = e.target.closest && e.target.closest('[data-act]'); if (el && ACT[el.dataset.act]) { e.preventDefault(); const r = ACT[el.dataset.act](el.dataset); if (r && r.catch) r.catch((x) => toast('⚠ ' + x.message)); } });
let t; $('q').oninput = () => { clearTimeout(t); t = setTimeout(guard(async () => { if (cur.screen !== 'patients') { cur.screen = 'patients'; } await search($('q').value); }), 120); };
document.addEventListener('keydown', (e) => {
  if (dialogOpen()) {                                              // the question on top gets the keyboard first
    if (e.key === 'Escape') { e.preventDefault(); closeDialog(null); }
    else if (e.key === 'Enter' && dlgDefault && !['TEXTAREA', 'BUTTON', 'SELECT'].includes(e.target && e.target.tagName)) { e.preventDefault(); $(dlgDefault).click(); }
    return;
  }
  if ($('app').classList.contains('hide')) return;
  const modalOpen = !$('modalbg').classList.contains('hide');
  if (e.key === 'Escape' && modalOpen) closeModal();
  if (modalOpen) { if (e.ctrlKey && e.key === 's') { e.preventDefault(); $('msave') && $('msave').click(); } return; }
  const k = { F2: 'newPatient' }; if (cur.patient && canFin()) Object.assign(k, { F4: 'bill', F5: 'receive', F6: 'expense', F7: 'refund' });
  if (k[e.key]) { e.preventDefault(); ACT[k[e.key]](); }
  if (e.key === '/' && document.activeElement.tagName !== 'INPUT') { e.preventDefault(); $('q').focus(); }
});
// If Windows ever hands the window back without keyboard focus, put the cursor back in the open form.
if (typeof window !== 'undefined' && window.addEventListener) window.addEventListener('focus', () => {
  const box = dialogOpen() ? $('dlg') : !$('modalbg').classList.contains('hide') ? $('modal') : null;
  const f = box && box.querySelector && box.querySelector('input,select,textarea');
  if (f && document.activeElement && document.activeElement.tagName === 'BODY') f.focus();
});
if (typeof window !== 'undefined' && window.api) { me = { id: 1, username: 'admin', full_name: 'Local User', role: 'ADMIN', must_change_password: false }; enter().catch((e) => toast('⚠ ' + e.message)); }
if (typeof module !== 'undefined') module.exports = { ACT, SCREENS, go, openProfile, enter, call, setMe: (u) => { me = u; }, askConfirm, askText, askForm, printDialog };   // used only by the smoke test

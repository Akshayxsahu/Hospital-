# Hospital Accounting Software (Patient-Wise)

Simple, offline-first Windows accounting app for a hospital. Focus: **money in, money out, profit — per patient.** Not an EMR.

| File | What it is |
|---|---|
| `db/schema.sql` + `db/views.sql` | Complete database: tables, indexes, seed data (`schema.sql`) and the accounting views (`views.sql`, rebuilt at every start). Older databases are upgraded in place. Tested. |
| `db/demo_patient_a.sql` | Loads your "Patient A" example |
| `docs/PATIENT_LEDGER_SAMPLE.md` | How the patient ledger screen looks |

---

## 0. Status — everything in your list is built

| Area | Status |
|---|---|
| Patient master, auto ID `PAT-2026-0001`, one-box search (ID / name / mobile / Aadhar / Ayushman), mandatory Aadhar or Ayushman ID, duplicate warning | ✅ |
| Billing (no GST), advance / part / full, due tracking, 5 payment modes incl. Insurance/TPA, refund, discount, credit note | ✅ |
| Receipt & bill print — A4 letterhead and 80 mm thermal | ✅ (printing uses the Windows printer driver) |
| Patient-wise expenses, custom heads, attachments (PDF/image), fixed-cost allocation (per patient-day / equal), auto doctor share | ✅ |
| Doctors: fixed fee **and** % share, payable, settlement. Staff salary | ✅ |
| Dashboard + 7 reports with filters; Excel and PDF export | ✅ |
| Single-user desktop mode (no login screen), audit trail, void-with-reason (role checks remain in the code) | ✅ |
| Daily auto backup, manual backup to pen drive / Google Drive folder, restore | ✅ |
| Windows installer built automatically by GitHub | ✅ (`.github/workflows/build.yml`) |
| **Cloud sync** (live two-way) | ❌ not built — use *Backup to Google Drive folder* instead. `sync_queue` table is reserved for the future |
| Aadhar number encrypted in the database | ❌ stored as plain text in the local DB (see Limits) |

**Tested here:** 34 automated tests (`npm test`) cover all business logic, permissions, reports (the balance sheet is checked to balance at every date), xlsx files, backup/restore, and the screens run against the real backend with a simulated browser page.
**Not tested here:** the app could not be opened in a real Electron window or on a physical printer from the build sandbox. Run it once on a Windows PC (see `docs/GITHUB_GUIDE.md`) and report anything odd.

### Limits (be aware)
- One computer holds the data (SQLite file). Several PCs on a network are **not** supported; use one PC, or one PC + backups.
- Aadhar and all data sit in the local database file; protect the PC with a Windows password and BitLocker. Database-level encryption is a possible later upgrade.
- **Accrual basis:** income is counted when a bill is made (less credit notes), costs when incurred; salaries in their own month (counted on the last day of it). Cash received only affects dues, advances and the cash / bank books. Reports use *admission date* for patient P&L. Doctor share is calculated on the line amount before bill-level discount.

### Run / build
```
npm install     # once, needs internet (Node.js 22 LTS)
npm test        # 34 tests
npm start       # open the app (no login screen)
npm run dist    # build Windows installer into /dist  (or let GitHub do it - see docs/GITHUB_GUIDE.md)
```
Docs: `docs/GITHUB_GUIDE.md` (step-by-step GitHub), `docs/USER_MANUAL.md` (staff guide), `docs/PATIENT_LEDGER_SAMPLE.md` (sample ledger).

---

## 1. Technology Stack (recommended)

**Electron + React + SQLite (better-sqlite3)** — packaged as a normal Windows `.exe` installer.

| Need | Choice | Why |
|---|---|---|
| Offline, local, fast | **SQLite** (single file, WAL mode) | 10,000+ patients is tiny for SQLite; indexed search returns in ~10 ms. Backup = copy one file. |
| Desktop app | **Electron** | Runs on Windows 10/11 laptop & desktop. ~200-300 MB RAM, fine for 4 GB. |
| UI | **React + a table/grid library** (e.g. AG Grid Community) | Keyboard-first grids like Tally/Busy: Enter to move, F-keys for actions. |
| Print | A4: HTML → PDF via Electron `printToPDF`. Thermal: **ESC/POS** (`node-thermal-printer`) 58/80 mm | Same data, two templates. Letterhead = logo + header image from Settings. |
| Export | `exceljs` (Excel), PDF via print template | All reports use the same query → two exporters. |
| Backup | Daily auto copy of `.db` (SQLite online-backup API) → local folder; manual copy to pen drive; Google Drive via Drive API (optional) | |
| Optional cloud sync | `sync_queue` table → push to a small cloud API (Postgres) when online | Build **last**; the app is fully usable without it. |
| Security | bcrypt/argon2 passwords, role checks in the **main process** (not just hidden buttons), Aadhar stored encrypted, optional SQLCipher DB encryption | |

**Alternative:** .NET 8 WinForms/WPF + SQLite. Lighter on RAM and very Tally-like, but fewer ready-made UI parts. Pick this only if your developer is a .NET person.
**Not recommended:** pure web app (needs internet/server, breaks "offline" requirement).

### Suggested repo layout
```
/src            Electron main process + business logic (db, auth, patients, api, audit)
/renderer       Screens (plain HTML/JS now; React can be added later)
/test           Automated tests
/db             schema.sql (+ demo_patient_a.sql sample data)
/reports        one file per report (SQL + export template)
/docs
```
Rule: **totals are never stored** — they are always computed from the views in `db/schema.sql`, so Dashboard, Ledger and Reports can never disagree. Money is stored as integer paise.

---

## 2. Roles

| Screen / Action | Receptionist | Accountant | Admin |
|---|:-:|:-:|:-:|
| Add / edit patient | ✅ | ✅ | ✅ |
| Create bill, receipt, refund, discount, credit note | ❌ | ✅ | ✅ |
| Add expenses, allocate fixed cost | ❌ | ✅ | ✅ |
| Doctor settlement, staff salary | ❌ | ✅ | ✅ |
| Dashboard, reports, P&L, Balance Sheet | ❌ | ✅ | ✅ |
| Void / delete any entry | ❌ | ❌ | ✅ (reason mandatory) |
| Users, settings, backup/restore, audit log | ❌ | ❌ | ✅ |

---

## 3. Screen-by-Screen Flow

```
Login → Dashboard ─┬─ F2 New Patient ─→ Patient Profile/Ledger ─┬─ F4 Bill
                   │                                           ├─ F5 Receive Payment
                   ├─ Search box (always on top)               ├─ F6 Add Expense
                   ├─ Billing                                  └─ F7 Refund / Discount / Credit Note
                   ├─ Expenses
                   ├─ Doctors & Staff
                   ├─ Reports
                   └─ Admin (Users, Backup, Audit Log, Settings)
```

**Screen 0 – Login.** Username + password. Role decides which menu items appear.

**Screen 1 – Dashboard.** 5 big tiles: *Today's Collection · Today's Expense · Today's Profit · Pending Dues · Patients Today*. Below: last 10 receipts, top 5 dues, "Backup done at 02:00 ✔".

**Screen 2 – Patient Entry (F2).** One compact form: Name, Age, Gender, Mobile, Address, ID proof (Aadhar or Ayushman card - mandatory), Guardian, Doctor (with "+ Add new doctor"), Ward / Bed No., Type (OPD/IPD/Emergency/Day Care), Admission date. Patient ID `PAT-2026-0001` is generated on Save. If mobile/Aadhar already exists → "Patient already registered, open profile?" (avoids duplicates). Receptionist stops here.

**Screen 3 – Search & Patient Profile (the main screen).** Search by ID / Name / Mobile / Aadhar (results as you type, <1 s). Opening a patient shows **everything in one screen**:
- Header: demographics, doctor, ward, admission/discharge, status
- Four summary boxes: **Billed · Received · Due · Profit/Loss**
- Tabs: **Ledger** (all bills & receipts) · **Expenses / Cost Sheet** · **Documents** · **Audit**
- Action buttons: Bill, Receive, Add Expense, Refund, Discharge

**Screen 4 – Billing (F4).** Pick patient → add lines (service, qty, rate; doctor optional) → discount (amount + reason) → Save. Then immediately **"Receive Payment?"** pop-up.
- *Receive Payment (F5):* amount, type (Advance/Part/Full), mode (Cash/UPI/Card/Bank/TPA), reference no. → Save → **Receipt prints** (A4 letterhead or thermal). Due amount updates instantly.
- *Refund / Credit Note (F7)* – pick original receipt/bill, amount, reason.

**Screen 5 – Expense Entry (F6).** Pick patient → head (dropdown + "＋ new head") → one or more lines (head, details, amount) with "+ Add line", date → **📎 Attach** PDF/image → Save. Choosing *Doctor Fee* + a doctor automatically adds it to that doctor's payable. Screen shows a running **Total Cost** for the patient while typing.
- *Fixed-Cost Allocation (monthly, Accountant/Admin):* choose head (Electricity/Rent/Salary), period, total amount, method → **Per patient-day** (default, fairest) / **Equal per patient** / **Manual**. A preview grid shows each patient's share; Confirm creates one `ALLOCATED` expense row per patient.
- *Hospital Expense (not patient-linked):* separate small form, goes only to overall P&L.

**Screen 6 – Doctors & Staff.** Doctor list → click doctor → *Earned, Paid, Payable* + patient-wise list → **Settle** button (creates settlement + voucher). Staff: monthly salary entry grid (one tick per person per month).

**Screen 7 – Reports (all have Date / Doctor / Patient ID / Payment Mode filters + Excel + PDF buttons):**
1. Patient-wise Profit & Loss (group by Date / Doctor / Ward)
2. Daily Collection (by payment mode)
3. Outstanding / Dues (with ageing)
4. Doctor-wise Collection & Payable
5. Overall Hospital P&L (income − patient costs − hospital expenses − salaries)
6. Cash Book · Bank Book
7. Balance Sheet (cash + bank + receivables vs. payables to doctors + capital/retained profit)

**Screen 8 – Admin.** Users & roles · Backup now / Restore / choose pen-drive or Google Drive · Audit Log viewer (who, what, when, old→new value) · Settings (letterhead, ID prefix, printer).

**Daily habit for staff (the "10-minute training"):** `F2 register → F4 bill → F5 receive → F6 expense → check Profit box`.

---

## 4. Database Overview

See `db/schema.sql` for exact fields. Table groups:

| Group | Tables |
|---|---|
| Access & setup | `users`, `settings`, `number_series` |
| Masters | `patients`, `doctors`, `wards`, `accounts` (cash/bank), `service_items` |
| Income | `bills`, `bill_items`, `credit_notes`, `payments`, `refunds` |
| Expense | `expense_heads`, `patient_expenses`, `expense_attachments`, `fixed_cost_allocations`, `hospital_expenses` |
| People | `doctor_settlements`, `staff`, `staff_salaries` |
| Safety | `audit_log`, `backup_log`, `sync_queue` |
| Computed views | `v_patient_financials`, `v_doctor_payable`, `v_cashbook` |

### Core formulas
```
Net Billed   = Bills − Credit Notes
Net Received = Payments − Refunds
Due          = Net Billed − Net Received
Total Cost   = Direct expenses + Allocated fixed cost
Profit/Loss  = Net Received − Total Cost        (matches your example)
```

### Performance for 10,000+ patients
Indexes on name (case-insensitive), mobile, Aadhar, UHID, date, doctor, ward; WAL mode; paginated grids. 100,000 patients still searches in well under 1 s. If name search ever feels slow, add an SQLite FTS5 table — no redesign needed.

### Audit & safety rules
- No hard delete: bills/payments/refunds use `is_void`, expenses/patients use `is_deleted`; Admin only, reason required.
- Every create/update/void writes `audit_log` (user, time, old JSON, new JSON) — done in one DB transaction with the change itself.
- Receipt/bill numbers come from `number_series` inside the same transaction → no gaps or duplicates.
- After discharge the patient is `CLOSED` only by Admin; closed patients reject new entries.

---

## 5. Milestones — all done
1. Login/roles, patient master, ID, search  2. Billing, receipts, dues  3. Expenses, attachments, profit boxes  4. Doctors, settlement, salary, allocation  5. Dashboard, 7 reports, Excel/PDF  6. Audit viewer, backups, installer.
**Later (optional):** live cloud sync, Aadhar/database encryption, SMS/WhatsApp receipts.

## 6. Decisions you gave (built in)
- **No GST** anywhere. **Doctor pay: both** fixed fee and % share. **Profit: accrual basis** (billed − costs incurred).


## What changed in v1.1

1. **Doctors** - *Doctors & Staff -> + Add doctor*, or **+ Add new doctor** right inside the patient form.
2. **Printers & PDF** - every Print window has **Print** and **Save as PDF**. *Admin -> Printers* picks the A4 and thermal printers (add the printer in Windows first); *Print* on reports too.
3. **Bed No.** replaces Room No. (existing data is carried over).
4. **Discharge** uses an in-app date box (the browser `prompt()` is not supported in Electron) and then prints a **Discharge slip**; the slip can be re-printed from the patient screen.
5. **Aadhar or Ayushman card ID is mandatory** for every patient (Aadhar = 12 digits; Ayushman IDs come in several formats, so only characters are checked). Older patients without one must get it when next edited.
6. **Expenses** accept several lines in one entry (like bills); the vendor field is removed.
7. **Keyboard freezing** - native pop-ups (`confirm` / `prompt`) are gone, focus is handed back after every dialog / print job, and a hidden print window is no longer destroyed while the print dialog is open.
8. **Dashboard calendar** - month grid with billed (green) and expenses (red) per day; click a day for its figures.
9. **Accrual accounting** - see above. Balance sheet gained *Salaries payable* / *Salary paid in advance* so it still balances.

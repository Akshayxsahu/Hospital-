'use strict';
// HTML templates for receipts, bills and reports. A4 = letterhead page, THERMAL = 80 mm roll.
// The Electron main process prints these (or saves them as PDF). Templates are pure functions -> unit tested.
const fs = require('fs');
const { esc, inr, daysBetween } = require('./util');

const ONES = ['', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine', 'Ten', 'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen', 'Seventeen', 'Eighteen', 'Nineteen'];
const TENS = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];
const two = (n) => (n < 20 ? ONES[n] : TENS[Math.floor(n / 10)] + (n % 10 ? ' ' + ONES[n % 10] : ''));
function words(n) {                                       // Indian system: crore / lakh / thousand
  if (n === 0) return 'Zero';
  const parts = [[10000000, 'Crore'], [100000, 'Lakh'], [1000, 'Thousand'], [100, 'Hundred']];
  let s = '';
  for (const [v, name] of parts) { if (n >= v) { s += two0(Math.floor(n / v)) + ' ' + name + ' '; n %= v; } }
  return (s + (n ? two(n) : '')).trim();
}
const two0 = (n) => (n >= 100 ? words(n) : two(n));
function amountInWords(paise) {
  const r = Math.floor(paise / 100), p = paise % 100;
  return `Rupees ${words(r)}${p ? ' and ' + two(p) + ' Paise' : ''} Only`;
}

function settings(db) { return Object.fromEntries(db.all('SELECT key,value FROM settings').map((r) => [r.key, r.value])); }
function logoTag(s) {
  try { if (s.letterhead_path && fs.existsSync(s.letterhead_path)) { const ext = s.letterhead_path.split('.').pop().toLowerCase().replace('jpg', 'jpeg'); return `<img src="data:image/${ext};base64,${fs.readFileSync(s.letterhead_path).toString('base64')}" style="max-height:70px">`; } } catch (_) { /* ignore */ }
  return '';
}
const head = (s) => `<div class="lh">${logoTag(s)}<h1>${esc(s.hospital_name || 'Hospital')}</h1><div>${esc(s.address || '')}${s.phone ? ' | Ph: ' + esc(s.phone) : ''}</div></div>`;
const CSS = {
  A4: 'body{font:13px Arial;margin:30px}.lh{text-align:center;border-bottom:2px solid #17406b;padding-bottom:8px;margin-bottom:14px}.lh h1{margin:4px 0;color:#17406b}table{width:100%;border-collapse:collapse}td,th{padding:6px;border:1px solid #bbb;text-align:left}.r{text-align:right}.big{font-size:18px;font-weight:bold}.sig{margin-top:60px;display:flex;justify-content:space-between}',
  THERMAL: 'body{font:12px monospace;width:72mm;margin:0 auto}.lh{text-align:center;border-bottom:1px dashed #000;padding-bottom:4px}.lh h1{font-size:15px;margin:2px}table{width:100%}td{padding:1px 0}.r{text-align:right}.big{font-size:15px;font-weight:bold}.sig{margin-top:18px}',
};
const wrap = (fmt, body) => `<!doctype html><html><head><meta charset="utf-8"><style>${CSS[fmt]}@page{margin:${fmt === 'A4' ? '10mm' : '2mm'}}</style></head><body>${body}</body></html>`;
const fmtOf = (f) => (f === 'THERMAL' ? 'THERMAL' : 'A4');

function receiptHtml(db, paymentId, format = 'A4') {
  const fmt = fmtOf(format), s = settings(db);
  const y = db.get(`SELECT y.*, p.uhid, p.name, u.full_name received_by FROM payments y JOIN patients p ON p.id=y.patient_id LEFT JOIN users u ON u.id=y.created_by WHERE y.id=?`, paymentId);
  if (!y) throw new Error('Receipt not found');
  const due = db.get('SELECT due FROM v_patient_financials WHERE patient_id=?', y.patient_id).due;
  const row = (a, b) => `<tr><td>${a}</td><td class="r">${b}</td></tr>`;
  return wrap(fmt, `${head(s)}<h3 style="text-align:center">PAYMENT RECEIPT${y.is_void ? ' (CANCELLED)' : ''}</h3>
    <table>${row('Receipt No', esc(y.receipt_no))}${row('Date', esc(y.pay_date))}${row('Patient', `${esc(y.name)} (${esc(y.uhid)})`)}
    ${row('Payment type', esc(y.pay_type))}${row('Mode', esc(y.mode.replace('_', ' ')) + (y.reference_no ? ' / ' + esc(y.reference_no) : ''))}${y.tpa_name ? row('TPA', esc(y.tpa_name)) : ''}
    <tr><td class="big">Amount Received</td><td class="r big">Rs. ${inr(y.amount)}</td></tr>${row('Balance due after this', 'Rs. ' + inr(Math.max(due, 0)))}</table>
    <p><i>${amountInWords(y.amount)}</i></p><div class="sig"><span>Received by: ${esc(y.received_by || '')}</span><span>Signature</span></div>`);
}

function billHtml(db, billId, format = 'A4') {
  const fmt = fmtOf(format), s = settings(db);
  const b = db.get('SELECT b.*, p.uhid, p.name, p.age, p.gender, p.address, p.mobile, p.guardian_name FROM bills b JOIN patients p ON p.id=b.patient_id WHERE b.id=?', billId);
  if (!b) throw new Error('Bill not found');
  const items = db.all('SELECT * FROM bill_items WHERE bill_id=?', billId);
  const paid = db.get('SELECT COALESCE(SUM(amount),0) v FROM payments WHERE patient_id=? AND is_void=0', b.patient_id).v;
  return wrap(fmt, `${head(s)}<h3 style="text-align:center">BILL / INVOICE${b.is_void ? ' (CANCELLED)' : ''}</h3>
    <p>Bill No: <b>${esc(b.bill_no)}</b> &nbsp; Date: ${esc(b.bill_date)}<br>Patient: <b>${esc(b.name)}</b> (${esc(b.uhid)}) ${b.age ? ', ' + b.age + 'y' : ''} ${esc(b.gender || '')}
    ${b.guardian_name ? `<br>Guardian: ${esc(b.guardian_name)}` : ''}${b.mobile ? ` &nbsp; Mobile: ${esc(b.mobile)}` : ''}<br>Address: ${esc(b.address || '-')}</p>
    <table><tr><th>#</th><th>Description</th><th class="r">Amount</th></tr>
    ${items.map((i, n) => `<tr><td>${n + 1}</td><td>${esc(i.description)}${i.qty > 1 ? ` <small>(${i.qty} x ${inr(i.rate)})</small>` : ''}</td><td class="r">${inr(i.amount)}</td></tr>`).join('')}
    <tr><td colspan="2" class="r">Sub total</td><td class="r">${inr(b.subtotal)}</td></tr>
    ${b.discount ? `<tr><td colspan="2" class="r">Discount (${esc(b.discount_reason)})</td><td class="r">- ${inr(b.discount)}</td></tr>` : ''}
    <tr><td colspan="2" class="r big">TOTAL</td><td class="r big">${inr(b.total)}</td></tr>
    <tr><td colspan="2" class="r">Received from patient so far</td><td class="r">${inr(paid)}</td></tr></table>
    <p><i>${amountInWords(b.total)}</i></p><div class="sig"><span>No GST charged</span><span>Authorised signatory</span></div>`);
}


// Discharge slip: who, where (ward / bed), when, and (for Accountant/Admin) the money summary.
function dischargeHtml(db, patientId, format = 'A4', { withFinance = true } = {}) {
  const fmt = fmtOf(format), s = settings(db);
  const p = db.get(`SELECT p.*, d.name doctor_name, d.speciality doctor_speciality, s.name staff_name, s.designation staff_designation,
                    w.name ward_name FROM patients p LEFT JOIN doctors d ON d.id=p.doctor_id LEFT JOIN staff s ON s.id=p.staff_id
                    LEFT JOIN wards w ON w.id=p.ward_id WHERE p.id=? AND p.is_deleted=0`, patientId);
  if (!p) throw new Error('Patient not found');
  if (!p.discharge_date) throw new Error('This patient is not discharged yet - discharge first');
  const days = Math.max(1, daysBetween(p.admission_date, p.discharge_date) + 1);
  const idTxt = p.id_type === 'AYUSHMAN' ? `Ayushman card: ${p.ayushman_id || ''}` : `Aadhar: ${p.aadhar || ''}`;
  const f = withFinance ? db.get('SELECT * FROM v_patient_financials WHERE patient_id=?', patientId) : null;
  const row = (a, b) => `<tr><td>${a}</td><td>${b}</td></tr>`;
  const money = (a, b) => `<tr><td>${a}</td><td class="r">Rs. ${inr(b)}</td></tr>`;
  return wrap(fmt, `${head(s)}<h3 style="text-align:center">DISCHARGE SLIP</h3>
    <table>${row('Patient', `<b>${esc(p.name)}</b> (${esc(p.uhid)})`)}${row('Age / Sex', `${esc(p.age ?? '')} / ${esc(p.gender ?? '')}`)}${row('ID proof', esc(idTxt))}
    ${p.guardian_name ? row('Guardian', esc(p.guardian_name)) : ''}${p.mobile ? row('Mobile', esc(p.mobile)) : ''}
    ${row('Doctor', esc(p.doctor_name || '-') + (p.doctor_speciality ? ` (${esc(p.doctor_speciality)})` : ''))}${row('Staff in charge', p.staff_name ? esc(p.staff_name) + (p.staff_designation ? ` (${esc(p.staff_designation)})` : '') : '-')}${row('Ward / Bed No.', `${esc(p.ward_name || '-')} / ${esc(p.bed_no || '-')}`)}
    ${row('Admission date', esc(p.admission_date))}${row('Discharge date', esc(p.discharge_date))}${row('Days stayed', String(days))}</table>
    ${f ? `<h4>Account summary</h4><table>${money('Total billed', f.net_billed)}${money('Received', f.net_received)}${money(f.due > 0 ? '<b>Balance due</b>' : 'Balance due', Math.max(f.due, 0))}${f.due < 0 ? money('Refundable to patient', -f.due) : ''}</table>` : ''}
    <div class="sig"><span>Patient / Guardian signature</span><span>Doctor</span><span>Authorised signatory</span></div>`);
}

function reportHtml(db, report) {
  const s = settings(db);
  const fmtv = (v, t) => (t === 'money' ? inr(v ?? 0) : esc(v ?? ''));
  const cls = (t) => (t === 'money' || t === 'int' ? ' class="r"' : '');
  return wrap('A4', `${head(s)}<h3 style="text-align:center">${esc(report.title)}</h3>
    <table><tr>${report.columns.map((c) => `<th${cls(c.type)}>${esc(c.label)}</th>`).join('')}</tr>
    ${report.rows.map((r) => `<tr>${report.columns.map((c) => `<td${cls(c.type)}>${fmtv(r[c.key], c.type)}</td>`).join('')}</tr>`).join('')}
    ${report.totals ? `<tr style="font-weight:bold"><td>TOTAL</td>${report.columns.slice(1).map((c) => `<td${cls(c.type)}>${report.totals[c.key] !== undefined ? fmtv(report.totals[c.key], c.type) : ''}</td>`).join('')}</tr>` : ''}</table>
    <p style="font-size:11px;color:#555">Printed ${new Date().toLocaleString('en-IN')}</p>`).replace('@page{margin:10mm}', '@page{margin:10mm;size:A4 landscape}');
}
module.exports = { receiptHtml, billHtml, dischargeHtml, reportHtml, amountInWords };

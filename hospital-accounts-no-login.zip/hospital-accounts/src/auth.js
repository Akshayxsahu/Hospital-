'use strict';
const crypto = require('crypto');
const audit = require('./audit');
const ROLES = ['ADMIN', 'ACCOUNTANT', 'RECEPTIONIST'];

function hash(password) {
  const salt = crypto.randomBytes(16);
  const h = crypto.scryptSync(password, salt, 64);
  return `scrypt$${salt.toString('hex')}$${h.toString('hex')}`;
}
function verify(password, stored) {
  const [alg, saltHex, hHex] = stored.split('$');
  if (alg !== 'scrypt') return false;
  const h = crypto.scryptSync(password, Buffer.from(saltHex, 'hex'), 64);
  return crypto.timingSafeEqual(h, Buffer.from(hHex, 'hex'));
}

// First run: create 'admin' with a temporary password that must be changed at first login.
function ensureAdmin(db, tempPassword = 'admin123') {
  if (db.get('SELECT id FROM users LIMIT 1')) return false;
  db.run(`INSERT INTO users(username,full_name,password_hash,role,must_change_password)
          VALUES ('admin','Administrator',?, 'ADMIN',1)`, hash(tempPassword));
  return true;
}

function createUser(db, actor, { username, full_name, password, role }) {
  if (!ROLES.includes(role)) throw new Error('Invalid role');
  if (!username || !full_name) throw new Error('Username and name are required');
  if (!password || password.length < 6) throw new Error('Password must be at least 6 characters');
  return db.tx(() => {
    const r = db.run('INSERT INTO users(username,full_name,password_hash,role,must_change_password) VALUES (?,?,?,?,1)',
      username.trim().toLowerCase(), full_name.trim(), hash(password), role);
    const id = Number(r.lastInsertRowid);
    audit.log(db, actor.id, 'CREATE', 'users', id, null, { username, full_name, role });
    return id;
  });
}

function login(db, username, password) {
  const u = db.get('SELECT * FROM users WHERE username=? AND is_active=1', String(username || '').trim().toLowerCase());
  if (!u || !verify(String(password || ''), u.password_hash)) {
    audit.log(db, u?.id, 'LOGIN', 'users', u?.id, null, { success: false, username });
    throw new Error('Wrong username or password');
  }
  audit.log(db, u.id, 'LOGIN', 'users', u.id, null, { success: true });
  return { id: u.id, username: u.username, full_name: u.full_name, role: u.role, must_change_password: !!u.must_change_password };
}

function changePassword(db, user, oldPw, newPw) {
  const u = db.get('SELECT * FROM users WHERE id=?', user.id);
  if (!verify(oldPw, u.password_hash)) throw new Error('Current password is wrong');
  if (!newPw || newPw.length < 6) throw new Error('New password must be at least 6 characters');
  db.run('UPDATE users SET password_hash=?, must_change_password=0 WHERE id=?', hash(newPw), user.id);
  audit.log(db, user.id, 'UPDATE', 'users', user.id, null, { password: 'changed' });
}

module.exports = { ROLES, hash, ensureAdmin, createUser, login, changePassword };

'use strict';
const audit = require('./audit');
const util = require('./util');
const { next } = require('./numbering');
const MODES = ['CASH', 'UPI', 'CARD', 'BANK_TRANSFER', 'INSURANCE_TPA'];

function openPatient(db, id) {
  const p = db.get('SELECT * FROM patients WHERE id=? AND is_deleted=0', id);
  if (!p) throw new Error('Patient not found');
  if (p.status === 'CLOSED') throw new Error('Patient file is closed - Admin must reopen');
  return p;
}
const fin = (db, id) => db.get('SELECT * FROM v_patient_financials WHERE patient_id=?', id);
// Cash goes to the Cash book, everything else to the Bank book.
const accountFor = (db, mode) => db.get('SELECT id FROM accounts WHERE kind=? ORDER BY id LIMIT 1', mode === 'CASH' ? 'CASH' : 'BANK')?.id ?? null;
const dateOr = (d) => { d = d || util.ymd(); if (!util.isDate(d)) throw new Error('Invalid date'); return d; };

function createBill(db, actor, { patient_id, bill_date, items, discount = 0, discount_reason }) {
  openPatient(db, patient_id);
  if (!Array.isArray(items) || !items.length) throw new Error('Add at least one item');
  const lines = items.map((it, i) => {
    const qty = it.qty ?? 1;
    if (!it.description) throw new Error(`Item ${i + 1}: description required`);
    if (!Number.isInteger(qty) || qty <= 0) throw new Error(`Item ${i + 1}: quantity must be a whole number`);
    if (!Number.isInteger(it.rate) || it.rate < 0) throw new Error(`Item ${i + 1}: rate is invalid`);
    return { ...it, qty, amount: qty * it.rate };
  });
  const subtotal = lines.reduce((s, l) => s + l.amount, 0);
  if (!Number.isInteger(discount) || discount < 0 || discount > subtotal) throw new Error('Discount cannot be more than the bill amount');
  if (discount > 0 && !discount_reason) throw new Error('Discount reason is required');
  const total = subtotal - discount;
  return db.tx(() => {
    const bill_no = next(db, 'BILL');
    const id = Number(db.run(`INSERT INTO bills(bill_no,patient_id,bill_date,subtotal,discount,discount_reason,total,created_by)
                              VALUES (?,?,?,?,?,?,?,?)`, bill_no, patient_id, dateOr(bill_date), subtotal, discount, discount_reason ?? null, total, actor.id).lastInsertRowid);
    const feeHead = db.get("SELECT id FROM expense_heads WHERE name='Doctor Fee'").id;
    for (const l of lines) {
      const itemId = Number(db.run('INSERT INTO bill_items(bill_id,service_id,description,doctor_id,qty,rate,doctor_percent_bp,amount) VALUES (?,?,?,?,?,?,?,?)',
        id, l.service_id ?? null, l.description, l.doctor_id ?? null, l.qty, l.rate, l.doctor_percent_bp ?? null, l.amount).lastInsertRowid);
      if (l.doctor_id) {                                   // doctor's % share is booked automatically
        const d = db.get('SELECT * FROM doctors WHERE id=?', l.doctor_id);
        if (!d) throw new Error('Doctor not found');
        const bp = l.doctor_percent_bp ?? d.percent_bp;
        const fee = Math.round((l.amount * bp) / 10000);
        if (fee > 0) db.run(`INSERT INTO patient_expenses(patient_id,head_id,exp_date,amount,doctor_id,description,source,bill_item_id,created_by)
                             VALUES (?,?,?,?,?,?, 'AUTO_DOCTOR',?,?)`, patient_id, feeHead, dateOr(bill_date), fee, l.doctor_id,
          `${d.name} ${(bp / 100).toFixed(bp % 100 ? 2 : 0)}% of ${l.description}`, itemId, actor.id);
      }
    }
    audit.log(db, actor.id, 'CREATE', 'bills', id, null, { bill_no, patient_id, subtotal, discount, total });
    return { id, bill_no, total };
  });
}

function receivePayment(db, actor, { patient_id, bill_id, pay_type, mode, amount, reference_no, tpa_name, pay_date }) {
  openPatient(db, patient_id);
  util.posInt(amount, 'Amount');
  if (!MODES.includes(mode)) throw new Error('Choose a payment mode');
  if (!['ADVANCE', 'PART', 'FULL'].includes(pay_type)) throw new Error('Choose Advance / Part / Full');
  if (mode === 'INSURANCE_TPA' && !tpa_name) throw new Error('TPA / insurance company name is required');
  if (bill_id && !db.get('SELECT id FROM bills WHERE id=? AND patient_id=? AND is_void=0', bill_id, patient_id)) throw new Error('Bill does not belong to this patient');
  const due = fin(db, patient_id).due;
  if (pay_type === 'PART' && !(due > 0 && amount < due)) throw new Error(due > 0 ? 'Part payment must be less than the due amount - use Full' : 'Nothing is due - take it as Advance');
  if (pay_type === 'FULL' && (due <= 0 || amount !== due)) throw new Error(due > 0 ? `Full payment must equal the due amount (${util.inr(due)})` : 'Nothing is due - take it as Advance');
  return db.tx(() => {
    const receipt_no = next(db, 'RCP');
    const id = Number(db.run(`INSERT INTO payments(receipt_no,patient_id,bill_id,pay_date,pay_type,mode,amount,account_id,reference_no,tpa_name,created_by)
      VALUES (?,?,?,?,?,?,?,?,?,?,?)`, receipt_no, patient_id, bill_id ?? null, dateOr(pay_date), pay_type, mode, amount, accountFor(db, mode), reference_no ?? null, tpa_name ?? null, actor.id).lastInsertRowid);
    audit.log(db, actor.id, 'CREATE', 'payments', id, null, { receipt_no, patient_id, pay_type, mode, amount });
    return { id, receipt_no, due_after: due - amount };
  });
}

function refund(db, actor, { patient_id, payment_id, mode, amount, reason, refund_date }) {
  openPatient(db, patient_id);
  util.posInt(amount, 'Amount');
  if (!MODES.includes(mode)) throw new Error('Choose a payment mode');
  if (!reason) throw new Error('Refund reason is required');
  if (amount > fin(db, patient_id).net_received) throw new Error('Refund is more than the money received from this patient');
  return db.tx(() => {
    const refund_no = next(db, 'REF');
    const id = Number(db.run('INSERT INTO refunds(refund_no,patient_id,payment_id,refund_date,mode,amount,account_id,reason,created_by) VALUES (?,?,?,?,?,?,?,?,?)',
      refund_no, patient_id, payment_id ?? null, dateOr(refund_date), mode, amount, accountFor(db, mode), reason, actor.id).lastInsertRowid);
    audit.log(db, actor.id, 'CREATE', 'refunds', id, null, { refund_no, patient_id, amount, reason });
    return { id, refund_no };
  });
}

function creditNote(db, actor, { patient_id, bill_id, amount, reason, cn_date }) {
  openPatient(db, patient_id);
  util.posInt(amount, 'Amount');
  if (!reason) throw new Error('Credit note reason is required');
  const b = db.get('SELECT * FROM bills WHERE id=? AND patient_id=? AND is_void=0', bill_id, patient_id);
  if (!b) throw new Error('Choose the bill this credit note is against');
  const used = db.get('SELECT COALESCE(SUM(amount),0) s FROM credit_notes WHERE bill_id=? AND is_void=0', bill_id).s;
  if (amount > b.total - used) throw new Error('Credit note is more than the bill amount left');
  return db.tx(() => {
    const cn_no = next(db, 'CN');
    const id = Number(db.run('INSERT INTO credit_notes(cn_no,patient_id,bill_id,cn_date,amount,reason,created_by) VALUES (?,?,?,?,?,?,?)',
      cn_no, patient_id, bill_id, dateOr(cn_date), amount, reason, actor.id).lastInsertRowid);
    audit.log(db, actor.id, 'CREATE', 'credit_notes', id, null, { cn_no, bill_id, amount, reason });
    return { id, cn_no };
  });
}

// Admin only. Nothing is deleted - the row is flagged, reason kept, audit written.
const VOIDABLE = {
  bills: ['is_void', 'void_reason'], payments: ['is_void', 'void_reason'], refunds: ['is_void', 'void_reason'],
  credit_notes: ['is_void', 'void_reason'], doctor_settlements: ['is_void', 'void_reason'],
  fixed_cost_allocations: ['is_void', 'void_reason'],
  patient_expenses: ['is_deleted', 'delete_reason'], hospital_expenses: ['is_deleted', 'delete_reason'],
};
function voidRecord(db, actor, table, id, reason) {
  const cols = VOIDABLE[table];
  if (!cols) throw new Error('This record type cannot be voided');
  if (!reason || reason.trim().length < 3) throw new Error('A reason is required');
  const old = db.get(`SELECT * FROM ${table} WHERE id=?`, id);
  if (!old) throw new Error('Record not found');
  if (old[cols[0]]) throw new Error('Already voided');
  db.tx(() => {
    db.run(`UPDATE ${table} SET ${cols[0]}=1, ${cols[1]}=? WHERE id=?`, reason.trim(), id);
    if (table === 'bills') db.run('UPDATE patient_expenses SET is_deleted=1, delete_reason=? WHERE bill_item_id IN (SELECT id FROM bill_items WHERE bill_id=?)', 'Bill voided', id);
    if (table === 'fixed_cost_allocations') db.run('UPDATE patient_expenses SET is_deleted=1, delete_reason=? WHERE allocation_id=?', 'Allocation voided', id);
    audit.log(db, actor.id, 'VOID', table, id, old, { reason });
  });
  return { id };
}
module.exports = { MODES, createBill, receivePayment, refund, creditNote, voidRecord, accountFor };

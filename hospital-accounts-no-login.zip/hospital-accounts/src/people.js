'use strict';
const audit = require('./audit');
const util = require('./util');
const { next } = require('./numbering');
const { accountFor } = require('./billing');

function saveDoctor(db, actor, d) {
  if (!d.name?.trim()) throw new Error('Doctor name is required');
  const fixed = d.fixed_fee ?? 0, bp = d.percent_bp ?? 0;
  if (!Number.isInteger(fixed) || fixed < 0) throw new Error('Fixed fee is invalid');
  if (!Number.isInteger(bp) || bp < 0 || bp > 10000) throw new Error('Percentage must be between 0 and 100');
  if (d.id) {
    db.run('UPDATE doctors SET name=?,speciality=?,mobile=?,fixed_fee=?,percent_bp=?,is_active=? WHERE id=?', d.name.trim(), d.speciality ?? null, d.mobile ?? null, fixed, bp, d.is_active ?? 1, d.id);
    audit.log(db, actor.id, 'UPDATE', 'doctors', d.id, null, d); return { id: d.id };
  }
  const id = Number(db.run('INSERT INTO doctors(name,speciality,mobile,fixed_fee,percent_bp) VALUES (?,?,?,?,?)', d.name.trim(), d.speciality ?? null, d.mobile ?? null, fixed, bp).lastInsertRowid);
  audit.log(db, actor.id, 'CREATE', 'doctors', id, null, d); return { id };
}
function saveWard(db, actor, w) {
  if (!w.name?.trim()) throw new Error('Ward name is required');
  if (w.id) { db.run('UPDATE wards SET name=?,daily_rate=? WHERE id=?', w.name.trim(), w.daily_rate ?? 0, w.id); return { id: w.id }; }
  const id = Number(db.run('INSERT INTO wards(name,daily_rate) VALUES (?,?)', w.name.trim(), w.daily_rate ?? 0).lastInsertRowid);
  audit.log(db, actor.id, 'CREATE', 'wards', id, null, w); return { id };
}
function saveService(db, actor, s) {
  if (!s.name?.trim()) throw new Error('Service name is required');
  const id = Number(db.run('INSERT INTO service_items(name,category,default_rate) VALUES (?,?,?)', s.name.trim(), s.category ?? null, s.default_rate ?? 0).lastInsertRowid);
  audit.log(db, actor.id, 'CREATE', 'service_items', id, null, s); return { id };
}
function saveStaff(db, actor, s) {
  if (!s.name?.trim()) throw new Error('Staff name is required');
  if (s.id) { db.run('UPDATE staff SET name=?,designation=?,monthly_salary=?,is_active=? WHERE id=?', s.name.trim(), s.designation ?? null, s.monthly_salary ?? 0, s.is_active ?? 1, s.id); return { id: s.id }; }
  const id = Number(db.run('INSERT INTO staff(name,designation,monthly_salary) VALUES (?,?,?)', s.name.trim(), s.designation ?? null, s.monthly_salary ?? 0).lastInsertRowid);
  audit.log(db, actor.id, 'CREATE', 'staff', id, null, s); return { id };
}

// Paying a doctor what the hospital owes. Cannot pay more than payable.
function settleDoctor(db, actor, { doctor_id, amount, mode = 'CASH', settle_date, note }) {
  util.posInt(amount, 'Amount');
  const d = db.get('SELECT * FROM v_doctor_payable WHERE doctor_id=?', doctor_id);
  if (!d) throw new Error('Doctor not found');
  if (amount > d.payable) throw new Error(`Only ${util.inr(d.payable)} is payable to ${d.name}`);
  return db.tx(() => {
    const settle_no = next(db, 'SET');
    const id = Number(db.run('INSERT INTO doctor_settlements(settle_no,doctor_id,settle_date,amount,mode,account_id,note,created_by) VALUES (?,?,?,?,?,?,?,?)',
      settle_no, doctor_id, settle_date || util.ymd(), amount, mode, accountFor(db, mode), note ?? null, actor.id).lastInsertRowid);
    audit.log(db, actor.id, 'CREATE', 'doctor_settlements', id, null, { settle_no, doctor_id, amount });
    return { id, settle_no, payable_after: d.payable - amount };
  });
}

// One entry per staff per month. Counts in overall P&L (not in patient cost - allocate "Staff Salary" for that).
function paySalary(db, actor, { staff_id, salary_month, amount, paid_date, mode = 'CASH' }) {
  if (!/^\d{4}-\d{2}$/.test(salary_month || '')) throw new Error('Month must look like 2026-11');
  const s = db.get('SELECT * FROM staff WHERE id=?', staff_id);
  if (!s) throw new Error('Staff not found');
  amount = amount ?? s.monthly_salary;
  util.posInt(amount, 'Amount');
  if (db.get('SELECT id FROM staff_salaries WHERE staff_id=? AND salary_month=?', staff_id, salary_month)) throw new Error(`${s.name}'s salary for ${salary_month} is already entered`);
  const id = db.tx(() => {
    const id = Number(db.run('INSERT INTO staff_salaries(staff_id,salary_month,amount,paid_date,mode,account_id) VALUES (?,?,?,?,?,?)',
      staff_id, salary_month, amount, paid_date || util.ymd(), mode, accountFor(db, mode)).lastInsertRowid);
    audit.log(db, actor.id, 'CREATE', 'staff_salaries', id, null, { staff_id, salary_month, amount });
    return id;
  });
  return { id };
}

function masters(db) {
  return {
    doctors: db.all('SELECT * FROM doctors WHERE is_active=1 ORDER BY name'),
    wards: db.all('SELECT * FROM wards ORDER BY name'),
    heads: db.all('SELECT * FROM expense_heads WHERE is_active=1 ORDER BY scope,name'),
    accounts: db.all('SELECT * FROM accounts ORDER BY id'),
    services: db.all('SELECT * FROM service_items WHERE is_active=1 ORDER BY name'),
    staff: db.all('SELECT * FROM staff WHERE is_active=1 ORDER BY name'),
  };
}
module.exports = { saveDoctor, saveWard, saveService, saveStaff, settleDoctor, paySalary, masters };

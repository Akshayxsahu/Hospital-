'use strict';
const audit = require('./audit');
const util = require('./util');
const TYPES = ['OPD', 'IPD', 'EMERGENCY', 'DAYCARE'];
const FIELDS = ['name', 'age', 'gender', 'mobile', 'address', 'id_type', 'aadhar', 'ayushman_id', 'guardian_name', 'doctor_id', 'staff_id',
  'ward_id', 'bed_no', 'patient_type', 'admission_date', 'discharge_date'];
const ID_TYPES = ['AADHAR', 'AYUSHMAN'];

const today = () => util.ymd();

function validate(p, partial = false) {
  const clean = {};
  for (const f of FIELDS) if (p[f] !== undefined && p[f] !== '') clean[f] = typeof p[f] === 'string' ? p[f].trim() : p[f];
  if (!partial || 'name' in clean) if (!clean.name) throw new Error('Patient name is required');
  if (!partial || 'patient_type' in clean) if (!TYPES.includes(clean.patient_type)) throw new Error('Patient type must be OPD / IPD / Emergency / Day Care');
  if (clean.mobile && !/^\d{10}$/.test(clean.mobile)) throw new Error('Mobile must be 10 digits');
  if (clean.id_type && !ID_TYPES.includes(clean.id_type)) throw new Error('ID proof must be Aadhar or Ayushman card');
  if (clean.aadhar && !/^\d{12}$/.test(clean.aadhar)) throw new Error('Aadhar must be 12 digits');
  // Ayushman / PM-JAY IDs come in several formats (PMJAY ID, family ID, ABHA number), so only the characters are checked.
  if (clean.ayushman_id) { clean.ayushman_id = clean.ayushman_id.replace(/\s+/g, '').toUpperCase(); if (!/^[A-Z0-9-]{6,30}$/.test(clean.ayushman_id)) throw new Error('Ayushman card ID: use 6-30 letters / digits (no spaces or symbols)'); }
  if (clean.age != null && !(Number(clean.age) >= 0 && Number(clean.age) <= 120)) throw new Error('Age looks wrong');
  if (clean.gender && !['M', 'F', 'O'].includes(clean.gender)) throw new Error('Gender must be M / F / O');
  return clean;
}

// One ID proof is mandatory: Aadhar (12 digits) or Ayushman card ID. Checked on the complete record.
function checkAssigned(db, p) {
  if (p.doctor_id && !db.get('SELECT id FROM doctors WHERE id=?', p.doctor_id)) throw new Error('Assigned doctor not found');
  if (p.staff_id && !db.get('SELECT id FROM staff WHERE id=?', p.staff_id)) throw new Error('Assigned staff member not found');
}
function requireId(p) {
  if (!ID_TYPES.includes(p.id_type)) throw new Error('Choose the ID proof: Aadhar or Ayushman card (mandatory)');
  if (p.id_type === 'AADHAR' && !p.aadhar) throw new Error('Aadhar number is mandatory (12 digits)');
  if (p.id_type === 'AYUSHMAN' && !p.ayushman_id) throw new Error('Ayushman card ID is mandatory');
}

// PAT-2026-0001 — number is taken inside the same transaction as the insert: no gaps, no duplicates.
function nextUhid(db, now) {
  const year = now.getFullYear();
  const row = db.get(`INSERT INTO number_series(series,year,last_no) VALUES ('PAT',?,1)
                      ON CONFLICT(series,year) DO UPDATE SET last_no=last_no+1 RETURNING last_no`, year);
  return `PAT-${year}-${String(row.last_no).padStart(4, '0')}`;
}

// Same mobile, Aadhar or Ayushman ID already registered? Returned so the screen can ask "open existing patient?"
function findDuplicates(db, { mobile, aadhar, ayushman_id }) {
  if (!mobile && !aadhar && !ayushman_id) return [];
  return db.all(`SELECT id,uhid,name,mobile FROM patients WHERE is_deleted=0 AND
                 ((? IS NOT NULL AND mobile=?) OR (? IS NOT NULL AND aadhar=?) OR (? IS NOT NULL AND ayushman_id=?)) LIMIT 5`,
    mobile ?? null, mobile ?? null, aadhar ?? null, aadhar ?? null, ayushman_id ?? null, ayushman_id ?? null);
}

function create(db, actor, input, { now = util.now(), allowDuplicate = false } = {}) {
  const p = validate(input);
  requireId(p); checkAssigned(db, p);
  p.admission_date = p.admission_date || today();
  if (!allowDuplicate) {
    const dup = findDuplicates(db, p);
    if (dup.length) { const e = new Error('Patient with same mobile/Aadhar already exists'); e.code = 'DUPLICATE'; e.matches = dup; throw e; }
  }
  return db.tx(() => {
    const uhid = nextUhid(db, now);
    const cols = Object.keys(p);
    const r = db.run(`INSERT INTO patients(uhid,created_by,${cols.join(',')}) VALUES (?,?,${cols.map(() => '?').join(',')})`,
      uhid, actor.id, ...cols.map(c => p[c]));
    const id = Number(r.lastInsertRowid);
    audit.log(db, actor.id, 'CREATE', 'patients', id, null, { uhid, ...p });
    return { id, uhid };
  });
}

function update(db, actor, id, changes) {
  const old = db.get('SELECT * FROM patients WHERE id=? AND is_deleted=0', id);
  if (!old) throw new Error('Patient not found');
  if (old.status === 'CLOSED' && actor.role !== 'ADMIN') throw new Error('Closed patient can only be edited by Admin');
  const p = validate(changes, true);
  checkAssigned(db, p); requireId({ ...old, ...p });                       // an old record without an ID proof must get one when it is next edited
  const cols = Object.keys(p).filter(c => p[c] !== old[c]);
  if (!cols.length) return { id, changed: 0 };
  db.tx(() => {
    db.run(`UPDATE patients SET ${cols.map(c => c + '=?').join(',')} WHERE id=?`, ...cols.map(c => p[c]), id);
    audit.log(db, actor.id, 'UPDATE', 'patients', id,
      Object.fromEntries(cols.map(c => [c, old[c]])), Object.fromEntries(cols.map(c => [c, p[c]])));
  });
  return { id, changed: cols.length };
}

// Search by UHID, name, mobile or Aadhar — one box, auto-detects what was typed.
function search(db, q, limit = 50) {
  q = String(q || '').trim();
  // Doctor and staff are shown next to every patient in the list.
  const sel = `SELECT p.id,p.uhid,p.name,p.age,p.gender,p.mobile,p.patient_type,p.admission_date,p.status,d.name AS doctor_name,s.name AS staff_name
               FROM patients p LEFT JOIN doctors d ON d.id=p.doctor_id LEFT JOIN staff s ON s.id=p.staff_id WHERE p.is_deleted=0`;
  if (!q) return db.all(`${sel} ORDER BY p.id DESC LIMIT ?`, limit);
  const esc = q.replace(/[%_\\]/g, m => '\\' + m);
  if (/^\d+$/.test(q)) {
    return db.all(`${sel} AND (p.mobile LIKE ? ESCAPE '\\' OR p.aadhar LIKE ? ESCAPE '\\' OR p.ayushman_id LIKE ? ESCAPE '\\' OR p.uhid LIKE ? ESCAPE '\\')
      ORDER BY p.id DESC LIMIT ?`, esc + '%', esc + '%', esc + '%', '%' + esc, limit);   // uhid: typing "0001" finds PAT-2026-0001
  }
  if (/^(pat|hosp)/i.test(q)) {
    return db.all(`${sel} AND p.uhid LIKE ? ESCAPE '\\' ORDER BY p.id DESC LIMIT ?`, esc.toUpperCase() + '%', limit);
  }
  return db.all(`${sel} AND p.name LIKE ? ESCAPE '\\' COLLATE NOCASE ORDER BY p.name LIMIT ?`, '%' + esc + '%', limit);
}

// Full profile + financial summary in one call (financials only if caller may see them).
function profile(db, id, { withFinance }) {
  const p = db.get(`SELECT p.*, d.name AS doctor_name, d.speciality AS doctor_speciality, d.mobile AS doctor_mobile,
                    s.name AS staff_name, s.designation AS staff_designation, s.mobile AS staff_mobile, w.name AS ward_name FROM patients p
                    LEFT JOIN doctors d ON d.id=p.doctor_id LEFT JOIN staff s ON s.id=p.staff_id LEFT JOIN wards w ON w.id=p.ward_id
                    WHERE p.id=? AND p.is_deleted=0`, id);
  if (!p) throw new Error('Patient not found');
  const out = { patient: p };
  if (withFinance) {
    out.finance = db.get('SELECT * FROM v_patient_financials WHERE patient_id=?', id);
    out.payments = db.all('SELECT * FROM payments WHERE patient_id=? AND is_void=0 ORDER BY pay_date,id', id);
    out.bills = db.all('SELECT * FROM bills WHERE patient_id=? AND is_void=0 ORDER BY bill_date,id', id);
    out.expenses = db.all(`SELECT e.*, h.name AS head FROM patient_expenses e JOIN expense_heads h ON h.id=e.head_id
                           WHERE e.patient_id=? AND e.is_deleted=0 ORDER BY e.exp_date,e.id`, id);
  }
  return out;
}

function discharge(db, actor, id, date = util.ymd()) {
  const p = db.get('SELECT * FROM patients WHERE id=? AND is_deleted=0', id);
  if (!p) throw new Error('Patient not found');
  if (p.status === 'CLOSED') throw new Error('Patient file is closed');
  if (!util.isDate(date)) throw new Error('Invalid discharge date');
  if (date < p.admission_date) throw new Error('Discharge date is before admission date');
  db.tx(() => {
    db.run("UPDATE patients SET discharge_date=?, status='DISCHARGED' WHERE id=?", date, id);
    audit.log(db, actor.id, 'UPDATE', 'patients', id, { status: p.status, discharge_date: p.discharge_date }, { status: 'DISCHARGED', discharge_date: date });
  });
  return { id, discharge_date: date };
}

// Admin closes the file: no more entries. Needs zero balance unless forced.
function close(db, actor, id, { force = false } = {}) {
  const f = db.get('SELECT * FROM v_patient_financials WHERE patient_id=?', id);
  if (!f) throw new Error('Patient not found');
  if (f.due !== 0 && !force) throw new Error('Balance is not zero - settle first or close with force');
  db.tx(() => {
    db.run("UPDATE patients SET status='CLOSED' WHERE id=?", id);
    audit.log(db, actor.id, 'UPDATE', 'patients', id, null, { status: 'CLOSED', forced: !!force });
  });
  return { id };
}
module.exports = { create, update, search, profile, findDuplicates, discharge, close };

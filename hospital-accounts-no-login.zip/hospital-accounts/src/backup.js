'use strict';
const fs = require('fs');
const path = require('path');
const dbm = require('./db');
const audit = require('./audit');
const util = require('./util');

// Consistent snapshot of the live database into one file (safe while the app is running).
function backupNow(db, dir, kind = 'AUTO', userId = null) {
  fs.mkdirSync(dir, { recursive: true });
  const file = path.join(dir, `hospital-${util.stamp()}.db`);
  if (fs.existsSync(file)) fs.unlinkSync(file);
  db.exec(`VACUUM INTO '${file.replace(/'/g, "''")}'`);
  const size = fs.statSync(file).size;
  db.run('INSERT INTO backup_log(kind,file_path,size_bytes) VALUES (?,?,?)', kind, file, size);
  audit.log(db, userId, 'BACKUP', 'backup_log', null, null, { kind, file });
  if (kind === 'AUTO') prune(dir, 30);
  return { file, size };
}
function prune(dir, keep) {                                  // keep newest N automatic backups
  const files = fs.readdirSync(dir).filter((f) => /^hospital-\d{8}-\d{6}\.db$/.test(f)).sort();
  files.slice(0, Math.max(0, files.length - keep)).forEach((f) => fs.unlinkSync(path.join(dir, f)));
}
// Runs at app start and then every hour: first call each day makes the daily backup.
function autoBackupIfNeeded(db, dir) {
  const done = db.get("SELECT id FROM backup_log WHERE kind='AUTO' AND status='OK' AND date(at)=?", util.ymd());
  return done ? null : backupNow(db, dir, 'AUTO');
}
function verify(file) {
  const d = dbm.open(file, { upgrade: false });   // look only - never modify the user's backup file
  try {
    if (d.get('PRAGMA integrity_check')?.integrity_check !== 'ok') throw new Error('Backup file is damaged');
    if (!d.get("SELECT name FROM sqlite_master WHERE name='patients'")) throw new Error('This is not a hospital backup file');
    return { patients: d.get('SELECT COUNT(*) n FROM patients').n };
  } finally { d.close(); }
}
// Restore = stage the file; it is swapped in at next start (the open DB cannot be replaced while running).
function stageRestore(file, dataDir) {
  const info = verify(file);
  fs.copyFileSync(file, path.join(dataDir, 'restore.pending'));
  return info;
}
function applyPendingRestore(dataDir, dbFile = 'hospital.db') {
  const pend = path.join(dataDir, 'restore.pending');
  if (!fs.existsSync(pend)) return false;
  const cur = path.join(dataDir, dbFile);
  if (fs.existsSync(cur)) fs.renameSync(cur, path.join(dataDir, `before-restore-${util.stamp()}.db`));
  for (const ext of ['-wal', '-shm']) if (fs.existsSync(cur + ext)) fs.unlinkSync(cur + ext);
  fs.renameSync(pend, cur);
  return true;
}
module.exports = { backupNow, autoBackupIfNeeded, verify, stageRestore, applyPendingRestore };

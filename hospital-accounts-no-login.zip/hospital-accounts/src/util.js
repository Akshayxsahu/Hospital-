'use strict';
let override = null;
const pad = (n) => String(n).padStart(2, '0');
const now = () => (override ? new Date(override) : new Date());
const ymd = (d = now()) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;   // LOCAL date (not UTC) - matters at midnight in India
const stamp = (d = now()) => `${d.getFullYear()}${pad(d.getMonth() + 1)}${pad(d.getDate())}-${pad(d.getHours())}${pad(d.getMinutes())}${pad(d.getSeconds())}`;
const daysBetween = (a, b) => Math.round((Date.UTC(...b.split('-').map((v, i) => (i === 1 ? v - 1 : +v))) - Date.UTC(...a.split('-').map((v, i) => (i === 1 ? v - 1 : +v)))) / 864e5);
const isDate = (s) => /^\d{4}-\d{2}-\d{2}$/.test(s) && !isNaN(new Date(s));
const posInt = (v, label) => { if (!Number.isInteger(v) || v <= 0) throw new Error(`${label} must be a positive amount`); return v; };
const esc = (s) => String(s ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const inr = (paise) => (paise / 100).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
module.exports = { setNow: (d) => { override = d; }, now, ymd, stamp, daysBetween, isDate, posInt, esc, inr };

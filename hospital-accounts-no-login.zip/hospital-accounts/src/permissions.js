'use strict';
// One table decides who can do what. Enforced in the main process (not just hidden buttons).
const ALL = ['ADMIN', 'ACCOUNTANT', 'RECEPTIONIST'];
const FIN = ['ADMIN', 'ACCOUNTANT'];
const PERMISSIONS = {
  'patient.create': ALL, 'patient.update': ALL, 'patient.search': ALL, 'patient.view': ALL,
  'finance.view':   FIN,                       // sees billed / received / profit boxes
  'bill.create':    FIN, 'payment.create': FIN, 'refund.create': FIN, 'expense.create': FIN,
  'doctor.settle':  FIN, 'staff.salary': FIN,
  'report.view':    FIN,
  'master.edit':    FIN,
  'void.any':       ['ADMIN'],
  'user.manage':    ['ADMIN'], 'audit.view': ['ADMIN'], 'backup.manage': ['ADMIN'], 'settings.edit': ['ADMIN'],
};
function can(role, action) { return (PERMISSIONS[action] || []).includes(role); }
function require_(role, action) {
  if (!can(role, action)) { const e = new Error(`Not allowed: ${action}`); e.code = 'FORBIDDEN'; throw e; }
}
module.exports = { PERMISSIONS, can, require: require_ };

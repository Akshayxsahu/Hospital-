'use strict';
const { contextBridge, ipcRenderer } = require('electron');
const inv = (ch) => (...a) => ipcRenderer.invoke(ch, ...a);
contextBridge.exposeInMainWorld('api', (name, ...args) => ipcRenderer.invoke('api', name, args));
contextBridge.exposeInMainWorld('native', {
  pickFile: inv('pickFile'), pickBackupFile: inv('pickBackupFile'), pickFolder: inv('pickFolder'), attachFile: inv('attachFile'), openAttachment: inv('openAttachment'),
  exportXlsx: inv('exportXlsx'), exportPdf: inv('exportPdf'), printDoc: inv('printDoc'), backupToFolder: inv('backupToFolder'), restartApp: inv('restartApp'),
});

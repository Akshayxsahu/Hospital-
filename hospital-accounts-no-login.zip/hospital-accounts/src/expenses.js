'use strict';
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const audit = require('./audit');
const util = require('./util');
const { accountFor } = require('./billing');

function head(db, id) { const h = db.get('SELECT * FROM expense_heads WHERE id=? AND is_active=1', id); if (!h) throw new Error('Expense head not found'); return h; }

function addHead(db, actor, { name, scope = 'PATIENT' }) {
  name = String(name || '').trim();
  if (!name) throw new Error('Head name is required');
  if (!['PATIENT', 'FIXED', 'HOSPITAL'].includes(scope)) throw new Error('Invalid head type');
  if (db.get('SELECT id FROM expense_heads WHERE name=? COLLATE NOCASE', name)) throw new Error('This head already exists');
  const id = Number(db.run('INSERT INTO expense_heads(name,scope) VALUES (?,?)', name, scope).lastInsertRowid);
  audit.log(db, actor.id, 'CREATE', 'expense_heads', id, null, { name, scope });
  return { id };
}

function addPatientExpense(db, actor, { patient_id, head_id, exp_date, amount, doctor_id, vendor, description, mode = 'CASH' }) {
  const p = db.get('SELECT * FROM patients WHERE id=? AND is_deleted=0', patient_id);
  if (!p) throw new Error('Patient not found');
  if (p.status === 'CLOSED') throw new Error('Patient file is closed - Admin must reopen');
  const h = head(db, head_id);
  if (h.scope !== 'PATIENT') throw new Error(`"${h.name}" is an overhead head - use Fixed Cost Allocation`);
  util.posInt(amount, 'Amount');
  if (h.name === 'Doctor Fee' && !doctor_id) throw new Error('Choose the doctor for a Doctor Fee');
  if (doctor_id && !db.get('SELECT id FROM doctors WHERE id=?', doctor_id)) throw new Error('Doctor not found');
  exp_date = exp_date || util.ymd();
  if (!util.isDate(exp_date)) throw new Error('Invalid date');
  // Doctor fees are payable (cash leaves at settlement); everything else is paid now from cash/bank.
  const account = doctor_id ? null : accountFor(db, mode);
  return db.tx(() => {
    const id = Number(db.run(`INSERT INTO patient_expenses(patient_id,head_id,exp_date,amount,doctor_id,vendor,description,source,account_id,created_by)
      VALUES (?,?,?,?,?,?,?, 'MANUAL',?,?)`, patient_id, head_id, exp_date, amount, doctor_id ?? null, vendor ?? null, description ?? null, account, actor.id).lastInsertRowid);
    audit.log(db, actor.id, 'CREATE', 'patient_expenses', id, null, { patient_id, head: h.name, amount, doctor_id });
    return { id };
  });
}

const OK_EXT = { '.pdf': 'application/pdf', '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg' };
// Copies a bill/prescription into <attachDir>/YYYY/MM/ and records it against the expense.
function attach(db, actor, expenseId, srcPath, attachDir) {
  const e = db.get('SELECT * FROM patient_expenses WHERE id=? AND is_deleted=0', expenseId);
  if (!e) throw new Error('Expense not found');
  const ext = path.extname(srcPath).toLowerCase();
  if (!OK_EXT[ext]) throw new Error('Only PDF, PNG or JPG files can be attached');
  const stat = fs.statSync(srcPath);
  if (stat.size > 10 * 1024 * 1024) throw new Error('File is larger than 10 MB');
  const buf = fs.readFileSync(srcPath);
  const sha256 = crypto.createHash('sha256').update(buf).digest('hex');
  const d = util.ymd();
  const rel = path.join(d.slice(0, 4), d.slice(5, 7), `${expenseId}-${Date.now()}-${path.basename(srcPath).replace(/[^\w.\-]/g, '_')}`);
  fs.mkdirSync(path.dirname(path.join(attachDir, rel)), { recursive: true });
  fs.writeFileSync(path.join(attachDir, rel), buf);
  const id = Number(db.run('INSERT INTO expense_attachments(expense_id,file_name,file_path,mime_type,sha256) VALUES (?,?,?,?,?)',
    expenseId, path.basename(srcPath), rel, OK_EXT[ext], sha256).lastInsertRowid);
  audit.log(db, actor.id, 'CREATE', 'expense_attachments', id, null, { expense_id: expenseId, file: path.basename(srcPath) });
  return { id, path: rel };
}
const attachments = (db, expenseId) => db.all('SELECT * FROM expense_attachments WHERE expense_id=?', expenseId);

function addHospitalExpense(db, actor, { head_id, exp_date, amount, mode = 'CASH', description }) {
  const h = head(db, head_id);
  if (h.scope === 'PATIENT') throw new Error(`"${h.name}" is a patient expense - add it on the patient`);
  util.posInt(amount, 'Amount');
  exp_date = exp_date || util.ymd();
  if (!util.isDate(exp_date)) throw new Error('Invalid date');
  const id = db.tx(() => {
    const id = Number(db.run('INSERT INTO hospital_expenses(head_id,exp_date,amount,mode,account_id,description,created_by) VALUES (?,?,?,?,?,?,?)',
      head_id, exp_date, amount, mode, accountFor(db, mode), description ?? null, actor.id).lastInsertRowid);
    audit.log(db, actor.id, 'CREATE', 'hospital_expenses', id, null, { head: h.name, amount, exp_date });
    return id;
  });
  return { id };
}

// ---- Fixed-cost allocation --------------------------------------------------------------
// Splits `total` (paise) by weights so the parts add up EXACTLY to the total (largest remainder).
function splitExact(total, weights) {
  const W = weights.reduce((a, b) => a + b, 0);
  if (W <= 0) return weights.map(() => 0);
  const parts = weights.map((w, i) => ({ i, base: Math.floor((total * w) / W), frac: ((total * w) % W) / W }));
  let left = total - parts.reduce((s, p) => s + p.base, 0);
  [...parts].sort((a, b) => b.frac - a.frac || a.i - b.i).slice(0, left).forEach((p) => { p.base += 1; });
  return parts.map((p) => p.base);
}

function allocationPreview(db, { head_id, period_from, period_to, total_amount, method = 'PER_PATIENT_DAY', manual }) {
  const h = head(db, head_id);
  if (h.scope !== 'FIXED') throw new Error(`"${h.name}" is not a fixed-cost head`);
  if (!util.isDate(period_from) || !util.isDate(period_to) || period_to < period_from) throw new Error('Check the period dates');
  util.posInt(total_amount, 'Total amount');
  if (!['PER_PATIENT_DAY', 'EQUAL', 'MANUAL'].includes(method)) throw new Error('Invalid method');
  const clash = db.get(`SELECT id FROM fixed_cost_allocations WHERE head_id=? AND is_void=0 AND period_from<=? AND period_to>=?`, head_id, period_to, period_from);
  if (clash) throw new Error(`${h.name} is already allocated for an overlapping period (allocation #${clash.id}). Void it first to redo.`);
  const pts = db.all(`SELECT id,uhid,name,admission_date,discharge_date FROM patients
                      WHERE is_deleted=0 AND admission_date<=? AND (discharge_date IS NULL OR discharge_date>=?) ORDER BY id`, period_to, period_from);
  if (!pts.length) throw new Error('No patients were admitted in this period');
  const rows = pts.map((p) => {
    const s = p.admission_date > period_from ? p.admission_date : period_from;
    const e = p.discharge_date && p.discharge_date < period_to ? p.discharge_date : period_to;
    return { patient_id: p.id, uhid: p.uhid, name: p.name, days: Math.max(1, util.daysBetween(s, e) + 1) };
  });
  let amounts;
  if (method === 'MANUAL') {
    amounts = rows.map((r) => Number(manual?.[r.patient_id] ?? 0));
    if (amounts.some((a) => !Number.isInteger(a) || a < 0)) throw new Error('Manual amounts must be whole paise, not negative');
    if (amounts.reduce((a, b) => a + b, 0) !== total_amount) throw new Error('Manual amounts must add up to the total exactly');
  } else amounts = splitExact(total_amount, rows.map((r) => (method === 'EQUAL' ? 1 : r.days)));
  return { head: h.name, rows: rows.map((r, i) => ({ ...r, amount: amounts[i] })).filter((r) => r.amount > 0), total_amount };
}

function allocationConfirm(db, actor, input) {
  const pv = allocationPreview(db, input);
  return db.tx(() => {
    const id = Number(db.run('INSERT INTO fixed_cost_allocations(head_id,period_from,period_to,total_amount,method,created_by) VALUES (?,?,?,?,?,?)',
      input.head_id, input.period_from, input.period_to, input.total_amount, input.method ?? 'PER_PATIENT_DAY', actor.id).lastInsertRowid);
    for (const r of pv.rows) db.run(`INSERT INTO patient_expenses(patient_id,head_id,exp_date,amount,description,source,allocation_id,created_by)
      VALUES (?,?,?,?,?, 'ALLOCATED',?,?)`, r.patient_id, input.head_id, input.period_to, r.amount, `${pv.head} ${input.period_from} to ${input.period_to} (${r.days} day${r.days > 1 ? 's' : ''})`, id, actor.id);
    audit.log(db, actor.id, 'CREATE', 'fixed_cost_allocations', id, null, { head: pv.head, total: input.total_amount, patients: pv.rows.length });
    return { id, patients: pv.rows.length };
  });
}
module.exports = { addHead, addPatientExpense, attach, attachments, addHospitalExpense, allocationPreview, allocationConfirm, splitExact };

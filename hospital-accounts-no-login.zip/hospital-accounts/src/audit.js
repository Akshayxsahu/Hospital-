'use strict';
function log(db, userId, action, table, recordId, oldVal, newVal) {
  db.run(
    'INSERT INTO audit_log(user_id,action,table_name,record_id,old_json,new_json) VALUES (?,?,?,?,?,?)',
    userId ?? null, action, table ?? null, recordId ?? null,
    oldVal == null ? null : JSON.stringify(oldVal), newVal == null ? null : JSON.stringify(newVal));
}
function forRecord(db, table, id) {
  return db.all(`SELECT a.at, u.username, a.action, a.old_json, a.new_json
                 FROM audit_log a LEFT JOIN users u ON u.id=a.user_id
                 WHERE a.table_name=? AND a.record_id=? ORDER BY a.id`, table, id);
}
function list(db, f = {}) {
  const c = [], p = [];
  if (f.user_id) { c.push('a.user_id=?'); p.push(f.user_id); }
  if (f.table_name) { c.push('a.table_name=?'); p.push(f.table_name); }
  if (f.action) { c.push('a.action=?'); p.push(f.action); }
  if (f.from) { c.push('date(a.at)>=?'); p.push(f.from); }
  if (f.to) { c.push('date(a.at)<=?'); p.push(f.to); }
  return db.all(`SELECT a.id,a.at,u.username,a.action,a.table_name,a.record_id,a.old_json,a.new_json FROM audit_log a
                 LEFT JOIN users u ON u.id=a.user_id ${c.length ? 'WHERE ' + c.join(' AND ') : ''} ORDER BY a.id DESC LIMIT ?`, ...p, Math.min(f.limit || 300, 2000));
}
module.exports = { log, forRecord, list };

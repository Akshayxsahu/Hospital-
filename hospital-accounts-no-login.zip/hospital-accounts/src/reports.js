'use strict';
// Every report returns { title, columns:[{key,label,type}], rows:[...], totals? } so the screen,
// Excel export and PDF export all use the SAME data. type: 'text' | 'int' | 'money' (paise).
const util = require('./util');

const col = (key, label, type = 'text') => ({ key, label, type });
const sum = (rows, k) => rows.reduce((s, r) => s + (r[k] || 0), 0);
function where(parts) { const c = parts.filter((p) => p[0]); return { sql: c.length ? ' AND ' + c.map((p) => p[1]).join(' AND ') : '', params: c.flatMap((p) => p.slice(2)) }; }

// ---- Accrual-basis helpers -----------------------------------------------------------------
// ACCRUAL: income = what was BILLED (less credit notes), counted on the bill date - not when the cash arrives.
//          cost   = what was INCURRED, counted on the expense date - not when it is paid.
// Cash received is shown separately (and sits on the balance sheet as cash / dues / advances).
// Salaries belong to a month, so they are accounted on the LAST DAY of their month.
const SAL_END = "date(salary_month||'-01','+1 month','-1 day')";
function income(db, from, to) {
  const billed = db.get('SELECT COALESCE(SUM(total),0) v FROM bills WHERE is_void=0 AND bill_date BETWEEN ?1 AND ?2', from, to).v;
  const cn = db.get('SELECT COALESCE(SUM(amount),0) v FROM credit_notes WHERE is_void=0 AND cn_date BETWEEN ?1 AND ?2', from, to).v;
  return { billed, credit_notes: cn, net: billed - cn };
}
// Overhead rows with source=ALLOCATED are NOT expenses (they re-distribute hospital expenses / salaries) -> excluded to avoid double counting.
function costs(db, from, to, { withSalary = true } = {}) {
  const patient = db.all(`SELECT h.name label, SUM(e.amount) amount FROM patient_expenses e JOIN expense_heads h ON h.id=e.head_id
      WHERE e.is_deleted=0 AND e.source!='ALLOCATED' AND e.exp_date BETWEEN ?1 AND ?2 GROUP BY h.name ORDER BY h.name`, from, to);
  const hospital = db.all(`SELECT h.name label, SUM(x.amount) amount FROM hospital_expenses x JOIN expense_heads h ON h.id=x.head_id
      WHERE x.is_deleted=0 AND x.exp_date BETWEEN ?1 AND ?2 GROUP BY h.name ORDER BY h.name`, from, to);
  const salary = withSalary ? db.get(`SELECT COALESCE(SUM(amount),0) v FROM staff_salaries WHERE ${SAL_END} BETWEEN ?1 AND ?2`, from, to).v : 0;
  return { patient, hospital, salary, total: sum(patient, 'amount') + sum(hospital, 'amount') + salary };
}

// ---- Dashboard -----------------------------------------------------------------------------
function dashboard(db, date = util.ymd()) {
  if (!util.isDate(date)) throw new Error('Invalid date');
  const n = (sql, ...p) => db.get(sql, ...p).v;
  const ym = date.slice(0, 7), mFrom = ym + '-01', mTo = ym + '-31';
  const collected = n('SELECT COALESCE(SUM(amount),0) v FROM payments WHERE is_void=0 AND pay_date=?', date) - n('SELECT COALESCE(SUM(amount),0) v FROM refunds WHERE is_void=0 AND refund_date=?', date);
  const inc = income(db, date, date), exp = costs(db, date, date, { withSalary: false });   // salaries are monthly -> in the month figures
  const minc = income(db, mFrom, mTo), mexp = costs(db, mFrom, mTo);
  return {
    date, month: ym,
    collection: collected,                               // cash actually received today (info only)
    billed: inc.net,                                     // income today (accrual)
    expense: exp.total, profit: inc.net - exp.total,     // profit = accrual
    month_income: minc.net, month_expense: mexp.total, month_profit: minc.net - mexp.total,
    pending_dues: n('SELECT COALESCE(SUM(due),0) v FROM v_patient_financials WHERE due>0'),
    patients_today: n('SELECT COUNT(*) v FROM patients WHERE is_deleted=0 AND admission_date=?', date),
    recent_receipts: db.all(`SELECT y.receipt_no, p.name, y.mode, y.amount, y.pay_date FROM payments y JOIN patients p ON p.id=y.patient_id WHERE y.is_void=0 ORDER BY y.id DESC LIMIT 10`),
    top_dues: db.all('SELECT uhid,name,due FROM v_patient_financials WHERE due>0 ORDER BY due DESC LIMIT 5'),
  };
}

// ---- Calendar: one entry per day of the month for the dashboard calendar ---------------------
function calendarMonth(db, ym) {
  if (!/^\d{4}-(0[1-9]|1[0-2])$/.test(ym || '')) throw new Error('Month must look like 2026-11');
  const from = ym + '-01', to = ym + '-31', days = {};
  const day = (d) => (days[d] ||= { billed: 0, collected: 0, expense: 0, patients: 0 });
  for (const r of db.all('SELECT bill_date d, SUM(total) v FROM bills WHERE is_void=0 AND bill_date BETWEEN ?1 AND ?2 GROUP BY bill_date', from, to)) day(r.d).billed += r.v;
  for (const r of db.all('SELECT cn_date d, SUM(amount) v FROM credit_notes WHERE is_void=0 AND cn_date BETWEEN ?1 AND ?2 GROUP BY cn_date', from, to)) day(r.d).billed -= r.v;
  for (const r of db.all('SELECT pay_date d, SUM(amount) v FROM payments WHERE is_void=0 AND pay_date BETWEEN ?1 AND ?2 GROUP BY pay_date', from, to)) day(r.d).collected += r.v;
  for (const r of db.all('SELECT refund_date d, SUM(amount) v FROM refunds WHERE is_void=0 AND refund_date BETWEEN ?1 AND ?2 GROUP BY refund_date', from, to)) day(r.d).collected -= r.v;
  for (const r of db.all("SELECT exp_date d, SUM(amount) v FROM patient_expenses WHERE is_deleted=0 AND source!='ALLOCATED' AND exp_date BETWEEN ?1 AND ?2 GROUP BY exp_date", from, to)) day(r.d).expense += r.v;
  for (const r of db.all('SELECT exp_date d, SUM(amount) v FROM hospital_expenses WHERE is_deleted=0 AND exp_date BETWEEN ?1 AND ?2 GROUP BY exp_date', from, to)) day(r.d).expense += r.v;
  for (const r of db.all('SELECT admission_date d, COUNT(*) v FROM patients WHERE is_deleted=0 AND admission_date BETWEEN ?1 AND ?2 GROUP BY admission_date', from, to)) day(r.d).patients += r.v;
  return { ym, days };
}

// ---- Patient-wise P&L (by date / doctor / ward) --------------------------------------------
function patientPnl(db, f = {}) {
  const w = where([[f.from, 'f.admission_date>=?', f.from], [f.to, 'f.admission_date<=?', f.to], [f.doctor_id, 'f.doctor_id=?', f.doctor_id],
    [f.ward_id, 'f.ward_id=?', f.ward_id], [f.uhid, 'f.uhid=?', f.uhid]]);
  const rows = db.all(`SELECT f.uhid,f.name,COALESCE(d.name,'Unassigned') doctor,COALESCE(w.name,'-') ward,f.admission_date,
      f.net_billed,f.net_received,f.due,f.direct_cost,f.overhead_cost,f.total_cost,f.profit
      FROM v_patient_financials f LEFT JOIN doctors d ON d.id=f.doctor_id LEFT JOIN wards w ON w.id=f.ward_id
      WHERE 1=1${w.sql} ORDER BY f.admission_date,f.patient_id`, ...w.params);
  const money = ['net_billed', 'net_received', 'due', 'direct_cost', 'overhead_cost', 'total_cost', 'profit'];
  const mc = [col('net_billed', 'Billed', 'money'), col('net_received', 'Received', 'money'), col('due', 'Due', 'money'), col('direct_cost', 'Direct Cost', 'money'),
    col('overhead_cost', 'Overhead', 'money'), col('total_cost', 'Total Cost', 'money'), col('profit', 'Profit / Loss (Billed - Cost)', 'money')];
  const g = f.group_by;
  let out, columns;
  if (['date', 'doctor', 'ward'].includes(g)) {
    const key = { date: 'admission_date', doctor: 'doctor', ward: 'ward' }[g];
    const m = new Map();
    for (const r of rows) {
      const o = m.get(r[key]) || { [key]: r[key], patients: 0, ...Object.fromEntries(money.map((k) => [k, 0])) };
      o.patients++; money.forEach((k) => { o[k] += r[k]; }); m.set(r[key], o);
    }
    out = [...m.values()];
    columns = [col(key, { date: 'Admission Date', doctor: 'Doctor', ward: 'Ward' }[g]), col('patients', 'Patients', 'int'), ...mc];
  } else {
    out = rows;
    columns = [col('uhid', 'Patient ID'), col('name', 'Name'), col('doctor', 'Doctor'), col('ward', 'Ward'), col('admission_date', 'Admitted'), ...mc];
  }
  const totals = Object.fromEntries(money.map((k) => [k, sum(out, k)]));
  if (out.length && out[0].patients !== undefined) totals.patients = sum(out, 'patients');
  return { title: 'Patient-wise Profit & Loss (accrual: billed - cost)', columns, rows: out, totals };
}

// ---- Daily collection ----------------------------------------------------------------------
function dailyCollection(db, f = {}) {
  const w = where([[f.from, 'x.dt>=?', f.from], [f.to, 'x.dt<=?', f.to], [f.mode, 'x.mode=?', f.mode], [f.doctor_id, 'p.doctor_id=?', f.doctor_id], [f.uhid, 'p.uhid=?', f.uhid]]);
  const rows = db.all(`SELECT x.dt date, x.mode, COUNT(*) entries, SUM(x.amt_in) received, SUM(x.amt_out) refunded, SUM(x.amt_in)-SUM(x.amt_out) net FROM (
      SELECT pay_date dt, mode, amount amt_in, 0 amt_out, patient_id FROM payments WHERE is_void=0
      UNION ALL SELECT refund_date, mode, 0, amount, patient_id FROM refunds WHERE is_void=0) x
      JOIN patients p ON p.id=x.patient_id WHERE 1=1${w.sql} GROUP BY x.dt,x.mode ORDER BY x.dt,x.mode`, ...w.params);
  return { title: 'Daily Collection', columns: [col('date', 'Date'), col('mode', 'Mode'), col('entries', 'Entries', 'int'), col('received', 'Received', 'money'), col('refunded', 'Refunded', 'money'), col('net', 'Net', 'money')],
    rows, totals: { entries: sum(rows, 'entries'), received: sum(rows, 'received'), refunded: sum(rows, 'refunded'), net: sum(rows, 'net') } };
}

// ---- Outstanding / dues with ageing --------------------------------------------------------
function outstanding(db, f = {}) {
  const asOf = f.as_of || util.ymd();
  const w = where([[f.doctor_id, 'f.doctor_id=?', f.doctor_id]]);
  const rows = db.all(`SELECT f.uhid,f.name,p.mobile,COALESCE(d.name,'Unassigned') doctor,f.net_billed,f.net_received,f.due,
      (SELECT MIN(bill_date) FROM bills b WHERE b.patient_id=f.patient_id AND b.is_void=0) first_bill
      FROM v_patient_financials f JOIN patients p ON p.id=f.patient_id LEFT JOIN doctors d ON d.id=f.doctor_id
      WHERE f.due>0${w.sql} ORDER BY f.due DESC`, ...w.params)
    .map((r) => { const age = r.first_bill ? util.daysBetween(r.first_bill, asOf) : 0; return { ...r, age_days: age, bucket: age <= 30 ? '0-30' : age <= 60 ? '31-60' : age <= 90 ? '61-90' : '90+' }; });
  return { title: 'Outstanding / Dues', columns: [col('uhid', 'Patient ID'), col('name', 'Name'), col('mobile', 'Mobile'), col('doctor', 'Doctor'), col('net_billed', 'Billed', 'money'),
    col('net_received', 'Received', 'money'), col('due', 'Due', 'money'), col('age_days', 'Days', 'int'), col('bucket', 'Age')], rows, totals: { due: sum(rows, 'due') } };
}

// ---- Doctor-wise ---------------------------------------------------------------------------
function doctorReport(db, f = {}) {
  const from = f.from || '0000-01-01', to = f.to || '9999-12-31';
  const rows = db.all(`SELECT d.id, d.name,
      COALESCE((SELECT SUM(i.amount) FROM bill_items i JOIN bills b ON b.id=i.bill_id WHERE i.doctor_id=d.id AND b.is_void=0 AND b.bill_date BETWEEN ?1 AND ?2),0) billed,
      COALESCE((SELECT SUM(amount) FROM patient_expenses e WHERE e.doctor_id=d.id AND e.is_deleted=0 AND e.exp_date BETWEEN ?1 AND ?2),0) earned,
      COALESCE((SELECT SUM(amount) FROM doctor_settlements s WHERE s.doctor_id=d.id AND s.is_void=0 AND s.settle_date BETWEEN ?1 AND ?2),0) paid,
      (SELECT payable FROM v_doctor_payable v WHERE v.doctor_id=d.id) payable
      FROM doctors d ${f.doctor_id ? 'WHERE d.id=?3' : ''} ORDER BY d.name`, from, to, ...(f.doctor_id ? [f.doctor_id] : []));
  return { title: 'Doctor-wise Collection & Payable', columns: [col('name', 'Doctor'), col('billed', 'Billed under doctor', 'money'), col('earned', 'Earned (fee/commission)', 'money'),
    col('paid', 'Paid in period', 'money'), col('payable', 'Payable till date', 'money')], rows, totals: { billed: sum(rows, 'billed'), earned: sum(rows, 'earned'), paid: sum(rows, 'paid'), payable: sum(rows, 'payable') } };
}

// ---- Overall hospital P&L (ACCRUAL basis) ----------------------------------------------------
function overallPnl(db, f = {}) {
  const from = f.from || '0000-01-01', to = f.to || '9999-12-31';
  const inc = income(db, from, to), c = costs(db, from, to);
  const rows = [{ section: 'INCOME (billed)', label: 'Billing (after discounts)', amount: inc.billed }, { section: 'INCOME (billed)', label: 'Less: credit notes', amount: -inc.credit_notes }];
  c.patient.forEach((r) => rows.push({ section: 'PATIENT COSTS', ...r }));
  c.hospital.forEach((r) => rows.push({ section: 'HOSPITAL EXPENSES', ...r }));
  if (c.salary) rows.push({ section: 'HOSPITAL EXPENSES', label: 'Staff salaries (month-wise)', amount: c.salary });
  rows.push({ section: 'RESULT', label: 'Total income', amount: inc.net }, { section: 'RESULT', label: 'Total expenses', amount: c.total }, { section: 'RESULT', label: 'NET PROFIT / (LOSS)', amount: inc.net - c.total });
  // Memo only - cash movement is NOT income or expense under accrual accounting.
  const rec = db.get('SELECT COALESCE(SUM(amount),0) v FROM payments WHERE is_void=0 AND pay_date BETWEEN ?1 AND ?2', from, to).v;
  const ref = db.get('SELECT COALESCE(SUM(amount),0) v FROM refunds WHERE is_void=0 AND refund_date BETWEEN ?1 AND ?2', from, to).v;
  rows.push({ section: 'MEMO (cash - not in profit)', label: 'Cash received from patients', amount: rec }, { section: 'MEMO (cash - not in profit)', label: 'Less: refunds paid', amount: -ref });
  return { title: 'Overall Hospital Profit & Loss (accrual basis)', columns: [col('section', 'Section'), col('label', 'Particulars'), col('amount', 'Amount', 'money')], rows, totals: { amount: inc.net - c.total } };
}

// ---- Cash book / Bank book -----------------------------------------------------------------
function cashBook(db, f = {}) {
  const acc = db.get(f.account_id ? 'SELECT * FROM accounts WHERE id=?' : 'SELECT * FROM accounts WHERE kind=? ORDER BY id LIMIT 1', f.account_id ?? (f.kind || 'CASH'));
  if (!acc) throw new Error('Account not found');
  const from = f.from || '0000-01-01', to = f.to || '9999-12-31';
  const before = db.get('SELECT COALESCE(SUM(money_in-money_out),0) v FROM v_cashbook WHERE account_id=? AND dt<?', acc.id, from).v;
  let bal = acc.opening_balance + before;
  const rows = [{ date: from === '0000-01-01' ? '' : from, particulars: 'Opening balance', money_in: 0, money_out: 0, balance: bal }];
  for (const r of db.all('SELECT * FROM v_cashbook WHERE account_id=? AND dt BETWEEN ? AND ? ORDER BY dt,ts', acc.id, from, to)) {
    bal += r.money_in - r.money_out;
    rows.push({ date: r.dt, particulars: r.particulars, money_in: r.money_in, money_out: r.money_out, balance: bal });
  }
  return { title: `${acc.kind === 'CASH' ? 'Cash' : 'Bank'} Book - ${acc.name}`, columns: [col('date', 'Date'), col('particulars', 'Particulars'), col('money_in', 'Money In', 'money'), col('money_out', 'Money Out', 'money'), col('balance', 'Balance', 'money')],
    rows, totals: { money_in: sum(rows, 'money_in'), money_out: sum(rows, 'money_out'), balance: bal } };
}

// ---- Balance sheet (accrual) ---------------------------------------------------------------
// Assets = cash + bank + dues receivable + salary paid in advance.
// Liabilities = doctors payable + patient advances held + salaries payable (accrued but not yet paid).
// Capital = opening balances;  Retained = net billed - costs incurred.
// Assets - Liabilities always equals Capital + Retained (a test enforces it on many dates).
function balanceSheet(db, f = {}) {
  const d = f.as_of || util.ymd();
  const rows = [];
  let assets = 0, capital = 0;
  for (const a of db.all('SELECT * FROM accounts ORDER BY id')) {
    const bal = a.opening_balance + db.get('SELECT COALESCE(SUM(money_in-money_out),0) v FROM v_cashbook WHERE account_id=? AND dt<=?', a.id, d).v;
    rows.push({ section: 'ASSETS', label: `${a.kind === 'CASH' ? 'Cash' : 'Bank'}: ${a.name}`, amount: bal }); assets += bal; capital += a.opening_balance;
  }
  const per = db.all(`SELECT (SELECT COALESCE(SUM(total),0) FROM bills WHERE patient_id=p.id AND is_void=0 AND bill_date<=?1)
      -(SELECT COALESCE(SUM(amount),0) FROM credit_notes WHERE patient_id=p.id AND is_void=0 AND cn_date<=?1)
      -(SELECT COALESCE(SUM(amount),0) FROM payments WHERE patient_id=p.id AND is_void=0 AND pay_date<=?1)
      +(SELECT COALESCE(SUM(amount),0) FROM refunds WHERE patient_id=p.id AND is_void=0 AND refund_date<=?1) due,
      (SELECT COALESCE(SUM(total),0) FROM bills WHERE patient_id=p.id AND is_void=0 AND bill_date<=?1)
      -(SELECT COALESCE(SUM(amount),0) FROM credit_notes WHERE patient_id=p.id AND is_void=0 AND cn_date<=?1) nb
      FROM patients p WHERE p.is_deleted=0`, d);
  const recv = per.reduce((s, r) => s + Math.max(r.due, 0), 0), adv = per.reduce((s, r) => s + Math.max(-r.due, 0), 0), netBilled = sum(per, 'nb');
  rows.push({ section: 'ASSETS', label: 'Patient dues receivable', amount: recv }); assets += recv;
  // Salary: expense is recognised at month end; cash leaves on the paid date. The gap is a liability (unpaid) or an asset (paid early).
  const sal = db.get(`SELECT COALESCE(SUM(CASE WHEN ${SAL_END}<=?1 THEN amount ELSE 0 END),0) accrued,
      COALESCE(SUM(CASE WHEN ${SAL_END}<=?1 AND (paid_date IS NULL OR paid_date>?1) THEN amount ELSE 0 END),0) unpaid,
      COALESCE(SUM(CASE WHEN ${SAL_END}>?1 AND paid_date IS NOT NULL AND paid_date<=?1 THEN amount ELSE 0 END),0) advance FROM staff_salaries`, d);
  if (sal.advance) { rows.push({ section: 'ASSETS', label: 'Salary paid in advance', amount: sal.advance }); assets += sal.advance; }
  const docP = db.get(`SELECT COALESCE((SELECT SUM(amount) FROM patient_expenses WHERE doctor_id IS NOT NULL AND is_deleted=0 AND exp_date<=?1),0)
      -COALESCE((SELECT SUM(amount) FROM doctor_settlements WHERE is_void=0 AND settle_date<=?1),0) v`, d).v;
  rows.push({ section: 'LIABILITIES', label: 'Payable to doctors', amount: docP }, { section: 'LIABILITIES', label: 'Patient advances held', amount: adv });
  if (sal.unpaid) rows.push({ section: 'LIABILITIES', label: 'Salaries payable (accrued, not yet paid)', amount: sal.unpaid });
  const cost = db.get(`SELECT COALESCE((SELECT SUM(amount) FROM patient_expenses WHERE is_deleted=0 AND source!='ALLOCATED' AND exp_date<=?1),0)
      +COALESCE((SELECT SUM(amount) FROM hospital_expenses WHERE is_deleted=0 AND exp_date<=?1),0) v`, d).v + sal.accrued;
  const retained = netBilled - cost;
  rows.push({ section: 'CAPITAL', label: 'Opening capital (opening cash + bank)', amount: capital }, { section: 'CAPITAL', label: 'Retained profit / (loss) till date (accrual)', amount: retained });
  const liab = docP + adv + sal.unpaid;
  rows.push({ section: 'TOTALS', label: 'Total assets', amount: assets }, { section: 'TOTALS', label: 'Total liabilities + capital', amount: liab + capital + retained });
  return { title: `Balance Sheet as on ${d}`, columns: [col('section', 'Section'), col('label', 'Particulars'), col('amount', 'Amount', 'money')], rows, balanced: assets === liab + capital + retained, totals: { amount: assets } };
}

const REPORTS = { dashboard, patientPnl, dailyCollection, outstanding, doctorReport, overallPnl, cashBook, balanceSheet };
function run(db, name, filters) {
  if (!REPORTS[name] || name === 'dashboard') throw new Error('Unknown report');
  return REPORTS[name](db, filters || {});
}
module.exports = { dashboard, calendarMonth, run, ...REPORTS };

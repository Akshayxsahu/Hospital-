'use strict';
// Every report returns { title, columns:[{key,label,type}], rows:[...], totals? } so the screen,
// Excel export and PDF export all use the SAME data. type: 'text' | 'int' | 'money' (paise).
const util = require('./util');

const col = (key, label, type = 'text') => ({ key, label, type });
const sum = (rows, k) => rows.reduce((s, r) => s + (r[k] || 0), 0);
function where(parts) { const c = parts.filter((p) => p[0]); return { sql: c.length ? ' AND ' + c.map((p) => p[1]).join(' AND ') : '', params: c.flatMap((p) => p.slice(2)) }; }

// ---- Dashboard -----------------------------------------------------------------------------
function dashboard(db, date = util.ymd()) {
  const n = (sql, ...p) => db.get(sql, ...p).v;
  const collected = n('SELECT COALESCE(SUM(amount),0) v FROM payments WHERE is_void=0 AND pay_date=?', date) - n('SELECT COALESCE(SUM(amount),0) v FROM refunds WHERE is_void=0 AND refund_date=?', date);
  // Overhead rows with source=ALLOCATED are NOT expenses (they re-distribute hospital expenses/salaries) -> excluded to avoid double counting.
  const expense = n("SELECT COALESCE(SUM(amount),0) v FROM patient_expenses WHERE is_deleted=0 AND source!='ALLOCATED' AND exp_date=?", date)
    + n('SELECT COALESCE(SUM(amount),0) v FROM hospital_expenses WHERE is_deleted=0 AND exp_date=?', date)
    + n('SELECT COALESCE(SUM(amount),0) v FROM staff_salaries WHERE paid_date=?', date);
  return {
    date, collection: collected, expense, profit: collected - expense,                 // profit = cash basis
    pending_dues: n('SELECT COALESCE(SUM(due),0) v FROM v_patient_financials WHERE due>0'),
    patients_today: n('SELECT COUNT(*) v FROM patients WHERE is_deleted=0 AND admission_date=?', date),
    recent_receipts: db.all(`SELECT y.receipt_no, p.name, y.mode, y.amount, y.pay_date FROM payments y JOIN patients p ON p.id=y.patient_id WHERE y.is_void=0 ORDER BY y.id DESC LIMIT 10`),
    top_dues: db.all('SELECT uhid,name,due FROM v_patient_financials WHERE due>0 ORDER BY due DESC LIMIT 5'),
  };
}

// ---- Patient-wise P&L (by date / doctor / ward) --------------------------------------------
function patientPnl(db, f = {}) {
  const w = where([[f.from, 'f.admission_date>=?', f.from], [f.to, 'f.admission_date<=?', f.to], [f.doctor_id, 'f.doctor_id=?', f.doctor_id],
    [f.ward_id, 'f.ward_id=?', f.ward_id], [f.uhid, 'f.uhid=?', f.uhid]]);
  const rows = db.all(`SELECT f.uhid,f.name,COALESCE(d.name,'Unassigned') doctor,COALESCE(w.name,'-') ward,f.admission_date,
      f.net_billed,f.net_received,f.due,f.direct_cost,f.overhead_cost,f.total_cost,f.profit
      FROM v_patient_financials f LEFT JOIN doctors d ON d.id=f.doctor_id LEFT JOIN wards w ON w.id=f.ward_id
      WHERE 1=1${w.sql} ORDER BY f.admission_date,f.patient_id`, ...w.params);
  const money = ['net_billed', 'net_received', 'due', 'direct_cost', 'overhead_cost', 'total_cost', 'profit'];
  const mc = [col('net_billed', 'Billed', 'money'), col('net_received', 'Received', 'money'), col('due', 'Due', 'money'), col('direct_cost', 'Direct Cost', 'money'),
    col('overhead_cost', 'Overhead', 'money'), col('total_cost', 'Total Cost', 'money'), col('profit', 'Profit / Loss', 'money')];
  const g = f.group_by;
  let out, columns;
  if (['date', 'doctor', 'ward'].includes(g)) {
    const key = { date: 'admission_date', doctor: 'doctor', ward: 'ward' }[g];
    const m = new Map();
    for (const r of rows) {
      const o = m.get(r[key]) || { [key]: r[key], patients: 0, ...Object.fromEntries(money.map((k) => [k, 0])) };
      o.patients++; money.forEach((k) => { o[k] += r[k]; }); m.set(r[key], o);
    }
    out = [...m.values()];
    columns = [col(key, { date: 'Admission Date', doctor: 'Doctor', ward: 'Ward' }[g]), col('patients', 'Patients', 'int'), ...mc];
  } else {
    out = rows;
    columns = [col('uhid', 'Patient ID'), col('name', 'Name'), col('doctor', 'Doctor'), col('ward', 'Ward'), col('admission_date', 'Admitted'), ...mc];
  }
  const totals = Object.fromEntries(money.map((k) => [k, sum(out, k)]));
  if (out.length && out[0].patients !== undefined) totals.patients = sum(out, 'patients');
  return { title: 'Patient-wise Profit & Loss', columns, rows: out, totals };
}

// ---- Daily collection ----------------------------------------------------------------------
function dailyCollection(db, f = {}) {
  const w = where([[f.from, 'x.dt>=?', f.from], [f.to, 'x.dt<=?', f.to], [f.mode, 'x.mode=?', f.mode], [f.doctor_id, 'p.doctor_id=?', f.doctor_id], [f.uhid, 'p.uhid=?', f.uhid]]);
  const rows = db.all(`SELECT x.dt date, x.mode, COUNT(*) entries, SUM(x.amt_in) received, SUM(x.amt_out) refunded, SUM(x.amt_in)-SUM(x.amt_out) net FROM (
      SELECT pay_date dt, mode, amount amt_in, 0 amt_out, patient_id FROM payments WHERE is_void=0
      UNION ALL SELECT refund_date, mode, 0, amount, patient_id FROM refunds WHERE is_void=0) x
      JOIN patients p ON p.id=x.patient_id WHERE 1=1${w.sql} GROUP BY x.dt,x.mode ORDER BY x.dt,x.mode`, ...w.params);
  return { title: 'Daily Collection', columns: [col('date', 'Date'), col('mode', 'Mode'), col('entries', 'Entries', 'int'), col('received', 'Received', 'money'), col('refunded', 'Refunded', 'money'), col('net', 'Net', 'money')],
    rows, totals: { entries: sum(rows, 'entries'), received: sum(rows, 'received'), refunded: sum(rows, 'refunded'), net: sum(rows, 'net') } };
}

// ---- Outstanding / dues with ageing --------------------------------------------------------
function outstanding(db, f = {}) {
  const asOf = f.as_of || util.ymd();
  const w = where([[f.doctor_id, 'f.doctor_id=?', f.doctor_id]]);
  const rows = db.all(`SELECT f.uhid,f.name,p.mobile,COALESCE(d.name,'Unassigned') doctor,f.net_billed,f.net_received,f.due,
      (SELECT MIN(bill_date) FROM bills b WHERE b.patient_id=f.patient_id AND b.is_void=0) first_bill
      FROM v_patient_financials f JOIN patients p ON p.id=f.patient_id LEFT JOIN doctors d ON d.id=f.doctor_id
      WHERE f.due>0${w.sql} ORDER BY f.due DESC`, ...w.params)
    .map((r) => { const age = r.first_bill ? util.daysBetween(r.first_bill, asOf) : 0; return { ...r, age_days: age, bucket: age <= 30 ? '0-30' : age <= 60 ? '31-60' : age <= 90 ? '61-90' : '90+' }; });
  return { title: 'Outstanding / Dues', columns: [col('uhid', 'Patient ID'), col('name', 'Name'), col('mobile', 'Mobile'), col('doctor', 'Doctor'), col('net_billed', 'Billed', 'money'),
    col('net_received', 'Received', 'money'), col('due', 'Due', 'money'), col('age_days', 'Days', 'int'), col('bucket', 'Age')], rows, totals: { due: sum(rows, 'due') } };
}

// ---- Doctor-wise ---------------------------------------------------------------------------
function doctorReport(db, f = {}) {
  const from = f.from || '0000-01-01', to = f.to || '9999-12-31';
  const rows = db.all(`SELECT d.id, d.name,
      COALESCE((SELECT SUM(i.amount) FROM bill_items i JOIN bills b ON b.id=i.bill_id WHERE i.doctor_id=d.id AND b.is_void=0 AND b.bill_date BETWEEN ?1 AND ?2),0) billed,
      COALESCE((SELECT SUM(amount) FROM patient_expenses e WHERE e.doctor_id=d.id AND e.is_deleted=0 AND e.exp_date BETWEEN ?1 AND ?2),0) earned,
      COALESCE((SELECT SUM(amount) FROM doctor_settlements s WHERE s.doctor_id=d.id AND s.is_void=0 AND s.settle_date BETWEEN ?1 AND ?2),0) paid,
      (SELECT payable FROM v_doctor_payable v WHERE v.doctor_id=d.id) payable
      FROM doctors d ${f.doctor_id ? 'WHERE d.id=?3' : ''} ORDER BY d.name`, from, to, ...(f.doctor_id ? [f.doctor_id] : []));
  return { title: 'Doctor-wise Collection & Payable', columns: [col('name', 'Doctor'), col('billed', 'Billed under doctor', 'money'), col('earned', 'Earned (fee/commission)', 'money'),
    col('paid', 'Paid in period', 'money'), col('payable', 'Payable till date', 'money')], rows, totals: { billed: sum(rows, 'billed'), earned: sum(rows, 'earned'), paid: sum(rows, 'paid'), payable: sum(rows, 'payable') } };
}

// ---- Overall hospital P&L (cash basis for income, as booked for costs) ----------------------
function overallPnl(db, f = {}) {
  const from = f.from || '0000-01-01', to = f.to || '9999-12-31';
  const one = (sql) => db.get(sql, from, to).v;
  const inc = one('SELECT COALESCE(SUM(amount),0) v FROM payments WHERE is_void=0 AND pay_date BETWEEN ?1 AND ?2');
  const ref = one('SELECT COALESCE(SUM(amount),0) v FROM refunds WHERE is_void=0 AND refund_date BETWEEN ?1 AND ?2');
  const patientCosts = db.all(`SELECT h.name label, SUM(e.amount) amount FROM patient_expenses e JOIN expense_heads h ON h.id=e.head_id
      WHERE e.is_deleted=0 AND e.source!='ALLOCATED' AND e.exp_date BETWEEN ?1 AND ?2 GROUP BY h.name ORDER BY h.name`, from, to);
  const hosp = db.all(`SELECT h.name label, SUM(x.amount) amount FROM hospital_expenses x JOIN expense_heads h ON h.id=x.head_id
      WHERE x.is_deleted=0 AND x.exp_date BETWEEN ?1 AND ?2 GROUP BY h.name ORDER BY h.name`, from, to);
  const sal = one('SELECT COALESCE(SUM(amount),0) v FROM staff_salaries WHERE paid_date BETWEEN ?1 AND ?2');
  const rows = [{ section: 'INCOME', label: 'Collections received', amount: inc }, { section: 'INCOME', label: 'Less: refunds', amount: -ref }];
  patientCosts.forEach((r) => rows.push({ section: 'PATIENT COSTS', ...r }));
  hosp.forEach((r) => rows.push({ section: 'HOSPITAL EXPENSES', ...r }));
  if (sal) rows.push({ section: 'HOSPITAL EXPENSES', label: 'Staff salaries', amount: sal });
  const totalCost = sum(patientCosts, 'amount') + sum(hosp, 'amount') + sal;
  rows.push({ section: 'RESULT', label: 'Total income', amount: inc - ref }, { section: 'RESULT', label: 'Total expenses', amount: totalCost }, { section: 'RESULT', label: 'NET PROFIT / (LOSS)', amount: inc - ref - totalCost });
  return { title: 'Overall Hospital Profit & Loss', columns: [col('section', 'Section'), col('label', 'Particulars'), col('amount', 'Amount', 'money')], rows, totals: { amount: inc - ref - totalCost } };
}

// ---- Cash book / Bank book -----------------------------------------------------------------
function cashBook(db, f = {}) {
  const acc = db.get(f.account_id ? 'SELECT * FROM accounts WHERE id=?' : 'SELECT * FROM accounts WHERE kind=? ORDER BY id LIMIT 1', f.account_id ?? (f.kind || 'CASH'));
  if (!acc) throw new Error('Account not found');
  const from = f.from || '0000-01-01', to = f.to || '9999-12-31';
  const before = db.get('SELECT COALESCE(SUM(money_in-money_out),0) v FROM v_cashbook WHERE account_id=? AND dt<?', acc.id, from).v;
  let bal = acc.opening_balance + before;
  const rows = [{ date: from === '0000-01-01' ? '' : from, particulars: 'Opening balance', money_in: 0, money_out: 0, balance: bal }];
  for (const r of db.all('SELECT * FROM v_cashbook WHERE account_id=? AND dt BETWEEN ? AND ? ORDER BY dt,ts', acc.id, from, to)) {
    bal += r.money_in - r.money_out;
    rows.push({ date: r.dt, particulars: r.particulars, money_in: r.money_in, money_out: r.money_out, balance: bal });
  }
  return { title: `${acc.kind === 'CASH' ? 'Cash' : 'Bank'} Book - ${acc.name}`, columns: [col('date', 'Date'), col('particulars', 'Particulars'), col('money_in', 'Money In', 'money'), col('money_out', 'Money Out', 'money'), col('balance', 'Balance', 'money')],
    rows, totals: { money_in: sum(rows, 'money_in'), money_out: sum(rows, 'money_out'), balance: bal } };
}

// ---- Balance sheet -------------------------------------------------------------------------
// Assets = cash + bank + dues receivable.  Liabilities = doctors payable + advances held.
// Capital = opening balances;  Retained = (net billed - costs).  Assets - Liabilities always equals Capital + Retained (test enforces it).
function balanceSheet(db, f = {}) {
  const d = f.as_of || util.ymd();
  const rows = [];
  let assets = 0, capital = 0;
  for (const a of db.all('SELECT * FROM accounts ORDER BY id')) {
    const bal = a.opening_balance + db.get('SELECT COALESCE(SUM(money_in-money_out),0) v FROM v_cashbook WHERE account_id=? AND dt<=?', a.id, d).v;
    rows.push({ section: 'ASSETS', label: `${a.kind === 'CASH' ? 'Cash' : 'Bank'}: ${a.name}`, amount: bal }); assets += bal; capital += a.opening_balance;
  }
  const per = db.all(`SELECT (SELECT COALESCE(SUM(total),0) FROM bills WHERE patient_id=p.id AND is_void=0 AND bill_date<=?1)
      -(SELECT COALESCE(SUM(amount),0) FROM credit_notes WHERE patient_id=p.id AND is_void=0 AND cn_date<=?1)
      -(SELECT COALESCE(SUM(amount),0) FROM payments WHERE patient_id=p.id AND is_void=0 AND pay_date<=?1)
      +(SELECT COALESCE(SUM(amount),0) FROM refunds WHERE patient_id=p.id AND is_void=0 AND refund_date<=?1) due,
      (SELECT COALESCE(SUM(total),0) FROM bills WHERE patient_id=p.id AND is_void=0 AND bill_date<=?1)
      -(SELECT COALESCE(SUM(amount),0) FROM credit_notes WHERE patient_id=p.id AND is_void=0 AND cn_date<=?1) nb
      FROM patients p WHERE p.is_deleted=0`, d);
  const recv = per.reduce((s, r) => s + Math.max(r.due, 0), 0), adv = per.reduce((s, r) => s + Math.max(-r.due, 0), 0), netBilled = sum(per, 'nb');
  rows.push({ section: 'ASSETS', label: 'Patient dues receivable', amount: recv }); assets += recv;
  const docP = db.get(`SELECT COALESCE((SELECT SUM(amount) FROM patient_expenses WHERE doctor_id IS NOT NULL AND is_deleted=0 AND exp_date<=?1),0)
      -COALESCE((SELECT SUM(amount) FROM doctor_settlements WHERE is_void=0 AND settle_date<=?1),0) v`, d).v;
  rows.push({ section: 'LIABILITIES', label: 'Payable to doctors', amount: docP }, { section: 'LIABILITIES', label: 'Patient advances held', amount: adv });
  const costs = db.get(`SELECT COALESCE((SELECT SUM(amount) FROM patient_expenses WHERE is_deleted=0 AND source!='ALLOCATED' AND exp_date<=?1),0)
      +COALESCE((SELECT SUM(amount) FROM hospital_expenses WHERE is_deleted=0 AND exp_date<=?1),0)
      +COALESCE((SELECT SUM(amount) FROM staff_salaries WHERE paid_date<=?1),0) v`, d).v;
  const retained = netBilled - costs;
  rows.push({ section: 'CAPITAL', label: 'Opening capital (opening cash + bank)', amount: capital }, { section: 'CAPITAL', label: 'Retained profit / (loss) till date', amount: retained });
  const liab = docP + adv;
  rows.push({ section: 'TOTALS', label: 'Total assets', amount: assets }, { section: 'TOTALS', label: 'Total liabilities + capital', amount: liab + capital + retained });
  return { title: `Balance Sheet as on ${d}`, columns: [col('section', 'Section'), col('label', 'Particulars'), col('amount', 'Amount', 'money')], rows, balanced: assets === liab + capital + retained, totals: { amount: assets } };
}

const REPORTS = { dashboard, patientPnl, dailyCollection, outstanding, doctorReport, overallPnl, cashBook, balanceSheet };
function run(db, name, filters) {
  if (!REPORTS[name] || name === 'dashboard') throw new Error('Unknown report');
  return REPORTS[name](db, filters || {});
}
module.exports = { dashboard, run, ...REPORTS };

'use strict';
const { app, BrowserWindow, ipcMain, dialog, shell } = require('electron');
const path = require('path');
const fs = require('fs');
const db = require('./db');
const auth = require('./auth');
const backup = require('./backup');
const { reportToXlsx } = require('./xlsx');
const { makeApi } = require('./api');

let call, win, conn;
const dataDir = () => path.join(app.getPath('userData'), 'data');

// Windows can leave the main window "mouse works, keyboard dead" after a dialog or a hidden print window closes.
// Giving focus back explicitly - to the window AND to its web page - fixes it. Called after every dialog / print job.
function refocus() {
  try {
    if (!win || win.isDestroyed()) return;
    if (win.isMinimized()) win.restore();
    win.focus();
    win.webContents.focus();
  } catch (_) { /* window is closing */ }
}
const showOpen = async (opts) => { try { return await dialog.showOpenDialog(win, opts); } finally { refocus(); } };
const showSave = async (opts) => { try { return await dialog.showSaveDialog(win, opts); } finally { refocus(); } };

// Print a page of HTML to a printer, or save it as PDF when pdfPath is given.
// The hidden window is destroyed ONLY after printing has finished (never while the print dialog is open).
function printHtml(html, { pdfPath, silent = false, thermal = false, deviceName } = {}) {
  return new Promise((resolve, reject) => {
    const w = new BrowserWindow({ show: false });
    let done = false;
    const finish = (fn, value) => {
      if (done) return; done = true;
      setTimeout(() => { try { w.destroy(); } catch (_) { /* already gone */ } refocus(); }, 300);
      fn(value);
    };
    w.webContents.on('did-fail-load', (_e, _code, desc) => finish(reject, new Error('Could not prepare the page: ' + desc)));
    w.webContents.on('did-finish-load', async () => {
      try {
        if (pdfPath) {
          // printToPDF page size is in inches: A4, or an 80 mm-wide roll for thermal receipts
          const pdf = await w.webContents.printToPDF({ pageSize: thermal ? { width: 3.15, height: 11 } : 'A4', landscape: /landscape/.test(html), printBackground: true });
          fs.writeFileSync(pdfPath, pdf);
          finish(resolve, pdfPath);
        } else {
          w.webContents.print({ silent, printBackground: true, ...(deviceName ? { deviceName } : {}), ...(thermal ? { pageSize: { width: 80000, height: 200000 } } : {}) },
            (ok, why) => (ok ? finish(resolve, true) : /cancel/i.test(why || '') ? finish(resolve, false) : finish(reject, new Error(why || 'Printing failed - check the printer is on and connected'))));
        }
      } catch (e) { finish(reject, e); }
    });
    w.loadURL('data:text/html;charset=utf-8,' + encodeURIComponent(html));
  });
}

app.whenReady().then(() => {
  const dir = dataDir();
  fs.mkdirSync(dir, { recursive: true });
  backup.applyPendingRestore(dir);                                      // finish a restore requested before restart
  conn = db.open(path.join(dir, 'hospital.db'));                        // also upgrades an older database in place
  conn.exec('PRAGMA journal_mode=WAL;');
  auth.ensureAdmin(conn);
  const ctx = { dataDir: dir, attachDir: path.join(dir, 'attachments'), backupDir: path.join(dir, 'backups') };
  call = makeApi(conn, ctx);

  // Daily automatic backup: on start, then check every hour (first check of each day makes the backup).
  const auto = () => { try { backup.autoBackupIfNeeded(conn, ctx.backupDir); } catch (e) { console.error('auto-backup failed', e); } };
  auto(); setInterval(auto, 60 * 60 * 1000);

  // Renderer gets ONE door into the app; errors come back as plain objects.
  ipcMain.handle('api', (_e, name, args) => {
    try { return { ok: true, data: call(name, ...(args || [])) }; }
    catch (err) { return { ok: false, error: err.message, code: err.code, matches: err.matches }; }
  });
  const guard = (fn) => async (_e, ...a) => { try { return { ok: true, data: await fn(...a) }; } catch (err) { return { ok: false, error: err.message }; } };
  const need = (action) => { require('./permissions').require(call.session()?.role, action); };

  ipcMain.handle('pickFile', guard(async () => (await showOpen({ filters: [{ name: 'PDF / Image', extensions: ['pdf', 'png', 'jpg', 'jpeg'] }] })).filePaths[0] || null));
  ipcMain.handle('pickBackupFile', guard(async () => (await showOpen({ filters: [{ name: 'Backup', extensions: ['db'] }] })).filePaths[0] || null));
  ipcMain.handle('pickFolder', guard(async () => (await showOpen({ properties: ['openDirectory'] })).filePaths[0] || null));
  ipcMain.handle('attachFile', guard(async (expenseId) => {                 // dialog + attach in one step
    const f = (await showOpen({ filters: [{ name: 'PDF / Image', extensions: ['pdf', 'png', 'jpg', 'jpeg'] }] })).filePaths[0];
    return f ? call('expense.attach', expenseId, f) : null;
  }));
  ipcMain.handle('openAttachment', guard(async (rel) => { need('finance.view'); const full = path.join(dir, 'attachments', rel); if (!full.startsWith(path.join(dir, 'attachments'))) throw new Error('Bad path'); return shell.openPath(full); }));
  ipcMain.handle('exportXlsx', guard(async (name, filters) => {
    const rep = call('report.run', name, filters);
    const r = await showSave({ defaultPath: `${rep.title}.xlsx`, filters: [{ name: 'Excel', extensions: ['xlsx'] }] });
    if (r.canceled) return null; fs.writeFileSync(r.filePath, reportToXlsx(rep)); return r.filePath;
  }));
  ipcMain.handle('exportPdf', guard(async (name, filters) => {
    const html = call('print.report', name, filters);
    const r = await showSave({ defaultPath: `${call('report.run', name, filters).title}.pdf`, filters: [{ name: 'PDF', extensions: ['pdf'] }] });
    if (r.canceled) return null; return printHtml(html, { pdfPath: r.filePath });
  }));

  // ---- Printing -------------------------------------------------------------------------------------
  // kind: receipt | bill | discharge | report.   dest: PRINT (printer) | PDF (save as a PDF file).
  // PRINT goes straight to the printer chosen in Admin -> Printers; if none is chosen, Windows' own print window opens.
  const docName = (kind, id) => {
    const q = { receipt: ['SELECT receipt_no n FROM payments WHERE id=?', 'Receipt'], bill: ['SELECT bill_no n FROM bills WHERE id=?', 'Bill'], discharge: ['SELECT uhid n FROM patients WHERE id=?', 'Discharge-slip'] }[kind];
    try { const r = q && conn.get(q[0], id); return `${q ? q[1] : 'Report'}-${r?.n || id}`.replace(/[^\w.-]+/g, '_'); } catch (_) { return 'document'; }
  };
  ipcMain.handle('printDoc', guard(async (kind, id, format, dest = 'PRINT', filters) => {
    const fmt = format === 'THERMAL' && kind !== 'report' ? 'THERMAL' : 'A4';
    const html = kind === 'bill' ? call('print.bill', id, fmt) : kind === 'discharge' ? call('print.discharge', id, fmt)
      : kind === 'report' ? call('print.report', id, filters) : call('print.receipt', id, fmt);
    const thermal = fmt === 'THERMAL';
    if (dest === 'PDF') {
      const r = await showSave({ defaultPath: `${docName(kind, id)}.pdf`, filters: [{ name: 'PDF', extensions: ['pdf'] }] });
      if (r.canceled || !r.filePath) return null;
      return printHtml(html, { pdfPath: r.filePath, thermal });
    }
    const s = call('settings.get');
    const wanted = thermal ? s.printer_thermal : s.printer_a4;
    let deviceName;
    if (wanted) { const installed = await win.webContents.getPrintersAsync(); if (installed.some((p) => p.name === wanted)) deviceName = wanted; }
    return printHtml(html, { thermal, silent: !!deviceName, deviceName });
  }));
  ipcMain.handle('listPrinters', guard(async () => (await win.webContents.getPrintersAsync()).map((p) => ({ name: p.name, isDefault: !!p.isDefault }))));
  ipcMain.handle('openPrinterSettings', guard(async () => { await shell.openExternal('ms-settings:printers'); return true; }));

  ipcMain.handle('backupToFolder', guard(async (kind) => {
    need('backup.manage');
    const f = (await showOpen({ properties: ['openDirectory'], title: 'Choose pen drive or Google Drive folder' })).filePaths[0];
    return f ? call('backup.now', f, kind) : null;
  }));
  ipcMain.handle('restartApp', () => { app.relaunch(); app.exit(0); });

  win = new BrowserWindow({ width: 1280, height: 800, autoHideMenuBar: true,
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false } });
  win.loadFile(path.join(__dirname, '..', 'renderer', 'index.html'));
  // Keyboard safety net: whenever the window becomes active or finishes loading, make sure the page owns the keyboard.
  win.on('focus', () => { if (!win.webContents.isFocused()) win.webContents.focus(); });
  win.webContents.on('did-finish-load', () => win.webContents.focus());
});
app.on('window-all-closed', () => app.quit());

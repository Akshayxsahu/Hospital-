'use strict';
// Thin DB adapter. Electron build uses better-sqlite3; tests / dev without it fall back to node:sqlite.
// Schema changes are applied by MIGRATIONS (numbered, run once, in order) so an installed copy with real
// patient data is upgraded in place - nothing is ever dropped except the derived VIEWS, which are rebuilt.
const fs = require('fs');
const path = require('path');

function openRaw(file) {
  try {
    const Better = require('better-sqlite3');
    return new Better(file);
  } catch (_) {
    const { DatabaseSync } = require('node:sqlite');
    return new DatabaseSync(file);
  }
}

const hasColumn = (raw, table, col) => raw.prepare(`PRAGMA table_info(${table})`).all().some((c) => c.name === col);

// Each migration runs exactly once on an existing database (PRAGMA user_version = how many have run).
// A brand-new database is created from schema.sql, which already includes all of them.
const MIGRATIONS = [
  // 1: "Room No." -> "Bed No."; Aadhar / Ayushman ID proof columns
  (raw) => {
    if (hasColumn(raw, 'patients', 'room_no') && !hasColumn(raw, 'patients', 'bed_no')) raw.exec('ALTER TABLE patients RENAME COLUMN room_no TO bed_no');
    if (!hasColumn(raw, 'patients', 'id_type')) raw.exec('ALTER TABLE patients ADD COLUMN id_type TEXT');
    if (!hasColumn(raw, 'patients', 'ayushman_id')) raw.exec('ALTER TABLE patients ADD COLUMN ayushman_id TEXT');
    raw.exec("UPDATE patients SET id_type='AADHAR' WHERE id_type IS NULL AND aadhar IS NOT NULL AND aadhar<>''");
    raw.exec('CREATE INDEX IF NOT EXISTS ix_pat_ayushman ON patients(ayushman_id)');
  },
  // 2: staff assigned to a patient (separate from the doctor) + staff mobile number
  (raw) => {
    if (!hasColumn(raw, 'patients', 'staff_id')) raw.exec('ALTER TABLE patients ADD COLUMN staff_id INTEGER REFERENCES staff(id)');
    if (!hasColumn(raw, 'staff', 'mobile')) raw.exec('ALTER TABLE staff ADD COLUMN mobile TEXT');
  },
];

function migrate(raw) {
  const v = raw.prepare('PRAGMA user_version').get().user_version;
  for (let i = v; i < MIGRATIONS.length; i++) {
    raw.exec('BEGIN');
    try { MIGRATIONS[i](raw); raw.exec(`PRAGMA user_version = ${i + 1}`); raw.exec('COMMIT'); }
    catch (e) { raw.exec('ROLLBACK'); throw new Error(`Database upgrade ${i + 1} failed: ${e.message}`); }
  }
}


// better-sqlite3 treats numbered placeholders (?1, ?2) as NAMED parameters, so values passed in a list are rejected with
// "Too many parameter values were provided" (node:sqlite accepts them, which hid the problem in tests).
// This turns every ?N into a plain ? and repeats the value where the number is reused, so both drivers behave the same,
// then checks the count - a wrong number of values fails loudly in tests instead of only on the user's PC.
function positional(sql, values) {
  const out = []; let max = 0;
  const text = sql.replace(/'(?:[^']|'')*'|\?(\d+)|\?/g, (m, n) => {
    if (m[0] === "'") return m;                                   // text inside quotes is left alone
    const idx = n ? Number(n) : ++max;
    if (idx > max) max = idx;
    out.push(values[idx - 1]);
    return '?';
  });
  const needed = Math.max(max, 0);
  if (values.length !== needed) throw new Error(`Query expects ${needed} value(s) but ${values.length} were given: ${sql.replace(/\s+/g, ' ').slice(0, 100)}`);
  return { sql: text, values: out };
}

function open(file = ':memory:', { upgrade = true } = {}) {
  const raw = openRaw(file);
  raw.exec('PRAGMA foreign_keys = ON;');
  const exists = raw.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name='users'").get();
  const root = path.join(__dirname, '..', 'db');
  if (!exists) { raw.exec(fs.readFileSync(path.join(root, 'schema.sql'), 'utf8')); raw.exec(`PRAGMA user_version = ${MIGRATIONS.length}`); }
  else if (upgrade) migrate(raw);
  if (upgrade) raw.exec(fs.readFileSync(path.join(root, 'views.sql'), 'utf8'));   // derived data: always rebuilt from the latest rules
  // Same behaviour on both drivers: booleans -> 0/1, undefined -> NULL
  const norm = (p) => p.map((v) => (v === undefined ? null : typeof v === 'boolean' ? (v ? 1 : 0) : v));
  const prep = (sql, p) => { const q = positional(sql, norm(p)); return [raw.prepare(q.sql), q.values]; };
  const db = {
    raw,
    run: (sql, ...p) => { const [st, v] = prep(sql, p); return st.run(...v); },
    get: (sql, ...p) => { const [st, v] = prep(sql, p); return st.get(...v) ?? null; },
    all: (sql, ...p) => { const [st, v] = prep(sql, p); return st.all(...v); },
    exec: (sql) => raw.exec(sql),
    // All-or-nothing: a bill, its audit row and its number are saved together or not at all.
    tx(fn) {
      raw.exec('BEGIN IMMEDIATE');
      try { const r = fn(); raw.exec('COMMIT'); return r; }
      catch (e) { raw.exec('ROLLBACK'); throw e; }
    },
    close: () => raw.close(),
  };
  return db;
}
module.exports = { open, MIGRATIONS, positional };

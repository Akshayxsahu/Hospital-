'use strict';
// Thin DB adapter. Electron build uses better-sqlite3; tests / dev without it fall back to node:sqlite.
const fs = require('fs');
const path = require('path');

function openRaw(file) {
  try {
    const Better = require('better-sqlite3');
    return new Better(file);
  } catch (_) {
    const { DatabaseSync } = require('node:sqlite');
    return new DatabaseSync(file);
  }
}

function open(file = ':memory:') {
  const raw = openRaw(file);
  raw.exec('PRAGMA foreign_keys = ON;');
  const exists = raw.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name='users'").get();
  if (!exists) raw.exec(fs.readFileSync(path.join(__dirname, '..', 'db', 'schema.sql'), 'utf8'));
  // Same behaviour on both drivers: booleans -> 0/1, undefined -> NULL
  const norm = (p) => p.map((v) => (v === undefined ? null : typeof v === 'boolean' ? (v ? 1 : 0) : v));
  const db = {
    raw,
    run: (sql, ...p) => raw.prepare(sql).run(...norm(p)),
    get: (sql, ...p) => raw.prepare(sql).get(...norm(p)) ?? null,
    all: (sql, ...p) => raw.prepare(sql).all(...norm(p)),
    exec: (sql) => raw.exec(sql),
    // All-or-nothing: a bill, its audit row and its number are saved together or not at all.
    tx(fn) {
      raw.exec('BEGIN IMMEDIATE');
      try { const r = fn(); raw.exec('COMMIT'); return r; }
      catch (e) { raw.exec('ROLLBACK'); throw e; }
    },
    close: () => raw.close(),
  };
  return db;
}
module.exports = { open };

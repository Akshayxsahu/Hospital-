'use strict';
const util = require('./util');
// BILL-2026-0001, RCP-2026-0001 ... taken inside the caller's transaction: no gaps, no duplicates.
function next(db, series, now = util.now()) {
  const y = now.getFullYear();
  const r = db.get(`INSERT INTO number_series(series,year,last_no) VALUES (?,?,1)
                    ON CONFLICT(series,year) DO UPDATE SET last_no=last_no+1 RETURNING last_no`, series, y);
  return `${series}-${y}-${String(r.last_no).padStart(4, '0')}`;
}
module.exports = { next };

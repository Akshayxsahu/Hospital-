-- Demo: reproduces the "Patient A" example. Run after schema.sql
INSERT INTO users(id,username,full_name,password_hash,role) VALUES (1,'admin','Admin','x','ADMIN');
INSERT INTO doctors(id,name,speciality) VALUES (1,'Dr. Sharma','General Medicine');
INSERT INTO patients(id,uhid,name,age,gender,mobile,doctor_id,ward_id,bed_no,id_type,aadhar,patient_type,admission_date,discharge_date,status,created_by)
 VALUES (1,'PAT-2026-0001','Patient A',45,'M','9876543210',1,2,'S-12','AADHAR','123456789012','IPD','2026-11-10','2026-11-14','DISCHARGED',1);

INSERT INTO bills(id,bill_no,patient_id,bill_date,subtotal,total,created_by) VALUES (1,'BILL-2026-0001',1,'2026-11-14',1000000,1000000,1);
INSERT INTO bill_items(bill_id,description,doctor_id,qty,rate,amount) VALUES (1,'IPD package (4 days)',1,1,1000000,1000000);

INSERT INTO payments(receipt_no,patient_id,bill_id,pay_date,pay_type,mode,amount,account_id,created_by) VALUES
 ('RCP-2026-0001',1,NULL,'2026-11-10','ADVANCE','CASH',500000,1,1),
 ('RCP-2026-0002',1,1,'2026-11-12','PART','UPI',300000,2,1),
 ('RCP-2026-0003',1,1,'2026-11-14','FULL','CASH',200000,1,1);

INSERT INTO patient_expenses(patient_id,head_id,exp_date,amount,doctor_id,description,source,created_by) VALUES
 (1,1,'2026-11-14',200000,1,'Doctor Fee - Dr. Sharma','AUTO_DOCTOR',1),
 (1,3,'2026-11-14', 20000,NULL,'Food (4 days)','MANUAL',1),
 (1,4,'2026-11-13',150000,NULL,'Pharmacy','MANUAL',1),
 (1,5,'2026-11-11',150000,NULL,'Pathology','MANUAL',1),
 (1,10,'2026-11-14',300000,NULL,'Fixed overhead','ALLOCATED',1);

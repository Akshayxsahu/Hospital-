-- ============================================================================
-- Hospital Accounting Software - SQLite schema (v1.2)  -- no GST anywhere
-- Rules:
--   * ALL money is stored as INTEGER paise (Rs. 10,000 = 1000000). No float errors.
--   * Nothing is hard-deleted. Rows are voided (is_void / is_deleted) + audit_log.
--   * Dates are ISO text 'YYYY-MM-DD'; timestamps 'YYYY-MM-DD HH:MM:SS'.
-- Run: sqlite3 hospital.db < schema.sql
-- ============================================================================
PRAGMA foreign_keys = ON;
PRAGMA journal_mode = WAL;

-- ---------- 1. SETTINGS, USERS, NUMBERING ----------------------------------
CREATE TABLE settings (
  key   TEXT PRIMARY KEY,         -- hospital_name, address, letterhead_path, id_prefix,
  value TEXT                      -- thermal_width, fixed_cost_method, backup_path ...
);

CREATE TABLE users (
  id            INTEGER PRIMARY KEY,
  username      TEXT NOT NULL UNIQUE,
  full_name     TEXT NOT NULL,
  password_hash TEXT NOT NULL,                       -- argon2/bcrypt, never plain text
  role          TEXT NOT NULL CHECK (role IN ('ADMIN','ACCOUNTANT','RECEPTIONIST')),
  is_active     INTEGER NOT NULL DEFAULT 1,
  must_change_password INTEGER NOT NULL DEFAULT 0,
  created_at    TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);

-- Auto-numbering: PAT-2026-0001, BILL-2026-0001, RCP-2026-0001 ...
CREATE TABLE number_series (
  series  TEXT NOT NULL,          -- 'PAT','BILL','RCP','REF','CN','SET'
  year    INTEGER NOT NULL,
  last_no INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (series, year)
);

-- ---------- 2. MASTERS ------------------------------------------------------
CREATE TABLE doctors (
  id              INTEGER PRIMARY KEY,
  name            TEXT NOT NULL,
  speciality      TEXT,
  mobile          TEXT,
  fixed_fee       INTEGER NOT NULL DEFAULT 0,   -- paise per visit/day (0 = none)
  percent_bp      INTEGER NOT NULL DEFAULT 0,   -- % of bill items booked to this doctor, basis points (2000 = 20%)
                                                -- Both can be set: doctor earns fixed fee entries + percent of billed items
  is_active       INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE wards (
  id         INTEGER PRIMARY KEY,
  name       TEXT NOT NULL UNIQUE,          -- General, Semi-Private, Private, ICU
  daily_rate INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE accounts (                      -- Cash book / Bank book
  id              INTEGER PRIMARY KEY,
  name            TEXT NOT NULL UNIQUE,      -- 'Cash in Hand', 'SBI Current A/c'
  kind            TEXT NOT NULL CHECK (kind IN ('CASH','BANK')),
  opening_balance INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE service_items (                 -- Billable items: consultation, bed charge, ECG...
  id          INTEGER PRIMARY KEY,
  name        TEXT NOT NULL,
  category    TEXT,
  default_rate INTEGER NOT NULL DEFAULT 0,
  is_active   INTEGER NOT NULL DEFAULT 1
);

-- ---------- 3. PATIENT MASTER ----------------------------------------------
CREATE TABLE patients (
  id             INTEGER PRIMARY KEY,
  uhid           TEXT NOT NULL UNIQUE,       -- PAT-2026-0001 (auto)
  name           TEXT NOT NULL,
  age            INTEGER,
  gender         TEXT CHECK (gender IN ('M','F','O')),
  mobile         TEXT,
  address        TEXT,
  aadhar         TEXT,                       -- store encrypted/masked in app layer
  guardian_name  TEXT,
  doctor_id      INTEGER REFERENCES doctors(id),
  ward_id        INTEGER REFERENCES wards(id),
  room_no        TEXT,
  patient_type   TEXT NOT NULL CHECK (patient_type IN ('OPD','IPD','EMERGENCY','DAYCARE')),
  admission_date TEXT NOT NULL,
  discharge_date TEXT,
  status         TEXT NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE','DISCHARGED','CLOSED')),
  is_deleted     INTEGER NOT NULL DEFAULT 0,
  created_by     INTEGER REFERENCES users(id),
  created_at     TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);
CREATE INDEX ix_pat_name   ON patients(name COLLATE NOCASE);
CREATE INDEX ix_pat_mobile ON patients(mobile);
CREATE INDEX ix_pat_aadhar ON patients(aadhar);
CREATE INDEX ix_pat_doc    ON patients(doctor_id, admission_date);
CREATE INDEX ix_pat_ward   ON patients(ward_id, admission_date);
CREATE INDEX ix_pat_date   ON patients(admission_date);

-- ---------- 4. BILLING (money we should get) -------------------------------
CREATE TABLE bills (
  id             INTEGER PRIMARY KEY,
  bill_no        TEXT NOT NULL UNIQUE,       -- BILL-2026-0001
  patient_id     INTEGER NOT NULL REFERENCES patients(id),
  bill_date      TEXT NOT NULL,
  subtotal       INTEGER NOT NULL DEFAULT 0, -- sum of items before discount
  discount       INTEGER NOT NULL DEFAULT 0,
  discount_reason TEXT,
  void_reason    TEXT,
  total          INTEGER NOT NULL DEFAULT 0, -- subtotal - discount (no GST charged)
  is_void        INTEGER NOT NULL DEFAULT 0,
  created_by     INTEGER REFERENCES users(id),
  created_at     TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);
CREATE INDEX ix_bill_pat ON bills(patient_id, bill_date);

CREATE TABLE bill_items (
  id         INTEGER PRIMARY KEY,
  bill_id    INTEGER NOT NULL REFERENCES bills(id),
  service_id INTEGER REFERENCES service_items(id),
  description TEXT NOT NULL,
  doctor_id  INTEGER REFERENCES doctors(id), -- for doctor-wise collection
  doctor_percent_bp INTEGER,                 -- optional override of doctor's default % for this line
  qty        INTEGER NOT NULL DEFAULT 1,
  rate       INTEGER NOT NULL,
  amount     INTEGER NOT NULL                -- qty * rate
);

CREATE TABLE credit_notes (
  id         INTEGER PRIMARY KEY,
  cn_no      TEXT NOT NULL UNIQUE,
  patient_id INTEGER NOT NULL REFERENCES patients(id),
  bill_id    INTEGER REFERENCES bills(id),
  cn_date    TEXT NOT NULL,
  amount     INTEGER NOT NULL CHECK (amount > 0),
  reason     TEXT,
  is_void    INTEGER NOT NULL DEFAULT 0,
  void_reason TEXT,
  created_by INTEGER REFERENCES users(id),
  created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);

-- ---------- 5. MONEY RECEIVED / RETURNED -----------------------------------
CREATE TABLE payments (                       -- every receipt
  id          INTEGER PRIMARY KEY,
  receipt_no  TEXT NOT NULL UNIQUE,           -- RCP-2026-0001
  patient_id  INTEGER NOT NULL REFERENCES patients(id),
  bill_id     INTEGER REFERENCES bills(id),   -- NULL for advance taken before bill
  pay_date    TEXT NOT NULL,
  pay_type    TEXT NOT NULL CHECK (pay_type IN ('ADVANCE','PART','FULL')),
  mode        TEXT NOT NULL CHECK (mode IN ('CASH','UPI','CARD','BANK_TRANSFER','INSURANCE_TPA')),
  amount      INTEGER NOT NULL CHECK (amount > 0),
  account_id  INTEGER REFERENCES accounts(id),-- which cash/bank book it lands in
  reference_no TEXT,                          -- UPI txn id / cheque / TPA claim no
  tpa_name    TEXT,
  is_void     INTEGER NOT NULL DEFAULT 0,
  void_reason TEXT,
  created_by  INTEGER REFERENCES users(id),
  created_at  TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);
CREATE INDEX ix_pay_pat  ON payments(patient_id, pay_date);
CREATE INDEX ix_pay_date ON payments(pay_date, mode);

CREATE TABLE refunds (
  id          INTEGER PRIMARY KEY,
  refund_no   TEXT NOT NULL UNIQUE,
  patient_id  INTEGER NOT NULL REFERENCES patients(id),
  payment_id  INTEGER REFERENCES payments(id),
  refund_date TEXT NOT NULL,
  mode        TEXT NOT NULL CHECK (mode IN ('CASH','UPI','CARD','BANK_TRANSFER','INSURANCE_TPA')),
  amount      INTEGER NOT NULL CHECK (amount > 0),
  account_id  INTEGER REFERENCES accounts(id),
  reason      TEXT,
  is_void     INTEGER NOT NULL DEFAULT 0,
  void_reason TEXT,
  created_by  INTEGER REFERENCES users(id),
  created_at  TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);
CREATE INDEX ix_ref_pat ON refunds(patient_id, refund_date);

-- ---------- 6. EXPENSES (money we spend) -----------------------------------
CREATE TABLE expense_heads (
  id        INTEGER PRIMARY KEY,
  name      TEXT NOT NULL UNIQUE,
  scope     TEXT NOT NULL CHECK (scope IN ('PATIENT','FIXED','HOSPITAL')),
            -- PATIENT  : direct cost of a patient (doctor fee, medicine...)
            -- FIXED    : overhead pool allocated to patients (electricity, rent, salary)
            -- HOSPITAL : only in overall P&L (not allocated)
  is_system INTEGER NOT NULL DEFAULT 0,       -- pre-defined heads can't be deleted
  is_active INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE fixed_cost_allocations (         -- one run = "allocate Nov electricity"
  id           INTEGER PRIMARY KEY,
  head_id      INTEGER NOT NULL REFERENCES expense_heads(id),
  period_from  TEXT NOT NULL,
  period_to    TEXT NOT NULL,
  total_amount INTEGER NOT NULL,
  method       TEXT NOT NULL CHECK (method IN ('PER_PATIENT_DAY','EQUAL','MANUAL')),
  is_void      INTEGER NOT NULL DEFAULT 0,
  void_reason  TEXT,
  created_by   INTEGER REFERENCES users(id),
  created_at   TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);

CREATE TABLE patient_expenses (
  id            INTEGER PRIMARY KEY,
  patient_id    INTEGER NOT NULL REFERENCES patients(id),
  head_id       INTEGER NOT NULL REFERENCES expense_heads(id),
  exp_date      TEXT NOT NULL,
  amount        INTEGER NOT NULL CHECK (amount >= 0),
  doctor_id     INTEGER REFERENCES doctors(id),  -- set when head = Doctor Fee
  vendor        TEXT,
  description   TEXT,
  source        TEXT NOT NULL DEFAULT 'MANUAL' CHECK (source IN ('MANUAL','ALLOCATED','AUTO_DOCTOR')),
  allocation_id INTEGER REFERENCES fixed_cost_allocations(id),
  bill_item_id  INTEGER REFERENCES bill_items(id),   -- auto doctor share created from this bill line
  account_id    INTEGER REFERENCES accounts(id),     -- paid from (cash/bank book); NULL for payable/allocated
  is_deleted    INTEGER NOT NULL DEFAULT 0,
  delete_reason TEXT,
  created_by    INTEGER REFERENCES users(id),
  created_at    TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);
CREATE INDEX ix_pexp_pat ON patient_expenses(patient_id, exp_date);
CREATE INDEX ix_pexp_doc ON patient_expenses(doctor_id, exp_date);

CREATE TABLE expense_attachments (            -- prescription / vendor bill PDF or image
  id         INTEGER PRIMARY KEY,
  expense_id INTEGER NOT NULL REFERENCES patient_expenses(id),
  file_name  TEXT NOT NULL,
  file_path  TEXT NOT NULL,                   -- relative path under /attachments/YYYY/MM/
  mime_type  TEXT,
  sha256     TEXT,
  uploaded_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);

CREATE TABLE hospital_expenses (              -- overall expenses not tied to a patient
  id          INTEGER PRIMARY KEY,
  head_id     INTEGER NOT NULL REFERENCES expense_heads(id),
  exp_date    TEXT NOT NULL,
  amount      INTEGER NOT NULL CHECK (amount > 0),
  mode        TEXT NOT NULL DEFAULT 'CASH',
  account_id  INTEGER REFERENCES accounts(id),
  description TEXT,
  is_deleted  INTEGER NOT NULL DEFAULT 0,
  delete_reason TEXT,
  created_by  INTEGER REFERENCES users(id),
  created_at  TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);

-- ---------- 7. DOCTORS & STAFF ---------------------------------------------
CREATE TABLE doctor_settlements (             -- paying the doctor what is payable
  id         INTEGER PRIMARY KEY,
  settle_no  TEXT NOT NULL UNIQUE,
  doctor_id  INTEGER NOT NULL REFERENCES doctors(id),
  settle_date TEXT NOT NULL,
  amount     INTEGER NOT NULL CHECK (amount > 0),
  mode       TEXT NOT NULL DEFAULT 'CASH',
  account_id INTEGER REFERENCES accounts(id),
  note       TEXT,
  is_void    INTEGER NOT NULL DEFAULT 0,
  void_reason TEXT,
  created_by INTEGER REFERENCES users(id),
  created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);

CREATE TABLE staff (
  id             INTEGER PRIMARY KEY,
  name           TEXT NOT NULL,
  designation    TEXT,
  monthly_salary INTEGER NOT NULL DEFAULT 0,
  is_active      INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE staff_salaries (
  id         INTEGER PRIMARY KEY,
  staff_id   INTEGER NOT NULL REFERENCES staff(id),
  salary_month TEXT NOT NULL,                 -- 'YYYY-MM'
  amount     INTEGER NOT NULL,
  paid_date  TEXT,
  mode       TEXT DEFAULT 'CASH',
  account_id INTEGER REFERENCES accounts(id),
  UNIQUE (staff_id, salary_month)
);

-- ---------- 8. SECURITY: AUDIT TRAIL & BACKUPS -----------------------------
CREATE TABLE audit_log (
  id         INTEGER PRIMARY KEY,
  at         TEXT NOT NULL DEFAULT (datetime('now','localtime')),
  user_id    INTEGER REFERENCES users(id),
  action     TEXT NOT NULL CHECK (action IN ('CREATE','UPDATE','VOID','DELETE','LOGIN','LOGOUT','BACKUP','RESTORE','PRINT')),
  table_name TEXT,
  record_id  INTEGER,
  old_json   TEXT,
  new_json   TEXT
);
CREATE INDEX ix_audit_rec ON audit_log(table_name, record_id);
CREATE INDEX ix_audit_usr ON audit_log(user_id, at);

CREATE TABLE backup_log (
  id        INTEGER PRIMARY KEY,
  at        TEXT NOT NULL DEFAULT (datetime('now','localtime')),
  kind      TEXT NOT NULL CHECK (kind IN ('AUTO','MANUAL_USB','GDRIVE')),
  file_path TEXT,
  size_bytes INTEGER,
  status    TEXT NOT NULL DEFAULT 'OK'
);

-- ---------- 9. SYNC (optional cloud sync) -----------------------------------
-- Every write also appends here; a background job pushes unsynced rows when online.
CREATE TABLE sync_queue (
  id         INTEGER PRIMARY KEY,
  table_name TEXT NOT NULL,
  record_id  INTEGER NOT NULL,
  op         TEXT NOT NULL,
  payload    TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now','localtime')),
  synced_at  TEXT
);

-- ============================================================================
-- VIEWS - the "patient-wise accounting" engine. The app never stores totals;
-- it always reads these, so numbers can never go out of sync.
--   Net Billed   = bills - credit notes
--   Net Received = payments - refunds
--   Due          = Net Billed - Net Received
--   Total Cost   = direct expenses + allocated fixed cost
--   Profit/Loss  = Net Received - Total Cost   (cash basis, as in your example)
--   Billed Profit = Net Billed - Total Cost    (accrual basis, shown alongside)
-- ============================================================================
CREATE VIEW v_patient_totals AS
SELECT p.id AS patient_id, p.uhid, p.name, p.doctor_id, p.ward_id, p.patient_type,
       p.admission_date, p.discharge_date,
  COALESCE((SELECT SUM(total)  FROM bills        b WHERE b.patient_id=p.id AND b.is_void=0),0) AS billed,
  COALESCE((SELECT SUM(amount) FROM credit_notes c WHERE c.patient_id=p.id AND c.is_void=0),0)  AS credit_notes,
  COALESCE((SELECT SUM(amount) FROM payments    y WHERE y.patient_id=p.id AND y.is_void=0),0)  AS received,
  COALESCE((SELECT SUM(amount) FROM refunds     r WHERE r.patient_id=p.id AND r.is_void=0),0)  AS refunded,
  COALESCE((SELECT SUM(amount) FROM patient_expenses e WHERE e.patient_id=p.id AND e.is_deleted=0 AND e.source!='ALLOCATED'),0) AS direct_cost,
  COALESCE((SELECT SUM(amount) FROM patient_expenses e WHERE e.patient_id=p.id AND e.is_deleted=0 AND e.source='ALLOCATED'),0)  AS overhead_cost
FROM patients p WHERE p.is_deleted=0;

CREATE VIEW v_patient_financials AS
SELECT *,
  billed - credit_notes                              AS net_billed,
  received - refunded                                AS net_received,
  (billed - credit_notes) - (received - refunded)    AS due,
  direct_cost + overhead_cost                        AS total_cost,
  (received - refunded) - (direct_cost + overhead_cost)  AS profit,
  (billed - credit_notes) - (direct_cost + overhead_cost) AS billed_profit
FROM v_patient_totals;

-- Doctor payable = doctor-fee expenses booked for them - settlements already paid
CREATE VIEW v_doctor_payable AS
SELECT d.id AS doctor_id, d.name,
  COALESCE((SELECT SUM(amount) FROM patient_expenses e WHERE e.doctor_id=d.id AND e.is_deleted=0),0) AS earned,
  COALESCE((SELECT SUM(amount) FROM doctor_settlements s WHERE s.doctor_id=d.id AND s.is_void=0),0)  AS paid,
  COALESCE((SELECT SUM(amount) FROM patient_expenses e WHERE e.doctor_id=d.id AND e.is_deleted=0),0)
 -COALESCE((SELECT SUM(amount) FROM doctor_settlements s WHERE s.doctor_id=d.id AND s.is_void=0),0)  AS payable
FROM doctors d;

-- Cash Book / Bank Book: one row per real money movement per account.
-- (Doctor-fee expenses are payables; cash leaves only when the doctor is settled. Allocated overhead is never cash.)
CREATE VIEW v_cashbook AS
SELECT y.pay_date AS dt, y.account_id, 'Receipt '||y.receipt_no||' - '||p.name AS particulars, y.amount AS money_in, 0 AS money_out, y.created_at AS ts
  FROM payments y JOIN patients p ON p.id=y.patient_id WHERE y.is_void=0
UNION ALL SELECT r.refund_date, r.account_id, 'Refund '||r.refund_no||' - '||p.name, 0, r.amount, r.created_at
  FROM refunds r JOIN patients p ON p.id=r.patient_id WHERE r.is_void=0
UNION ALL SELECT e.exp_date, e.account_id, 'Patient expense - '||h.name||' ('||p.uhid||')', 0, e.amount, e.created_at
  FROM patient_expenses e JOIN expense_heads h ON h.id=e.head_id JOIN patients p ON p.id=e.patient_id
  WHERE e.is_deleted=0 AND e.source='MANUAL' AND e.doctor_id IS NULL AND e.account_id IS NOT NULL
UNION ALL SELECT x.exp_date, x.account_id, 'Hospital expense - '||h.name, 0, x.amount, x.created_at
  FROM hospital_expenses x JOIN expense_heads h ON h.id=x.head_id WHERE x.is_deleted=0
UNION ALL SELECT s.settle_date, s.account_id, 'Doctor settlement '||s.settle_no||' - '||d.name, 0, s.amount, s.created_at
  FROM doctor_settlements s JOIN doctors d ON d.id=s.doctor_id WHERE s.is_void=0
UNION ALL SELECT q.paid_date, q.account_id, 'Salary '||q.salary_month||' - '||f.name, 0, q.amount, q.paid_date
  FROM staff_salaries q JOIN staff f ON f.id=q.staff_id WHERE q.paid_date IS NOT NULL;

-- ---------- SEED DATA --------------------------------------------------------
INSERT INTO expense_heads(name,scope,is_system) VALUES
 ('Doctor Fee','PATIENT',1),('Nursing Charges','PATIENT',1),('Food','PATIENT',1),
 ('Medicine / Pharmacy','PATIENT',1),('Pathology / Lab','PATIENT',1),('Radiology','PATIENT',1),
 ('OT Charges','PATIENT',1),('Room Rent','PATIENT',1),('Consumables','PATIENT',1),
 ('Other Fixed Cost','PATIENT',1),
 ('Electricity','FIXED',1),('Rent','FIXED',1),('Staff Salary','FIXED',1),
 ('Repairs & Maintenance','HOSPITAL',1);
INSERT INTO accounts(name,kind) VALUES ('Cash in Hand','CASH'),('Bank Account','BANK');
INSERT INTO wards(name,daily_rate) VALUES ('General',150000),('Semi-Private',250000),('Private',400000),('ICU',800000);
INSERT INTO settings(key,value) VALUES ('hospital_name','Your Hospital Name'),('address','Address line'),('phone',''),('letterhead_path',''),('thermal_printer','');

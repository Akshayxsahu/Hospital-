-- ============================================================================
-- VIEWS - the "patient-wise accounting" engine. Re-created every time the app starts,
-- so a fix here reaches existing databases too. The app never stores totals.
--   ACCRUAL BASIS: income is counted when BILLED, cost when INCURRED - not when cash moves.
--   Net Billed   = bills - credit notes                      (income)
--   Net Received = payments - refunds                        (cash, shown for dues only)
--   Due          = Net Billed - Net Received
--   Total Cost   = direct expenses + allocated fixed cost
--   Profit/Loss  = Net Billed - Total Cost                   (accrual)
--   Cash Profit  = Net Received - Total Cost                 (kept for reference only)
-- ============================================================================
DROP VIEW IF EXISTS v_patient_financials;
DROP VIEW IF EXISTS v_patient_totals;
DROP VIEW IF EXISTS v_doctor_payable;
DROP VIEW IF EXISTS v_cashbook;

CREATE VIEW v_patient_totals AS
SELECT p.id AS patient_id, p.uhid, p.name, p.doctor_id, p.ward_id, p.patient_type,
       p.admission_date, p.discharge_date,
  COALESCE((SELECT SUM(total)  FROM bills        b WHERE b.patient_id=p.id AND b.is_void=0),0) AS billed,
  COALESCE((SELECT SUM(amount) FROM credit_notes c WHERE c.patient_id=p.id AND c.is_void=0),0)  AS credit_notes,
  COALESCE((SELECT SUM(amount) FROM payments    y WHERE y.patient_id=p.id AND y.is_void=0),0)  AS received,
  COALESCE((SELECT SUM(amount) FROM refunds     r WHERE r.patient_id=p.id AND r.is_void=0),0)  AS refunded,
  COALESCE((SELECT SUM(amount) FROM patient_expenses e WHERE e.patient_id=p.id AND e.is_deleted=0 AND e.source!='ALLOCATED'),0) AS direct_cost,
  COALESCE((SELECT SUM(amount) FROM patient_expenses e WHERE e.patient_id=p.id AND e.is_deleted=0 AND e.source='ALLOCATED'),0)  AS overhead_cost
FROM patients p WHERE p.is_deleted=0;

CREATE VIEW v_patient_financials AS
SELECT *,
  billed - credit_notes                              AS net_billed,
  received - refunded                                AS net_received,
  (billed - credit_notes) - (received - refunded)    AS due,
  direct_cost + overhead_cost                        AS total_cost,
  (billed - credit_notes) - (direct_cost + overhead_cost)  AS profit,        -- accrual basis
  (received - refunded) - (direct_cost + overhead_cost)    AS cash_profit
FROM v_patient_totals;

-- Doctor payable = doctor-fee expenses booked for them - settlements already paid
CREATE VIEW v_doctor_payable AS
SELECT d.id AS doctor_id, d.name,
  COALESCE((SELECT SUM(amount) FROM patient_expenses e WHERE e.doctor_id=d.id AND e.is_deleted=0),0) AS earned,
  COALESCE((SELECT SUM(amount) FROM doctor_settlements s WHERE s.doctor_id=d.id AND s.is_void=0),0)  AS paid,
  COALESCE((SELECT SUM(amount) FROM patient_expenses e WHERE e.doctor_id=d.id AND e.is_deleted=0),0)
 -COALESCE((SELECT SUM(amount) FROM doctor_settlements s WHERE s.doctor_id=d.id AND s.is_void=0),0)  AS payable
FROM doctors d;

-- Cash Book / Bank Book: one row per real money movement per account.
-- (Doctor-fee expenses are payables; cash leaves only when the doctor is settled. Allocated overhead is never cash.)
CREATE VIEW v_cashbook AS
SELECT y.pay_date AS dt, y.account_id, 'Receipt '||y.receipt_no||' - '||p.name AS particulars, y.amount AS money_in, 0 AS money_out, y.created_at AS ts
  FROM payments y JOIN patients p ON p.id=y.patient_id WHERE y.is_void=0
UNION ALL SELECT r.refund_date, r.account_id, 'Refund '||r.refund_no||' - '||p.name, 0, r.amount, r.created_at
  FROM refunds r JOIN patients p ON p.id=r.patient_id WHERE r.is_void=0
UNION ALL SELECT e.exp_date, e.account_id, 'Patient expense - '||h.name||' ('||p.uhid||')', 0, e.amount, e.created_at
  FROM patient_expenses e JOIN expense_heads h ON h.id=e.head_id JOIN patients p ON p.id=e.patient_id
  WHERE e.is_deleted=0 AND e.source='MANUAL' AND e.doctor_id IS NULL AND e.account_id IS NOT NULL
UNION ALL SELECT x.exp_date, x.account_id, 'Hospital expense - '||h.name, 0, x.amount, x.created_at
  FROM hospital_expenses x JOIN expense_heads h ON h.id=x.head_id WHERE x.is_deleted=0
UNION ALL SELECT s.settle_date, s.account_id, 'Doctor settlement '||s.settle_no||' - '||d.name, 0, s.amount, s.created_at
  FROM doctor_settlements s JOIN doctors d ON d.id=s.doctor_id WHERE s.is_void=0
UNION ALL SELECT q.paid_date, q.account_id, 'Salary '||q.salary_month||' - '||f.name, 0, q.amount, q.paid_date
  FROM staff_salaries q JOIN staff f ON f.id=q.staff_id WHERE q.paid_date IS NOT NULL;

